document.addEventListener('DOMContentLoaded', function() {
  function closest (element, selector) {
    if (Element.prototype.closest) {
      return element.closest(selector);
    }
    do {
      if (Element.prototype.matches && element.matches(selector)
        || Element.prototype.msMatchesSelector && element.msMatchesSelector(selector)
        || Element.prototype.webkitMatchesSelector && element.webkitMatchesSelector(selector)) {
        return element;
      }
      element = element.parentElement || element.parentNode;
    } while (element !== null && element.nodeType === 1);
    return null;
  }

  // social share popups
  Array.prototype.forEach.call(document.querySelectorAll('.share a'), function(anchor) {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      window.open(this.href, '', 'height = 500, width = 500');
    });
  });

  // show form controls when the textarea receives focus or backbutton is used and value exists
  var commentContainerTextarea = document.querySelector('.comment-container textarea'),
    commentContainerFormControls = document.querySelector('.comment-form-controls, .comment-ccs');

  if (commentContainerTextarea) {
    commentContainerTextarea.addEventListener('focus', function focusCommentContainerTextarea() {
      commentContainerFormControls.style.display = 'block';
      commentContainerTextarea.removeEventListener('focus', focusCommentContainerTextarea);
    });

    if (commentContainerTextarea.value !== '') {
      commentContainerFormControls.style.display = 'block';
    }
  }

  // Expand Request comment form when Add to conversation is clicked
  var showRequestCommentContainerTrigger = document.querySelector('.request-container .comment-container .comment-show-container'),
    requestCommentFields = document.querySelectorAll('.request-container .comment-container .comment-fields'),
    requestCommentSubmit = document.querySelector('.request-container .comment-container .request-submit-comment');

  if (showRequestCommentContainerTrigger) {
    showRequestCommentContainerTrigger.addEventListener('click', function() {
      showRequestCommentContainerTrigger.style.display = 'none';
      Array.prototype.forEach.call(requestCommentFields, function(e) { e.style.display = 'block'; });
      requestCommentSubmit.style.display = 'inline-block';

      if (commentContainerTextarea) {
        commentContainerTextarea.focus();
      }
    });
  }

  // Mark as solved button
  var requestMarkAsSolvedButton = document.querySelector('.request-container .mark-as-solved:not([data-disabled])'),
    requestMarkAsSolvedCheckbox = document.querySelector('.request-container .comment-container input[type=checkbox]'),
    requestCommentSubmitButton = document.querySelector('.request-container .comment-container input[type=submit]');

  if (requestMarkAsSolvedButton) {
    requestMarkAsSolvedButton.addEventListener('click', function () {
      requestMarkAsSolvedCheckbox.setAttribute('checked', true);
      requestCommentSubmitButton.disabled = true;
      this.setAttribute('data-disabled', true);
      // Element.closest is not supported in IE11
      closest(this, 'form').submit();
    });
  }

  // Change Mark as solved text according to whether comment is filled
  var requestCommentTextarea = document.querySelector('.request-container .comment-container textarea');

  if (requestCommentTextarea) {
    requestCommentTextarea.addEventListener('input', function() {
      if (requestCommentTextarea.value === '') {
        if (requestMarkAsSolvedButton) {
          requestMarkAsSolvedButton.innerText = requestMarkAsSolvedButton.getAttribute('data-solve-translation');
        }
        requestCommentSubmitButton.disabled = true;
      } else {
        if (requestMarkAsSolvedButton) {
          requestMarkAsSolvedButton.innerText = requestMarkAsSolvedButton.getAttribute('data-solve-and-submit-translation');
        }
        requestCommentSubmitButton.disabled = false;
      }
    });
  }

  // Disable submit button if textarea is empty
  if (requestCommentTextarea && requestCommentTextarea.value === '') {
    requestCommentSubmitButton.disabled = true;
  }

  // Submit requests filter form in the request list page
  Array.prototype.forEach.call(document.querySelectorAll('#request-status-select, #request-organization-select'), function(el) {
    el.addEventListener('change', function(e) {
      e.stopPropagation();
      closest(this, 'form').submit();
    });
  });

  function toggleNavigation(toggleElement) {
    var menu = document.getElementById('user-nav');
    var isExpanded = menu.getAttribute('aria-expanded') === 'true';
    menu.setAttribute('aria-expanded', !isExpanded);
    toggleElement.setAttribute('aria-expanded', !isExpanded);
  }

  var burgerMenu = document.querySelector('.header .icon-menu');
  var userMenu = document.querySelector('#user-nav');

  // burgerMenu.addEventListener('click', function(e) {
  //   e.stopPropagation();
  //   toggleNavigation(this);
  // });

  // burgerMenu.addEventListener('keyup', function(e) {
  //   if (e.keyCode === 13) { // Enter key
  //     e.stopPropagation();
  //     toggleNavigation(this);
  //   }
  // });

  userMenu.addEventListener('keyup', function(e) {
    if (e.keyCode === 27) { // Escape key
      e.stopPropagation();
      this.setAttribute('aria-expanded', false);
      burgerMenu.setAttribute('aria-expanded', false);
    }
  });

  // if (userMenu.children.length === 0) {
  //   burgerMenu.style.display = 'none';
  // }

  // Submit organization form in the request page
  var requestOrganisationSelect = document.querySelector('#request-organization select');

  if (requestOrganisationSelect) {
    requestOrganisationSelect.addEventListener('change', function() {
      closest(this, 'form').submit();
    });
  }

  // Toggles expanded aria to collapsible elements
  Array.prototype.forEach.call(document.querySelectorAll('.collapsible-nav, .collapsible-sidebar'), function(el) {
    el.addEventListener('click', function(e) {
      e.stopPropagation();
      var isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
    });
  });

  // If a section has more than 6 subsections, we collapse the list, and show a trigger to display them all
  const seeAllTrigger = document.querySelector("#see-all-sections-trigger");
  const subsectionsList = document.querySelector(".section-list");

  if (subsectionsList && subsectionsList.children.length > 6) {
    seeAllTrigger.setAttribute("aria-hidden", false);

    seeAllTrigger.addEventListener("click", function(e) {
      subsectionsList.classList.remove("section-list--collapsed");
      seeAllTrigger.parentNode.removeChild(seeAllTrigger);
    });
  }
  
  //Start custom JS
  // Expand section by URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  const section = urlParams.get('section');

  if (section) {
    document.getElementById("section-"+section+"").checked = true;
    location.hash = "#section__" + section;
  }
  
  //Expand one section at a time
  var accordion__triggers = document.getElementsByClassName("accordion__trigger");
  for (var i = 0; i < accordion__triggers.length; i++) {
    accordion__triggers[i].addEventListener("click", function(e) {
      if (!this.classList.contains('active')) {
        accordion_close();
      	this.checked=true;
      	this.classList.add('active');
      }
    });
  }

	setCurrentYear();
  
  var user_dropdown__button = document.getElementById('gr_user_menu_avatar');
  var user_dropdown = document.getElementById('user__dropdown');

  user_dropdown__button.onclick = function() {
    user_dropdown.classList.toggle('active');
  }
  
});

// Set current year in footer
function setCurrentYear(){
  year=new Date().getYear();
  if (year<1900)
    year+=1900;
  document.getElementById("currentYear").innerHTML = year;
}

//Close sections
function accordion_close(){
  var checkboxes=document.getElementsByClassName('accordion__trigger');
  for(var i=0; i<checkboxes.length; i++) {
    if(checkboxes[i].type=='checkbox')
      checkboxes[i].checked=false;
    	checkboxes[i].classList.remove('active');
  }
}

$(document).ready(function(){

  var hc_url = 'https://support.freepik.com'

  var _allarticles = [], 
  _sorted = [],
  _artHtml = '',
  _id, 
  _url;

  var _articles = function(article){
    $.ajax({
      url: _url,
      type: 'GET',
      dataType: 'json',
      success: article
    });
  };

  // function for see all articles button in category
  $('.see-all-articles').click(function(e){
    e.preventDefault();
    _id = $(e.target).attr('href').split('/sections/')[1].split('-')[0];

    if(typeof HelpCenter.user.locale == 'undefined') {
      HelpCenter.user.locale = window.location.pathname.replace('/', '').replace('?', '/').split('/')[1];
    }

    _url = hc_url+'/api/v2/help_center/'+HelpCenter.user.locale+'/sections/'+_id+'/articles.json';
    _articles(function(data){
      _allarticles = data.articles;

      if(data.count>30){
        for(var i = 1; i<data.page_count; i++){
          _url = data.next_page;
          _articles(function(data){
            _allarticles = _allarticles.concat(data.articles);
            _arthtml = '';
            $(_allarticles).each(function(idx, itm){
              if(itm.draft==true){
              } else {
                _arthtml = _arthtml + '<li class="'+(itm.promoted==true?'article-promoted':'')+'"><a href="'+itm.html_url+'">'+itm.title+'</a></li>';
              }
            });
            $(e.target).parent().find('ul.article-list').html(_arthtml);
            $(e.target).hide();
          })
        }
      } else {
        _arthtml = '';
        $(data.articles).each(function(idx, itm){
          if(itm.draft==true){
          } else {
            _arthtml = _arthtml + '<li class="'+(itm.promoted==true?'article-promoted':'')+'"><a href="'+itm.html_url+'">'+itm.title+'</a></li>';
          }
        });
        $(e.target).parent().find('ul.article-list').html(_arthtml);
        $(e.target).hide();
      }

    });
  });
  // function for see all articles button in category ends here

});

$(document).ready(function() {
  // Redirect for about section
  if (window.location.href.indexOf("en-us/sections/200924741-About-Freepik") > -1 || window.location.href.indexOf("en-us/articles/202567252-Who-is-behind-Freepik-") > -1) {
    window.location.href='http://www.freepikcompany.com/about_us';
	}
  
  var notDefaultLanguage = window.location.href.indexOf('/en-us') == -1;
  if ( notDefaultLanguage ) {
    var newURL = window.location.href.replace(/(.*\/hc\/)([\w-]+)(\/.*)?/, "$1en-us$3");
	} 
});

function logged_in_callback() 
{
if (gr.auth.logged && $('nav.user-nav a.login').length)
redirect('https://support.freepik.com/access/login?theme=hc&hc=true&force_unaltered_return_to=true&locale=1&return_to=' + location.href);
else if (!gr.auth.logged && $('nav.user-nav div#user').length)
redirect('https://support.freepik.com/access/logout');
else if (!gr.auth.logged)
$('#gr_user_menu li.link-login a').attr('href', 'https://support.freepik.com/access/login?theme=hc&hc=true&force_unaltered_return_to=true&locale=1&return_to=' + location.href);
else if (gr.auth.logged)
$('#gr_user_menu li a.gr_logout_button').off().attr('href', 'https://support.freepik.com/access/logout');
}

function new_comment_notification(e)
{ 
  e.preventDefault();
  
  $('#gr_loader').show();
	gr.request.post('support/send_zendesk_comment_notification', {url: location.href, user_id: gr.auth.me.id, user_login: gr.auth.me.login});
}

function user_dropdown() {
  var dropdown = document.getElementById('user__dropdown');
  
  dropdown.classList.toggle('active');
}
