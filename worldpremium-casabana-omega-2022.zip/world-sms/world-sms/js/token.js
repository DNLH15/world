function gera(){
   now = new Date;


    
    var d1 = now.getDate()+now.getFullYear();

    var b64 = window.btoa(d1*d1);
 

   
    return b64;
}




