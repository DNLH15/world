// Core By Adm Terror

function rank(){
    // var corpo = document.getElementsByClassName('content');
    // console.log(corpo);
    var bt = document.getElementById('fixa');
    
    $("#conteudo").fadeOut('slow');
    $.ajax({
        url:"./rank.php",
        type:"GET",
        async:false,
        success:function(data){
                bt.click();
            $("#conteudo").html(data);
            $("#conteudo").fadeIn("slow");
        },error:function(data){
            console.log(data);
        }
    });
}

function menu(){
    var id_usuario = document.getElementById("id_usuario");
}
