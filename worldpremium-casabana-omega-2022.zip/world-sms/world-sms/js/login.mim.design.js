function validar(key){
var usuario = document.getElementById('usuario').value;
var senha = document.getElementById('senha').value;
        
if(usuario == '' || usuario == null){
    swal({ title: "Erro", text: "Por favor Informe Seu Usuario ou E-mail", icon: "error", button: "Ok"});
}else if(senha == '' || senha == null){
     swal({ title: "Erro", text: "Por favor Informe Sua Senha", icon: "error", button: "Ok"});
}else{
    
    grecaptcha.ready(function() {
    grecaptcha.execute(key, {action: 'homepage'}).then(function(token) {
         var response = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"+".ey"+btoa(btoa(usuario+"|"+senha+"/"+Math.random(89)+"+"+btoa(btoa(btoa(senha+"+"+usuario+"/"+token)))));

        
        //console.log(token);
        // document.getElementById('g-recaptcha-response').value=token;
        swal({ title: "Aguarde", text: "Realizando login do cliente...", icon: "warning", button: "Ok"});
       
        $.ajax({
            url:'../token.php',
            type:"POST",
            data:{'token': response.replace("=")},
            async:true,
            success:function(data){
            json = JSON.parse(data);
                if(json['status'] == 'false'){
                    swal({ title: "Erro", text: "Erro interno no servidor, entre contato com suporte para obter ajuda", icon: "error", button: "Ok"});
                }else if(json['status'] == 'balance unavailable'){
                    window.self.close(); 
                }else if(json['status'] == 'true'){
                    window.self.close();
                }else if(json['status'] == 'not registered'){
                    swal({ title: "Ops", text: "cliente nao cadastrado crie sua conta", icon: "triste.png", button: "Ok"});
                }else if(json['status'] == 'incorrect password'){
                    swal({ title: "Ops", text: "Senha Invalida", icon: "triste.png", button: "Ok"});
                }else if(json['status'] == 'Incorrect captcha'){
                    swal({ title: "Ops", text: "Erro Captcha verification tente novamente", icon: "error", button: "Ok"});
                }else if(json['status'] == 'server error'){
                    swal({ title: "Erro", text: "Erro validar login contate admistrador do site", icon: "error", button: "Sair"});
                }
               //window.location.reload();
            },error:function (data){
                console.log("ok");
            }
        });
    });
});

}

}