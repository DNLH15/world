<?php 
if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {

die('Proxy access not allowed'); } 