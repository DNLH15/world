<?php

error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
	file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
	die('Proxy access not allowed'); 
} 

$notifiyusers = array("status"=> "false");
$notifiyusers = json_encode($notifiyusers,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
$salvaone = file_put_contents(getcwd().'/token.json', $notifiyusers);
echo json_encode(array("status"=> "true", "message"=> "success data found!",  "code"=> "200"));
exit();


?>