<?php 

error_reporting(0);
session_start();
if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

if(strpos($_SERVER['REQUEST_METHOD'], "POST")!==false){

$response_api = json_decode(file_get_contents("php://input"),true);

if($response_api['id_usuario']){

  $id_saldo = $response_api['id_usuario'];
  $tokenid = $response_api['id'];

if(empty($id_saldo)){
   echo json_encode(array("status"=> "error", "message"=> "Unidentified customer token error, re-login to our dashboard", "code"=> "500"));
   exit();
}

if(!isset($id_saldo)  || empty($id_saldo)){
    echo json_encode(array("status"=> "error", "message"=> "Unidentified customer token error, re-login to our dashboard", "code"=> "500"));
    exit();
}

require_once  getcwd()."/conexao/code.php";

$users = json_decode(file_get_contents(getcwd()."/world-sms/login/keysaccess.json"),true);
$smsregistro = file_get_contents(getcwd()."/world-sms/cp/smsregistro.json");

$sql = "SELECT * FROM usuarios where access_key = '$id_saldo'";
$realiza = mysqli_query($conexao,$sql);
$dados = mysqli_fetch_assoc($realiza);

if ($realiza == true) {
	 $saldo = $dados['base_saldo'];
	 $login_aprovados = $dados['login_aprovadas'];
	 $token = $dados['usuario'];
	 $quantidade = $dados['quantidade'];
   $registro = $dados['registro'];
	 
	 $users[$id_saldo]['saldo'] = $saldo;
	 
	 $dsalvasaldo = json_encode($users,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
     file_put_contents(getcwd()."/world-sms/login/keysaccess.json", $dsalvasaldo);

	 if(empty($login_aprovados) || !$login_aprovados ){
	     $login_aprovados = 0;
	 }
     $cc_aprovadas = $dados['ccs_aprovadas'];
     if(empty($cc_aprovadas) || !$cc_aprovadas ){
	     $cc_aprovadas = 0;
	 }

	 if(empty($quantidade) || !$quantidade ){
	     $quantidade = 0;
	 }

    if(empty($registro) || !$registro ){
       $registro = 0;
    }

if($dados['token'] != $tokenid){
	session_start();
    session_destroy();
    $_SESSION = array();
    $deletetoken = mysqli_query($conexao, "DELETE token FROM usuarios WHERE access_key ='$id_saldo'");
    echo json_encode(array("status"=> "d", "msg"=>"0", "Ip" => $ip, "Extra" =>" ip Em 16 bits" ,"Ip Plubic" => $ip_plubic));
    exit();
}

if($saldo == 0  ||  $saldo == 1 || $saldo < 0 ){
    	echo json_encode(array("status"=> "redirect","msg"=>"Realiza Compra"));
    	exit();
}

	if ($saldo <= 1 ) {
				$msg = json_encode(array("status"=> "false","msg"=>"Sem Saldo"));
				session_destroy();	
	}else{
        $msg22 = base64_encode($saldo);
		$msg = json_encode(array("status"=> "true", "msg"=> "$msg22", "Login_aprovados" => $login_aprovados, "ccs_aprovadas" => $cc_aprovadas, 'ip'=> $ip_plubic, "Ip plubic" => $ip_plubic, "sms_recebidos"=> $quantidade, "registro"=> $registro, "total_sms"=> substr_count($smsregistro, "message"), "code"=> "200"));
	}
}else{
	echo json_encode(array("status"=> "error", "message"=> "Unidentified customer token error, re-login to our dashboard", "code"=> "500"));
    exit();
}
  echo $msg;
}else{
   echo json_encode(array("status"=> "error", "message"=> "Unidentified customer token error, re-login to our dashboard", "code"=> "500"));
   exit();
 }
}else{
  file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  echo json_encode(array("status"=> "error", "message"=> "method not recognized GET POST PUT", "code"=> "500"));
  exit();
}


?>