<?php 
  session_start();
  session_destroy();
  $_SESSION = array();
  header('location: https://worldpremiumchks.com');
  echo "<script>location.href='https://worldpremiumchks.com'</script>";
  exit();

?>