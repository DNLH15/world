<?php

echo explode("-", $_SERVER['HTTP_HOST'])[1];