<?php


function salveip($access_key){
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $ipaddress = '';

    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';


    $ips = json_decode(file_get_contents(getcwd()."/world-sms/login/sessions.json") , true);

    $ips[$access_key][] = [
        "ip" => $ipaddress,
        "useragent" => base64_encode($useragent),
        "time" => time()
    ];

    $ips[$access_key] = array_reverse($ips[$access_key]);

    $dsalva = json_encode($ips,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
    $salva = file_put_contents(getcwd()."/world-sms/login/sessions.json", $dsalva);
}
