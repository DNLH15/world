<?php

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

    if(!isset($_SESSION['limite'])){
        session_destroy();
        header("location: http://worldpremiumchks.com");
        echo "<script>location.href='http://worldpremiumchks.com'</script>";
        exit();
    }

    if($_SESSION['registro']){
       $segundos = time() - $_SESSION['registro'];

    }else{
        session_destroy();
        header("Location: http://worldpremiumchks.com");
        echo "<script>location.href='http://worldpremiumchks.com'</script>";
        exit();
    }

    if(!isset($_SESSION['logado'])){
       
       session_destroy();
       header("Location: http://worldpremiumchks.com");
       echo "<script>location.href='http://worldpremiumchks.com'</script>";
       exit();
    }


?>
