function validar(key){
var usuario = document.getElementById('usuario').value;
var senha = document.getElementById('senha').value;
        
if(usuario == '' || usuario == null){
    swal({ title: "Erro", text: "Por favor Informe Seu Usuario ou E-mail", icon: "error", button: "Ok"});
}else if(senha == '' || senha == null){
     swal({ title: "Erro", text: "Por favor Informe Sua Senha", icon: "error", button: "Ok"});
}else{
    
    grecaptcha.ready(function() {
    grecaptcha.execute(key, {action: 'homepage'}).then(function(token) {
         var linha = usuario+"|"+senha;

        
        //console.log(token);
        // document.getElementById('g-recaptcha-response').value=token;
        swal({ title: "Aguarde", text: "Realizando login do cliente...", icon: "warning", button: "Ok"});
       
        $.ajax({
            url:'token.php',
            type:"POST",
            data:{'cliente_id': btoa(btoa(btoa(linha)))+"_"+(btoa(btoa(btoa(linha)))), 'g-recaptcha-response':token},
            async:true,
            success:function(data){
            json = JSON.parse(data);
                if(json['status'] == 'false'){
                    swal({ title: "Erro", text: "Erro interno no servidor, entre contato com suporte para obter ajuda", icon: "error", button: "Ok"});
                }else if(json['status'] == 'balance unavailable'){
                    swal({ title: "Sucesso", text: "Cliente Logado Com Sucesso ! redirecionando....", icon: "success", button: "Ok"}).then((willDelete) => {
                        if (willDelete) { window.parent.location = '/new-index/?pagina=3' }else{ setTimeout(function(){ window.location = '/new-index/?pagina=3'}, 2000);}
                    }); 
                }else if(json['status'] == 'true'){
                    swal({ title: "Sucesso", text: "Cliente Logado Com Sucesso ! redirecionando....", icon: "success", button: "Ok"}).then((willDelete) => {
                        if (willDelete) { window.parent.location = '/new-index' }else{ setTimeout(function(){ window.location = '/new-index'}, 2000);}
                    }); 
                }else if(json['status'] == 'not registered'){
                    swal({ title: "Ops", text: "cliente nao cadastrado crie sua conta", icon: "triste.png", button: "Ok"});
                }else if(json['status'] == 'incorrect password'){
                    swal({ title: "Ops", text: "Senha Invalida", icon: "triste.png", button: "Ok"});
                }else if(json['status'] == 'Incorrect captcha'){
                    swal({ title: "Ops", text: "Erro Captcha verification tente novamente", icon: "error", button: "Ok"});
                }else if(json['status'] == 'server error'){
                    swal({ title: "Erro", text: "Erro validar login contate admistrador do site", icon: "error", button: "Sair"});
                }
               //window.location.reload();
            },error:function (data){
                console.log("ok");
            }
        });
        //setTimeout(function time(){swal({ title: "Ops!", text: "Não foi possível continuar sua solicitação, tente novamente. Caso erro persistir contate nosso suporte ajuda", icon: "error",closeOnClickOutside: false, button: "Ok"});},50000);        
    });
});

}

}