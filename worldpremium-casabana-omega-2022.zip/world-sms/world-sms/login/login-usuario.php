<?php
session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

function letras($size){
    $basic = '01234789abcdef';
    $return= "";
    for($count= 0; $size > $count; $count++){
        $return.= $basic[rand(0, strlen($basic) - 1)];
    }
    return $return;
}

$authenticity_token = strtoupper(letras(67));
$keytoken = letras(8).'-'.letras(4).'-'.letras(4).'-'.letras(4).'-'.letras(20);

define('SITE_KEY', '6Ld_h74UAAAAAJu_OC7Y8Yf1PJofb-qa0-aB4Xbs');

$response = $_SESSION['id_usuario'];
$token = $_GET['tipo'];
$token1 = explode(".", $_GET['token'])[1];
$token1 = explode("ey", $token1)[1];
$token1 = base64_decode(base64_decode($token1));
$user = json_decode($token1,true)["user"];
$urlid = json_decode($token1,true)["pass"];

if($response == ""){
    session_destroy();
}else{
   echo "<script>setTimeout(function(){ window.location = '/cp/world-sms'}, 2000) </script>"; 
}

if($token == "login"){
   $idsurl = '<input type="hidden" id="usuario" name="usuario" value="'.$user.'"><input type="hidden" id="urlid" name="urlid" value="'.$urlid.'">';
}


?>

<!DOCTYPE>
<html lang="pt-br">
<head>
  <title>LOGIN | WORLD-SMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link rel="apple-touch-icon-precomposed" href="/world-sms/image/Logo.png">
  <link rel="icon" href="/world-sms/image/Logo.png">
  <link rel="shortcut icon" href="/world-sms/image/Logo.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="/world-sms/login/css.css">
  <link rel="shortcut icon" href="/world-sms/image/Logo.png">
  <script src='https://www.google.com/recaptcha/api.js?render=<?php echo SITE_KEY; ?>'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body class="page page-onboarding preload">

<div class="preloader">
    <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel">
      </div>
    </div><p>carregando aguarde...</p>
  </div>
</div>
<div class="page">
  <main>
    <a href="//worldpremiumchks.com" class="button button-close" role="button"></a>

    <section class="row no-gutter reverse-order">
      <div class="col-one-half middle padding">
        <br><br>
        <div class="max-width-s">
          <h5><font color="white">WORLDPREMIUM-CHKS</font></h5>
          <p class="paragraph"><font color="white">Digite Seus Dados Para Continuar.</font></p>
          <input type="hidden" name="authenticity_token" value="<?php echo $authenticity_token; ?>" />
             <input type="hidden" name="keytoken" value="<?php echo $keytoken; ?>" />
          <form>
            <div class="form-group">
            <a href="#?esqueci-o-email" id="recup-email" onclick="recupEmail();" class="form-help"><font color="white">Esqueçeu o Email?</font></a>
              <label for="email"><font color="white">Email:</font></label>
              <input id="usuario" type="email" name="email"  placeholder="Email">
            </div>
            <div class="form-group">
              <label for="password"><font color="white">Senha:</font></label>
              <input id="urlid" type="password" name="urlid" placeholder="Senha">

              <a href="//worldpremiumchks.com/recuperar" class="form-help"><font color="white">Esqueçeu a senha?</font></a>
            </div>
            <div class="form-group">
              <input id="remember" type="checkbox" name="remember-me">
              <label for="remember" class="checkbox"><font color="white">Lembrar</font></label>
            </div>
            <a class="button button-primary full-width" id="submit" type="submit" data-sitekey="<?php echo SITE_KEY; ?>" onclick="validar('<?php echo SITE_KEY; ?>')" role="button"><div id="loginId">Login</div></a>

        </div>
        <div class="center max-width-s space-top">
          <span class="muted"><font color="white">ainda não possui acesso? </font></span><a href="//worldpremiumchks.com/tabela">Cadastre-se agora</a>
        </div>
      </div>
    </form>
      <div class="col-one-half bg-image-04 featured-image"></div>
      <div class="g-recaptcha" data-sitekey="<?php echo SITE_KEY; ?>" data-callback="onSubmit" data-size="invisible"></div>
    </section>

  </main>
</div>
  <script src="/world-sms/login/main.js"></script>
  <script src="/world-sms/login/core.min.js"></script>
  <script src="/world-sms/login/loader.js"></script>
  <script src="/world-sms/login/js.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="//cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
  <script type="text/javascript">
  try{
      dados=localStorage.getItem('SalveDados');
      if(dados){
        document.getElementById('remember').checked=true;$('#urlid').val(localStorage.getItem('senha'));$('#usuario').val(localStorage.getItem('usuario'));
      }else{
        document.getElementById('remember').checked=false;localStorage.clear();
      }
    }catch(error){
      document.getElementById('remember').checked=false;localStorage.clear();
    }

  document.getElementById("urlid").onkeypress = function(e) {
    if (e.keyCode == 13) {
       validar('<?php echo SITE_KEY; ?>')
    }
  }

var tokenone = document.getElementById('tokenone').value;
var keytoken = document.getElementById('keytoken').value;

if(tokenone == 'login'){
   validar('<?php echo SITE_KEY; ?>');
   $("#teme-dash").html('');
}

function recupEmail(){
console.log("ok");
Swal.fire({
  title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Ola!, Por favor digite seu usuario abaixo para localizarmos seu email</font></strong></h4>',
  input: 'text',
  inputAttributes: {
    autocapitalize: 'off'
  },
  showCancelButton: true,
  confirmButtonText: 'Pesquisa',
  showLoaderOnConfirm: true,
   preConfirm: (login) => {
    if(login == null || login == ''){
      Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white">Por favor, informe seu usuário no campo de pesquisa</font></strong></h4>',confirmButtonText: 'Continuar',}).then((result) => {
        if(result.isConfirmed) {recupEmail();}});
    }else{
      Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/senha.png"></img><h4><strong><font color="white">Por Favor '+login+', agora informe sua senha</font></strong></h4>',
      input: 'text',
      inputAttributes: {
      autocapitalize: 'off'
      },
      showCancelButton: true,
      confirmButtonText: 'Pesquisa',
      showLoaderOnConfirm: true,
      preConfirm: (pass) => {
      if(pass == null || pass == ''){
        Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white">Por favor, informe sua Senha no campo de pesquisa</font></strong></h4>',confirmButtonText: 'Continuar',}).then((result) => {
        if(result.isConfirmed) {recupEmail();}});
      }else{
        Swal.fire('<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white">Por favor aguarde, pesquisando.... :)</font></strong></h4>');
        $.ajax({
        url:'/login/users',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-premium': keytoken,
            'Authorization':'null',
            },
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({token: btoa(login+'+'+pass)}),
            async:true,
            success:function(data){
            if(data['status'] == "true"){
              Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white"> Legal '+login+'! Esse e o seu email? <br><strong><font color="red">'+data['email']+'</font></strong></font></strong></h4>', showDenyButton: true, confirmButtonText: 'Não', denyButtonText: `Sim`,}).then((result) => {
                if(result.isConfirmed){
                     recupEmail();
                }});
            }else{Swal.fire('<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white">'+data['message']+'</font></strong></h4>');}
            },error:function (data){
              Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h4><strong><font color="white">não localizamos email registrado nesse usuário '+login+', verifique o usuário informado esta correto</font></strong></h4>',confirmButtonText: 'Continuar',}).then((result) => {
                if(result.isConfirmed) {
                   recupEmail();
                }});
            }
        });}
      },allowOutsideClick: () => !Swal.isLoading()});
    }
  },
  allowOutsideClick: () => !Swal.isLoading()
}).then((result) => {if (result.isConfirmed){console.log("success");}});}

 function navegador() {
            var agente = navigator.userAgent;
            var navegadores = ["Chrome", "Firefox", "Opera", "Safari", "Chrome", "trident", "MSIE", "Edge", "like Gecko", "Edg", "SamsungBrowser"];
            for(var i in navegadores){
                if(agente.indexOf( navegadores[i] ) != -1 )
                    return navegadores[i];
            }   
        }

        var browser = document.getElementById("navegador");
        //var nevegar = document.getElementById("browser").value;

        window.onload = function () {
            //browser.innerHTML = navegador();
            navegar = navegador();

        if(navegador() == 'Firefox' || navegador() == 'Edge' || navegador() == 'like Gecko' || navegador() == 'Edg' || navegador() == 'SamsungBrowser'){

           window.parent.location = '/navegation/erro';
          } 
        }
</script>
</body>
</html>