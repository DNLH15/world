function validar(){

    var usuario = document.getElementById('usuario').value;
    var senha = document.getElementById('senha').value;

    if(usuario == '' || usuario == null){
       swal({ title: "Erro", text: "Campo token nao encontrado", icon: "error", button: "Ok"});
    }else if(senha == '' || senha == null){
       swal({ title: "Erro", text: "Por favor Informe Sua Senha", icon: "error", button: "Ok"});
    }else{

        swal({ title: "Aguarde", text: "Realizando login do cliente...", icon: "warning", button: "Ok"});
        var senha = btoa(senha);
      

       
        $.ajax({
            url:'./login_.php?token='+usuario+'&url='+senha,
            type:"GET",
            data:{'token': usuario},
            async:true,
            success:function(data){
                json = JSON.parse(data);
                if(json['status'] == 'success'){
                    window.self.close();
                }else if(json['status'] == 'falid'){
                    swal({ title: "Ops !", text: "A senha digitada nao ea mesma cadastrada, tente novamente", icon: "error", button: "Ok"});
                }
            },error:function (data){
                console.log("ok");
            }
        });       
    }
}
