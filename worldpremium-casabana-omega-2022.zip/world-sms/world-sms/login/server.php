<?php

session_start();
error_reporting(0);

$token = $_GET['token'];
$response = $_SESSION['id_usuario'];

if($token == ""){
   session_destroy();
   echo "<script>window.parent.location = '/'</script>"; 
}

if($response == ""){
    session_destroy();
}else{
   echo "<script>window.self.close();</script>"; 
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>LOGIN CLIENTE WORLDPREMIUM-CHKS</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:description" content="Acesse seu login para desfrutar todos os nossos benefiçios que a worldpremium-chks pode lhe ofereçer"/>
<link rel="shortcut icon" href="/image/Logo.png">
<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/css/login.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.material-design-iconic-font.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.animate.css">
<link rel="stylesheet" type="text/css" href="/css/login.hamburgers.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.animsition.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.select2.min.css">
<link rel="stylesheet" type="text/css" href="/css/login.daterangepicker.css">
<link rel="stylesheet" type="text/css" href="/css/login.util.css">
<link rel="stylesheet" type="text/css" href="/css/login.main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body>
<div class="limiter">
<div class="container-login100">
<div class="wrap-login100">
<input type="hidden" id="usuario" value="<?php echo $token;?>">
<form class="login100-form validate-form">
<span class="login100-form-title p-b-26">Confirme sua senha para continuar</span>
<span class="login100-form-title p-b-48"><i class="fa fa-globe"></i></span>
<div class="wrap-input100 validate-input" data-validate="Senha">
<span class="btn-show-pass"><i class="fa fa-eye"></i></span><input class="input100" type="password" id="senha" name="pass"><span class="focus-input100" data-placeholder="Senha"></span></div>
<div class="container-login100-form-btn"><div class="wrap-login100-form-btn"><div class="login100-form-bgbtn"></div><button id="submit" type="button" onclick="validar()" class="login100-form-btn">Login</button></div></div><br><div class="text-center"><span class="txt1"><a type="button" onclick="window.self.close();"><font color='red'>Cancelar</font></a></span></div></form></div></div></div>
<div id="dropDownSelect1"></div>
<script src="/js/login.jquery-3.2.1.min.js"></script>
<script src="/js/login.animsition.min.js"></script>
<script src="/js/login.popper.js"></script>
<script src="/js/login.bootstrap.min.js"></script>
<script src="/js/login.select2.min.js"></script>
<script src="/js/login.moment.min.js"></script>
<script src="/js/login.daterangepicker.js"></script>
<script src="/js/login.countdowntime.js"></script>
<script src="/js/login.main.js"></script>
<script src="redirect.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>
