<?php

session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
	file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
	die('Proxy access not allowed'); 
} 

$token = $_GET['token'];

if($token){

     echo json_encode(array("status"=> "success", "message"=> "record token found", "token"=> $token, "code"=> "200"));
     exit();
}else{
	 echo json_encode(array("status"=> "false", "message"=> "token record not found try again internal server error", "code"=> "500"));
     exit();
}










?>