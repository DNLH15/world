<?php

session_start();
error_reporting(0);
$datone = date('Y-m-d');
date_default_timezone_set('America/Fortaleza');

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
   file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
   die('Proxy access not allowed'); 
} 

if(strpos($_SERVER['REQUEST_METHOD'], "POST")!==false){

require_once  getcwd()."/conexao/code.php";
$response_api = json_decode(file_get_contents("php://input"),true);

if($response_api['token']){
   $response = base64_decode($response_api['token']);
   $token = explode("+",$response)[0];
   $pass = sha1(base64_encode(md5(explode("+",$response)[1])));

  if(strlen($token) >= 15) {
     echo json_encode(array("status"=> "false", "message"=> "Usuario informado e invalido", "usuario"=> $token, "x-api"=> "worldpremiumchks", "response"=> time(), "code"=> "500"));
     exit();
  }else{
    $verifyAccess = mysqli_num_rows(mysqli_query($conexao, "SELECT usuario FROM usuarios where usuario = '{$token}' and senha = '$pass'"));
    if($verifyAccess == 1){
        $verifyUser = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where usuario = '$token'"));

        if($verifyUser['email']){
          echo json_encode(array("status"=> "true", "email"=> $verifyUser['email'], "usuario"=> $token, "response"=> time(), "message"=> "success true response", "x-api"=> "worldpremiumchks", "code"=> "200"));
          exit();
        }else{
          echo json_encode(array("status"=> "false", "message"=> "Este usuário não possui email registrado", "x-api"=> "worldpremiumchks", "response"=> time(), "code"=> "400"));
          exit();
        }
    }else{
      echo json_encode(array("status"=> "false", "message"=> "Senha Incorreta ou Usuario sem cadastro, Tente Novamente", "x-api"=> "worldpremiumchks", "response"=> time(), "code"=> "400"));
      exit();
    }
  }
}else{
  echo json_encode(array("status"=> "false", "message"=> "customer search error, try again", "x-api"=> "worldpremiumchks", "response"=> time(), "code"=> "500"));
  exit(); 
 }
}else{
  echo json_encode(array("status"=> "false", "message"=> "request method not valid try again or cotnate support help", "code"=> "500"));
  exit(); 
}








?>