<?php

$db = explode("\\" , dirname(__FILE__));

$bancodedados = $db[sizeof($db) -1];
$username = "root";
$password = "";

try {
    $conn = new PDO('mysql:host=localhost;dbname='.$bancodedados, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  if (strpos($e , 'Unknown database') !==false){
    $conn = new PDO('mysql:host=localhost;', $username, $password);
    $conn->query("CREATE DATABASE {$bancodedados}");
  }
}

$dbh = new PDO('mysql:host=localhost;dbname='.$GLOBALS['bancodedados'], $GLOBALS['username'], $GLOBALS['password']);

$dbh->query("CREATE TABLE IF NOT EXISTS requetsIpblock (

        ip VARCHAR(30) NOT NULL,
        countBlock INT(200) NOT NULL,
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
);


function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}



function setlimite(){
    
    $dbh = new PDO('mysql:host=localhost;dbname='.$GLOBALS['bancodedados'], $GLOBALS['username'], $GLOBALS['password']);



    $ip = get_client_ip();
     $ip =  explode(".", $ip)[0].explode(".", $ip)[1];
    $r = $dbh->query("SELECT COUNT(*) AS total FROM requetsIpblock WHERE `ip` = '$ip'");

    $result = $r->fetch(PDO::FETCH_ASSOC);
    
    if ($result['total'] == 0){
        $exe = $dbh->query("INSERT INTO requetsIpblock (ip , countBlock , reg_date) VALUES ('$ip' , 0 , '".date("Y-m-d H:i:s")."')");

        if ($exe != true){
            // echo $exe;
        }
    }else{
        $r = $dbh->query("SELECT * FROM requetsIpblock WHERE `ip` = '$ip'");

        $result = $r->fetch(PDO::FETCH_ASSOC);

        $countBlock = $result['countBlock'] +1;

        $dbh->query("UPDATE requetsIpblock SET countBlock = $countBlock , reg_date = NOW() WHERE ip = '$ip'");

    }

}



function verify(){
    
  $dbh = new PDO('mysql:host=localhost;dbname='.$GLOBALS['bancodedados'], $GLOBALS['username'], $GLOBALS['password']);



    $ip = get_client_ip();
     $ip =  explode(".", $ip)[0].explode(".", $ip)[1];
    $r = $dbh->query("SELECT COUNT(*) AS total FROM requetsIpblock WHERE `ip` = '$ip'");

    $result = $r->fetch(PDO::FETCH_ASSOC);
    
    if ($result['total'] == 0){
        $exe = $dbh->query("INSERT INTO requetsIpblock (ip , countBlock , reg_date) VALUES ('$ip' , 0 , '".date("Y-m-d H:i:s")."')");

        if ($exe != true){
            //echo $exe;
        }
    }else{
        $r = $dbh->query("SELECT * FROM requetsIpblock WHERE `ip` = '$ip'");

        $result = $r->fetch(PDO::FETCH_ASSOC);


        if ($result['countBlock'] >= 5 and date("dm" , strtotime($result['reg_date'])) == date("dm")){
            error_reporting(0);
            header("HTTP/1.1 403");
            //die;
        }
    }



}


verify();
setlimite();