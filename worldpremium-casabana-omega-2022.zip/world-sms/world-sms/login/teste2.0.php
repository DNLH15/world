<?php 

$opcoes = array('http' =>
       array(
        'method'  => 'GET',
        'header'  => array('Content-Type: application/x-www-form-urlencoded','authorization: Basic dGVzdGU6dGVzdGU='),
    )
);
$contexto = stream_context_create($opcoes);

$result   = file_get_contents('https://worldpremiumchks.com/teste.php', false, $contexto);
