<?php

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

  if(strpos($ip_plubic,".")){  
     $ip_plubic = explode(".",$ip_plubic)[0].'.'.explode(".",$ip_plubic)[1];
  
  }else if(strpos($ip_plubic,":")){
     $ip_plubic = $ip_plubic;
  }else{
     $dd =  "Sem Informaçao";
  }


  $ip = $_SERVER['REMOTE_ADDR'];

if(strpos($ip,".")){
    
   $ip = explode(".",$ip)[0].'.'.explode(".",$ip)[1];
  
}else if(strpos($ip,":")){
   $ip = $ip;
}else{
   $dd =  "Sem Informaçao";
}


?>