<?php

session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
   file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
   die('Proxy access not allowed'); 
} 

if(strpos($_SERVER['REQUEST_METHOD'], "POST")!==false){
  
date_default_timezone_set('America/Fortaleza');
$acesso_time = date('Y-m-d H:i:s');
$response_api = json_decode(file_get_contents("php://input"),true);
$token = explode(".ey", $response_api['token'])[1];
$token = explode("undefined", base64_decode(base64_decode($token)))[0];
$token = explode("+", $token)[1];
$response = base64_decode(base64_decode(base64_decode(urldecode($token))));
$split = explode("+", $response);
$captcha = explode("/", $response)[1];


$usuario = explode("/", $split[1])[0];
$senha = $split[0];

define('SITE_KEY', '6Ld_h74UAAAAAJu_OC7Y8Yf1PJofb-qa0-aB4Xbs');
define('SECRET_KEY', '6Ld_h74UAAAAAGoyevR1yrnHPANAQQHecs7kZ_yD');

date_default_timezone_set("Brazil/East");
header("Content-Type: text/html; charset=utf-8"); 
$dat = date('Y-m-d'); 

if($usuario){

    function getCaptcha($SecretKey){
        $Response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".SECRET_KEY."&response={$SecretKey}");
        $Return = json_decode($Response);
        return $Return;
    }
    $Return = getCaptcha($captcha);
    
    if($Return->success == true && $Return->score > 0.5){
      require_once  getcwd()."/world-sms/login/salveip.php";
      $conexao = mysqli_connect("24.152.39.78", "root", "vpsbancoacessoA456#@casaty", "codebase") or die(json_encode(array("status"=> "server error", "message"=> "error communicating with server, refresh page or contact support help: support.contato@worldpremiumchks.com",  "code"=> "500")));
        if(empty($usuario) || empty($senha)) {
           echo json_encode(array("status"=> "false", "message"=> "token client validation error", "code" => "500"));
           exit();
          
        }

         $usuario = mysqli_real_escape_string($conexao, $usuario);
         $senha = mysqli_real_escape_string($conexao, $senha);
         $senha = sha1(base64_encode(md5($senha)));

        if(strpos($usuario,'@') && strpos($usuario,'.')){
           $query = "SELECT usuario FROM `usuarios` WHERE  email = '{$usuario}' and senha = '$senha'";
           $sql = "select * from usuarios where email = '{$usuario}' ";
        }else{
           $query = "select usuario from usuarios where usuario = '{$usuario}' and senha = '$senha'"; 
           $sql = "select * from usuarios where usuario = '{$usuario}' ";
        }

           $result = mysqli_query($conexao, $query);
           $row = mysqli_num_rows($result);

           $fim= mysqli_query($conexao, $sql);
           $dados= mysqli_fetch_assoc($fim);
           $date_time = $dados['data_time'];
           $id = $dados['id_usuario'];
           $saldo_db = $dados['base_saldo'];
           $nivel = $dados['nivel'];
           $access_key = $dados['access_key'];
           $usuario_id = $dados['usuario'];
           $email_id = $dados['email'];
           $token = explode("=",base64_encode(md5(rand(0000,9999)."+".$id)))[0];

          if(strpos($usuario,'@') && strpos($usuario,'.')){
              $idss = mysqli_query($conexao,"UPDATE `usuarios` SET  token='$token' WHERE email = '$usuario'");
          }else{
              $idss = mysqli_query($conexao,"UPDATE `usuarios` SET  token='$token' WHERE usuario = '$usuario'");
          }

        if(empty($access_key)){
            $fim = sha1(base64_encode(md5($id)));
              if(strpos($usuario,'@') && strpos($usuario,'.')){
                 $query = "UPDATE `usuarios` SET  access_key='$fim', dt_out = '$acesso_time' WHERE email = '$usuario'";
              }else{
                 $query = "UPDATE `usuarios` SET  access_key='$fim' , dt_out = '$acesso_time'  WHERE usuario = '$usuario'";
              }
          $result = mysqli_query($conexao, $query);
          $_SESSION['id_usuario'] = $fim;  
        }else{
          $_SESSION['id_usuario'] = $access_key;
       
        }

          $ipjson = md5(time());
      

    $date = date("d-m-Y");
    $usauriosdb = file_get_contents(getcwd().'/world-sms/login/keysaccess.json');
    $datadb = json_decode($usauriosdb, true);

    if (!$datadb[$access_key]){
        $datadb[$access_key] = ["dataTime" => $date];
        $datadb[$access_key]['ip'] = trim($ipjson);
        $datadb[$access_key]['token'] = $token;
    }else{
        $datadb[$access_key]['dataTime'] = $date;
        $datadb[$access_key]['ip'] = trim($ipjson);
        $datadb[$access_key]['token'] = $token;
    }
    
    $datadb[$access_key]['saldo'] = $saldo_db;
    $dsalva = json_encode($datadb,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
    $salva = file_put_contents(getcwd().'/world-sms/login/keysaccess.json', $dsalva);
    salveip($access_key);

        if($row == 1){
          
            if($saldo_db  == 0 || $saldo_db == 1 || $saldo_db < 0){

              $_SESSION['id_usuario'] = $access_key;
              $_SESSION['novato'] = true;
              $_SESSION['tokenid'] = $token;
      
              $query = "UPDATE `usuarios` SET dt_out = '$acesso_time'  WHERE access_key = '$access_key'";
              $result = mysqli_query($conexao, $query);
              $_SESSION['sem_saldo_dash'] = true;
              $_SESSION['novato'] = true;
              echo json_encode(array("status"=> "balance unavailable", "message"=> "customer without balance available", "cliente"=> $usuario, "code" => "200"));
              exit();
            }else if ($saldo_db > 0){

              $nome = "usuario_cookie";
              $valor = md5(md5($usuario));
              $expira = time() +22*3600;
              setcookie($nome, $valor, $expira);

              $ip = md5(time());
              $ip_plubic = md5(time());


                if(trim($ip) != trim($ip_plubic)){
                    if(strpos($usuario,'@')){
                       $ipsss = "UPDATE `usuarios` SET  ip_plubic = '$ip', dt_out = '$acesso_time'  WHERE email = '$usuario'";
                    }else{
                       $ipsss = "UPDATE `usuarios` SET  ip_plubic = '$ip', dt_out = '$acesso_time'  WHERE usuario = '$usuario'";
                    }
       
                    $result = mysqli_query($conexao, $ipsss);      
                }

                //sessao do tempo para expirar começa aqui....
                $tempolimite = 600; // equivale a 10 minutos
                $_SESSION['registro'] = time();
                $_SESSION['limite'] = $tempolimite;
                $_SESSION['logado'] = true;
                $_SESSION['id_usuario'] = $access_key;
                $_SESSION['usuario'] = $usuario_id;
                $_SESSION['novato'] = true;
                $_SESSION['Notificaçao'] = true;
                $_SESSION['tokenid'] = $token;
                echo json_encode(array("status"=> "true", "id"=> md5(base64_encode(md5($id))), "email"=> $email_id, "balance"=> $saldo_db, "cliente"=> $usuario_id, "message"=> "client successfully logged in", "code" => "200"));
                exit();                
            }  
        }else if($dados['id_usuario'] == ""){
            echo json_encode(array("status"=> "not registered", "message"=> "unregistered customer try again or create an account", "code" => "500"));
            exit();
        }else{
           echo json_encode(array("status"=> "incorrect password", "message"=> "password entered is incorrect", "code" => "500"));
           exit();
        }
    }else{
       echo json_encode(array("status"=> "Incorrect captcha", "message"=> "catpcha informed is incorrect try again", "code" => "500"));
       exit();
    }
}else{
   echo json_encode(array("status"=> "server error", "message"=> "internal server error please contact support: contato.suporte@worldpremiumchks.com", "code" => "500"));
   exit();
 }
}else{
  file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  echo json_encode(array("status"=> "error", "message"=> "method not recognized GET POST PUT", "code"=> "500"));
  exit();
}






?>
