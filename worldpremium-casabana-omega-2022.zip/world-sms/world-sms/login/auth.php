<?php

error_reporting(0);
session_start();


if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {

    die('Proxy access not allowed'); 
} 

$response = $_SESSION['id_usuario'];

if($response == ""){

if (!$_GET){
    // header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações !';

}


if (!isset($_GET['session'])){
    // header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações (400 - S) !!';
}


$params = json_decode(base64_decode($_GET['session']) , true);


if (empty($params)){

    $_SESSION['error'] = 'Erro ao carrega as informações ( 400 - P) !!';
    
}

$servers = [
    'server-one-worldpremiumchks.online',
    'server-two-worldpremiumchks.online',  
    'server-three-worldpremiumchks.online',
    '10.0.0.108',
    'localhost'
    
];

if (!in_array($params['header']['origin'] , $servers)){
    // header("Location: https://worldpremiumchks.com/");

    $_SESSION['error'] = 'Erro ao carrega as informações ( 502 - S)  !!';

}

$requestTime = $params['bory']['requestTime'];

$valideUser = intval($requestTime / 2 );

if (!in_array($valideUser , $params['bory']['user_id'])){
    // header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações (403 - U ) !!';

    
}

if ($params['bory']['requestExpire'] < time()){
    // header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações ( 400 - E) !!';
}


if ($params['bory']['password'] != ($requestTime * 2)){
    header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações ( 403 -p  ) !!';
}

function descrypt($string){
    $key = '3b9785b7b9213c7360b57accfa4f1f20';
    $c = base64_decode($string);
    $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
    $iv = substr($c, 0, $ivlen);
    $hmac = substr($c, $ivlen, $sha2len=32);
    $ciphertext_raw = substr($c, $ivlen+$sha2len);
    $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
    if (hash_equals($hmac, $calcmac))//PHP 5.6+ timing attack safe comparison
    {
        return $original_plaintext;
    }else{
      return false;
    }
}



$id_usuario = descrypt($params['bory']['secret']);

if (empty($id_usuario)){
    
    $_SESSION['error'] = 'Erro desconhecido , por favor tente novamente ( 523 ) ';
    
}

$servidor = "45.15.24.180";
$usuario = "root";
$senha = "sghdghds@dhgd#Terrordelas&*!171";
$dbname = "codebase";
$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname) or die ('Não foi possível conectar');

$sql = mysqli_query($conexao , "SELECT COUNT(*) as TOTAL FROM `usuarios` WHERE `access_key` = '$id_usuario'");
$total = mysqli_fetch_assoc($sql);

if ($total['TOTAL'] == 0 ){
    $_SESSION['error'] = 'Erro ao carrega as informações ( 404 ) !!';
}else if ($total['TOTAL'] == 1){
    
    $sql = mysqli_query($conexao , "SELECT * FROM `usuarios` WHERE `access_key` = '$id_usuario'");
    $dados = mysqli_fetch_assoc($sql);
    
    setcookie('usuario_cookie', (time() +22*3600), $id_usuario);

    $tempolimite = 600;
    
    $_SESSION['registro'] = time();
    
    $_SESSION['limite'] = $tempolimite;
    
    $_SESSION['logado'] = true;
    
    $_SESSION['usuario'] = $dados['usuario'];
    
    $_SESSION['novato'] = true;
    
    $_SESSION['id_usuario'] = $id_usuario;
    
    header("Location: https://world-sms.worldpremiumchks.com/cp/world-sms");
    die();
    
}else{
    // header("Location: https://worldpremiumchks.com/");
    $_SESSION['error'] = 'Erro ao carrega as informações ( 404 ) !!';

 }
}else{
   echo "<script>setTimeout(function(){ window.location = '/cp/world-sms'}, 2000) </script>"; 
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>AUTH</title>

	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<style type="text/css">
		body{
			color: #d3fbff;
			background-color: #1c1c1c;
		}

		.card{
			background-color: #313235;
			/*height: 160px;*/
			border-radius: 10px;
		}	

		.btn {
			width: 65px;
			border-radius: 8px;	
		}	

		.modal-content{
			background-color: #313235;
		}

		.form-control{
			color:#d3fbff ;
			background-color: #44454a;
		}

		.form-control:focus{
			background-color: #313235;
			color: #d3fbff;
		}

		.table{
			color:#d3fbff ;
		}
		.table-responsive{
			color:#d3fbff ;
			background-color: #313235;
		}

</style>


    
    <div class="container">
    		
    </div>

</body>
<script src="https://kit.fontawesome.com/4b324138d1.js" ></script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>

<?php  if (isset($_SESSION['error'])):?>
    <script type="text/javascript">
        swal({
            text: '<?php echo $_SESSION['error']?>',
            button: "Fecha",
            icon: "warning",
            title: "Oxe"
            }).then(function(){
            window.location.href = '/'
        });
    </script>
<?php endif;?>
</html>










