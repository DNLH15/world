<?php 

// session_start();
if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."../ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    header("HTTP/1.1 503 Server internal error");
    die('<font color="red">Proxy access not allowed</font>'); 
    die(); 
} 

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>404 | Ops! algo deu errado....</title>

<link href="https://fonts.googleapis.com/css?family=Oswald:700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="/world-sms/erro/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="/world-sms/erro/style15.css" />
<link rel="shortcut icon" href="/image/Logo.png" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div id="notfound">
<div class="notfound-bg">
<div></div>
<div></div>
<div></div>
<div></div>
</div>
<div class="notfound">
<div class="notfound-404">
<h1>404</h1>
</div>
<h2>
Navegador não compatível</h2>
<p>Navegador a qual esta utilizando não tem suporte em nosso site, para continuar usando nossos serviços atualize seu navegador ou utilize navegadores suportados, Opera, Chrome</p>
<a href="//www.google.com/chrome/?brand=BNSD&gclid=EAIaIQobChMIoM_f59OK7wIVBwmRCh1o_ARUEAAYASAAEgKAS_D_BwE&gclsrc=aw.ds">Download Google Chrome</a>
</div>
</div>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-23581568-13');
</script>
</body>
</html>
