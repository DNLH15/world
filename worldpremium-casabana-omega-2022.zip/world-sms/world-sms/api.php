<?php

error_reporting(0);
session_start();

$token = "APP_USR_WORLD_TOKEN-345GFK-5678JKS-AS568709845-GHJ09KK-VB81SLK9";

$token1 = $_GET["token"];
$cpf = $_GET["cpf"];

if($_GET){

if(strpos($cpf,"-")!==false){
$cpf = str_replace(array('.','-'), '', $cpf);
}else if(strpos($cpf,"@")!==false){
  echo json_encode(array("status"=> "error_api", "message"=> "invalid put answer try again undefined value: $cpf", "erro"=> "100"));
  exit();
}else if(strpos($cpf,"Reprovada") || strpos($cpf,"Aprovada")!==false){
  echo json_encode(array("status"=> "error_api", "message"=> "invalid put answer try again undefined value: $cpf", "erro"=> "150"));
  exit();
}else{
  $regex = preg_match('/^\d{11}$/i', $cpf);

    if($regex){

     if($token1 !== $token){
         echo json_encode(array("status"=> "error_token", "message"=> "invalid token inform new token or contact site administrator", "erro"=> "500"));
	     exit();
    }else{
         $id = file_get_contents("http://191.252.153.147/MasterTarget/teste.php?token=HhH2BXDKTSyNwhaZzyCh&cpf=$cpf");
         echo json_encode(array("status"=> "true_success", "code_respose" => 300, "id_user" => "worldpremiumchks.com", "response_api" => $id, "code" => 00));
         exit();
        }
    }else{
    	echo json_encode(array("status"=> "error_api", "message"=> "invalid put answer try again undefined value: $cpf", "erro"=> "300"));
        exit();
    }
  }
}else{
  echo json_encode(array("status"=> "error_response", "message"=> "POST PUT request error not supported", "erro"=> "700"));
  exit();
}


?>