<html>
<head>
<title>WORLDPREMIUM-CHKS</title>

<script>
window.parent.location = '../index.php';
window.self.close();
</script>

</head>
</body>
</html>