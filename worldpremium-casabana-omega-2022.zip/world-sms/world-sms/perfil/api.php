<?php

error_reporting(0);
session_start();

require_once  getcwd()."/world-sms/perfil/login_.php";

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

if ($_GET['action'] == "getliveskeys"){
    echo file_get_contents("https://api.worldpremiumchks.com/lives_client/getliveskey.php?access_key=".$_SESSION['id_usuario']);
}


if ($_GET['action'] == "getlives"){
    echo file_get_contents("https://api.worldpremiumchks.com/lives_client/getlives.php?access_key=".$_SESSION['id_usuario']."&checker=".urlencode($_GET['checker']));
}

if ($_GET['action'] ==  "delllive"){
    
    if (empty($_GET['id_live'])){
        die();
    }
    $id_live = $_GET['id_live'];
    $chk = $_GET['chk'];
    echo file_get_contents("https://api.worldpremiumchks.com/lives_client/gdelllive.php?id_live=".$id_live."&access_key=".$_SESSION['id_usuario']."&checker=".urlencode($chk));
}


if ($_POST['type'] == "alterperm"){
    $alter = $_POST['alter'];
    echo file_get_contents("https://api.worldpremiumchks.com/lives_client/perm.php?access_key=".$_SESSION['id_usuario']."&permision=".urlencode($alter));
}