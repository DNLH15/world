<?php 

session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

$id = $_SESSION['id_usuario'];

    $dados = mysqli_fetch_assoc(mysqli_query($conexao,"select * from usuarios where access_key = '{$id}'"));
    
    if($dados['base_saldo'] <= 0 || $dados['base_saldo'] == 1 || $dados['base_saldo'] == ""){
      $_SESSION['sem_saldo'] = true;  
    }

    $dados_tansacoes = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT valor FROM `transacoes` WHERE access_key ='$id' ORDER by valor"));
    
     if(empty($dados_tansacoes)){
        $dados_tansacoes['valor'] = 0;

    }
   
    $sql_tansacoes_order = "Select * from historicos  WHERE access_key ='$id' order by  data_transacao  desc";
    $fim_tansacoes_order= mysqli_query($conexao, $sql_tansacoes_order);
    $dados_tansacoes_order= mysqli_fetch_assoc($fim_tansacoes_order);
    
    
?>
<doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="/world-sms/image/Logo.png">
	<link rel="icon" type="image/png" sizes="96x96" href="/world-sms/image/Logo.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>WORLDPREMIUM-CHKS</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="icon" href="/world-sms/image/Logo.png">

    <!-- Canonical SEO -->
    <link rel="/world-sms/css/canonical" href="http://worldpremiumchks.com"/>

    <!-- Bootstrap core CSS     -->
    <link href="/world-sms/css/perfil.bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="/world-sms/css/perfil.animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="/world-sms/css/perfil.paper-dashboard.css" rel="stylesheet"/>
    <link href="/world-sms/css/perfil.style.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/world-sms/css/perfil.demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="/world-sms/css/perfil.themify-icons.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <!--Google Tag Manager (noscript)-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --> 

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://worldpremiumchks.com" class="simple-text">
                    WORLDPREMIUM-CHKS
                </a>
            </div>
        <ul class="nav">
         <li>
                    <a onclick='menu()' style='cursor: pointer;'>
                        <i class="fa fa-bars"></i>
                        <p>Menu Principal</p>
                    </a>
                </li>
                <li class="active">
                    <a href="/perfil/minha-conta">
                        <i class="fa fa-user"></i>
                        <p>Perfil</p>
                    </a>
                </li>
                
                <li>
                     <a target="_blank"  href='//worldpremiumchks.com/prices' style='cursor: pointer;'>
                        <i class="fa fa-shopping-cart"></i>
                        <p>Compra Creditos</p>
                    </a>
                </li>
                
                <li>
                    <a target="_blank"  onclick="actions()" style='cursor: pointer;'>
                        <i class="fa fa-shopping-cart"></i>
                        <p>Extratos</p>
                    </a>
                </li>
                 <li id='historico' >
                    <a onclick="lista_transacoes()" style='cursor: pointer;'>
                        <i class="fa fa-history"></i>
                        <p>Historico De Compra</p>
                    </a>
                </li>
                
                  <li  id='transacao'>
                    <a onclick="lista_pendig()" style='cursor: pointer;'>
                         <i class="fa fa-shopping-cart"></i>
                        <p>Pagamentos Pendente</p>
                    </a>
                </li>

                <li >
                    <a href='/perfil/amigos-compartilhados'>
                        <i class="fa fa-history"></i>
                        <p>Amigos Compartilhados</p>
                    </a>
                </li>

                <li >
                    <a href='/perfil/meus-sms'>
                        <i class="fa fa-commenting"></i>
                        <p>Meus SMS</p>
                    </a>
                </li>
                
                <li>
                    <a href="/goout">
                        <i class="fa fa-sign-out"></i>
                        <p>Sair</p>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="https://t.me/WORLDPREMIUMCHKS">
                        <i class="fa fa-commenting"></i>
                        <p>Contato</p>
                    </a>
                </li>
                
            </ul>
        </div>
    </div>
<input type='hidden' id='id_usuario' value='<?php echo $_SESSION['id_usuario'] ?>'>
    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid" >
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" id='fixa'>
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Perfil usuario</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-bell"></i>
                                    <p class="notification">1</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Sem notificaçoes</a></li>
                                
                              </ul>
                            </li>
						<li>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

        <div class="content" >
            <div class="container-fluid" >
                <div class="row" id='conteudo'>
                    <div class="col-lg-4 col-md-5">
                        <div class="card card-user">
                            <div class="image">
                                <img src="https://images.unsplash.com/photo-1522124624696-7ea32eb9592c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                  <img class="avatar border-white" src="/world-sms/image/icone.png" alt="..."/>
                                  <h4 class="title"><?php echo $dados['nome'];?><br />
                                     <a href="#"><small>@<?php echo $dados['usuario'];?></small></a>
                                  </h4>
                                </div>
                                <p class="description text-center">
                                    Dados do perfil atualizado 
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <div class="row">
                                    <div class="col-md-3 col-md-offset-1">
                                        <h5><?php echo $dados['base_saldo'];?><br /><small>saldo</small></h5>
                                    </div>
                                    <div class="col-md-4">
                                        <h5>0<br /><small>bloqueado</small></h5>
                                    </div>
                                    <div class="col-md-3">

                                        <h5><?php 
                                          $valor = $dados_tansacoes['valor']; 

                                          if($valor == ""){
                                             $valor = "0";
                                          }else{
                                          }
                                          echo $valor; ?><br /><small>pedente</small></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                        <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Ultima Movimentaçao</h4>
                            </div>
                            <?php
                            if(!empty($dados_tansacoes_order)):
                            ?>
                            <div class="content">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Id da Transação</label>
                                                <li><?php echo $dados_tansacoes_order['id_transacao']?></li>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Data Da Transação</label>
                                                <li><?php echo $dados_tansacoes_order['data_transacao']?></li>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Status Da Transação </label>
                                               <li><?php echo $dados_tansacoes_order['status']?></li>
                                            </div>
                                        </div>
                                    </div>
<hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Valor </label>
                                               <li><?php echo $dados_tansacoes_order['valor']?></li>
                                            </div>
                                        </div>
                                        <?php
                                        else:
                                            echo "<br><br>";
                                            echo "<span style='font-size:25px; margin:20px;'  >Opss ! , Ainda Não Há Nenhuma Transação !!</span>";
                                            echo "<br><br>";
                                        endif;
                                        ?>
                                        </div>
                                    </div>
                                 
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>



        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://worldpremiumchks.com">Worldpremium-chks</a>
                </div>
            </div>
        </footer>
    </div>
</div>


     
     
</body>

    <script src="/world-sms/js/perfil.jquery.min.js" type="text/javascript"></script>
    <script src="/world-sms/js/perfil.bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="/world-sms/js/perfil.bootstrap-checkbox-radio.js"></script>

    <!--  Charts Plugin -->
    <script src="/world-sms/js/perfil.chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="/world-sms/js/perfil.bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
    <script src="/world-sms/js/perfil.paper-dashboard.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="/world-sms/js/perfil.demo.js"></script>
    <script src="/world-sms/js/perfil.jquery.sharrre.js"></script>

<script>
      // Facebook Pixel Code Don't Delete
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','//connect.facebook.net/en_US/fbevents.js');

      try{
        fbq('init', '111649226022273');
        fbq('track', "PageView");

      }catch(err) {
        console.log('Facebook Track Error:', err);
      }
    </script>
    <noscript>
      <img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=111649226022273&ev=PageView&noscript=1"
      />
    </noscript>




<script type="text/javascript">
var btn = document.getElementById('fixa');
var id_usuario = document.getElementById('id_usuario').value;

      function lista_transacoes(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
    $.ajax({
        url: "transacoes",
        type:"POST",
        data:{"id_usuario":id_usuario},
        async:false,
        success:function(data){
            
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
}
function lista_pendig(){
    $("#conteudo").fadeOut("slow");
    $.ajax({
        url: "peding",
        type:"POST",
        data:{"id_usuario":id_usuario},
        async:false,
        success:function(data){
           
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();

        }
    });
    
  
}

  function refresh(id_transacao,merchant_order_id){
        $.ajax({
            url:"verifica",
            type:"POST",
            data:{"id_transacao":id_transacao,"merchant_order_id":merchant_order_id,"id_usuario":id_usuario},
            
            async:true,
            success:function(data){
                console.log(data);
                json= JSON.parse(data);
                if(json['status'] == 'true'){
                            swal({ title: "Success", text: "Sua Compra foi efetuada com sucesso !!, basta refazer seu login !! " , icon: "success",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.location.href = '/goout';
                            console.log('sair');
                            }
                            
                            });
                } else  if(json['status'] == 'cancelled'){
                            swal({ title: "Atençao", text: "Sua Compra Foi Cancelada Entre Em Contato Com Mercado pago" , icon: "warning",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.location.reload();
                            console.log('sair');
                            }
                            
                            });
                }else{
                    var status = json['msg'];
                    swal({ title: "Atençao", text: "Sua Compra esta no status: "+status+" , Se você acha que um erro entre em contato com um dos admins !" , icon: "warning",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.location.reload();
                            console.log('sair');
                            }
                            
                            });
                }
            },
            error:function(error){
                console.log(error);
            }
        });
    }
    


function menu(){
    $.ajax({
        url:"menu",
        type:"POST",
        data:{"id_usuario":id_usuario},
        success:function(data){
            // console.log(data);
            json = JSON.parse(data);
            if(json['status'] == 'false'){
                 swal({ title: "Atençao", text: "Você ainda nao possuir credito suficiente para acessa os chks" , icon: "warning",closeOnClickOutside : false, button: true})
                            .then((willDelete) => {
                            if (willDelete) {
                            // console.log('sair');
                            }
                            
                            });
                            
            }else  if(json['status'] == 'true'){
                  swal({ title: "Success", text: "VOCÊ SERA REDIRECIONADO PARA OS CHKS" , icon: "success",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.parent.location = '/cp/world-sms';
                            // console.log('sair');
                            }
                            
                            });
            }else{
                 swal({ title: "ERROR", text: "Ocorreu um Errro, relize o login novamente" , icon: "error",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.parent.location = '/goout';
                            // console.log('sair');
                            }
                            
                            });
            }
        },error:function(error){
            console.log(error);
        }
    });
}


function compra_credito(){
    
     $("#conteudo").html('<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center"><div class="content"><p>Escolha Os Preços Para Continua</p><select class="form-control" id="valores"><option value="selece" >Selecione o Valor </option><option value="25.00">25 Reais  == 50 de credito!!</option><option value="45.00">45 Reais  == 100 de credito!!</option><option value="65.00">65 Reais == 150 de credito!!</option><option value="85.00">85 Reais == 200 de credito!!</option><option value="105.00">105 Reais == 250 de credito!!</option><option value="125.00">125 Reais  == 300 de credito!!</option></select><br><br><button id="compraa" class="btn btn-primary" onclick="compra_fim(id_usuario)">Continua</button></div></div></div></div>');
            // $("#conteudo").fadeIn("slow");
            btn.click();
            
}

function actions(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
     var usuario =  $('#id_usuario').val();
    $.ajax({
        url: "detalhes",
        type:"POST",
        data:{"ugdfhjsdgdjh65-kjshdkj55etdssg":usuario},
        async:false,
        success:function(data){
            
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
}

$("#getlives").click( function(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
     var usuario =  $('#id_usuario').val();
    $.ajax({
        url: "lives",
        type:"get",
        async:false,
        success:function(data){
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
});

function compra_fim(id_usuario){
    var valor = document.getElementById('valores').value;

  if(valor == '' || valor == null){
    swal({ title: "Erro", text: "Por favor Informe Valor (Creditos) Para Realizar Sua Compra", icon: "error", button: "Ok"});
  }else{
    // console.log(id_usuario,valor);
    $('#compraa').attr('disabled', true);
    $.ajax({
        
        url:"https://worldpremiumchks.com/tabela/api.php",
        type:"POST",
        data:{"valor":valor,"access_key":id_usuario,"submit":"submit"},
        async:true,
        success:function(data){
            // console.log(data);
            json = JSON.parse(data);
            if (json['status'] == 'true') {
            
               swal({ title: "Sucesso", text: "Agora você sera redirecionado para mercado pago", icon: "success", button: true,closeOnClickOutside : false, })
                .then((willDelete) => {
                if (willDelete) {
                
                 window.location = json['url'];
                 
                }
                
            }); 
            	
            }
        },error:function(error){
            console.log(error);
        }
        
    });
  }
}
function compra_credito_1(){
    swal({ title: "Erro", text: "Sistema desabiltado para reparo!", icon: "error", button: "Ok"});
}
</script>


<?php 
if(isset($_SESSION['sem_saldo'])):
?>

<script type="text/javascript">
swal({ title: "Opss !!", text: "Você Nâo Possuir Saldo Suficiente Para Usa Nossos Serviços!", icon: "error", button: "Ok"});
</script>

<?php
unset($_SESSION['sem_saldo']);
 endif;
?>



</bod>
</html>
