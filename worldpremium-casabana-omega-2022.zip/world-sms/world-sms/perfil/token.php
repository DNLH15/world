<?php

session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

if($_POST["senha"]){
  
  $senha = sha1(base64_encode(md5($_POST["senha"])));
  $senha_nova = sha1(base64_encode(md5($_POST["senha-nova"])));
  $id = $_SESSION['id_usuario'];

    $verifyKey = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios WHERE access_key = '$id'"));

    if($verifyKey['usuario']){

        if($senha == ""){
           die(json_encode(array("status"=> "error", "message"=> "campo senha antiga nao deve esta vazio, tente novamente", "code"=> "500")));
           exit();
        }else if($senha_nova == ""){
          die(json_encode(array("status"=> "error", "message"=> "campo nova senha nao deve esta vazio, tente novamente", "code"=> "500")));
          exit();
        }else{
          $verifiySenha = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios WHERE senha = '$senha'"));
          if($verifiySenha['usuario']){
                 $atualizarSenha = mysqli_query($conexao,"UPDATE usuarios SET senha = '$senha_nova', modified=NOW() WHERE access_key = '$id'");

              if(mysqli_affected_rows($conexao)){
                  die(json_encode(array("status"=> "true", "message"=> "sua senha foi alterada com sucesso", "code"=> "500")));
                  exit();
              }else{
                 die(json_encode(array("status"=> "error", "message"=> "não foi possível alterar sua senha, contate adiministrador do site informando código erro 5003 para solucionar este erro", "code"=> "500")));
                 exit();
              }
          }else{
            die(json_encode(array("status"=> "error", "message"=> "Sua senha antiga não e a mesma senha atual cadastrado em nosso painel. por favor, verifique sua senha", "code"=> "500")));
            exit();
          }
        }
    }else{
       die(json_encode(array("status"=> "error", "message"=> "token worldpremiumchks não localizado, tente novamente", "code"=> "500")));
       exit();
    }
}else{
  die(json_encode(array("status"=> "error", "message"=> "token worldpremiumchks não localizado, tente novamente", "code"=> "500")));
  exit();
}




?>