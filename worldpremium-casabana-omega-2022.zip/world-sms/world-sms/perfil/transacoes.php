<?php
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

require_once  getcwd()."/world-sms/perfil/login_.php";
require_once  getcwd()."/conexao/code.php";

    $id = $_POST['id_usuario'];

    $sql = "SELECT * FROM `historicos` WHERE access_key = '$id'";
    $fim= mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);
    
     if(empty($dados)){
        echo "<span style=' padding:20px; font-size:25px; margin:20px;'  >Opss ! , Ainda Não Há Nenhuma Transação Pendente!!</span>";
        exit();
    }
    
?>
<html>
<head>
</head>
<body>
<table class="table table-hover" id='corpo'>
  <thead class ='thead'>
    <tr>
      <th scope="col">Id da Transação</th>
      <th scope="col">Data da Transação</th>
      <th scope="col" >status</th>
      <th scope="col">valor</th>
      
      
      
    </tr>
  </thead>
  <tbody class='tbody'>
    <tr>
        
  
  
      <?php
        $total = 0;
        
      do{
          
       $total ++;
       
    ?>

    <td><?php echo $dados['id_transacao']; ?></td>
    <td><?php echo $dados['data_transacao']; ?></td>
    <td><?php echo $dados['status']; ?></td>
    <td><?php echo $dados['valor']; ?></td>
  </tr>
      <?php

      } while($dados = mysqli_fetch_assoc($fim));
      
    ?>

  </tbody>
</table>
<hr style='height:10px color="white";'>
