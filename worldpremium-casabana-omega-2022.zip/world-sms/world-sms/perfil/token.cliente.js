
function validar(){
  
  var usuario = document.getElementById('usuario').value;
  var senha = document.getElementById('senha').value;
  var senha_nova = document.getElementById('senha_nova').value;

if(usuario == '' || usuario == null){
    swal({ title: "Erro", text: "Por favor Campo (Usuario) nao deve esta vazio ", icon: "error", button: "Ok"});
}else if(senha == '' || senha == null){
    swal({ title: "Erro", text: "Por favor Campo (Senha Antiga) nao deve esta vazio ", icon: "error", button: "Ok"});
}else if(senha_nova == '' || senha_nova == null){
    swal({ title: "Erro", text: "Por favor Campo (Senha Nova) nao deve esta vazio ", icon: "error", button: "Ok"});
}else{

	swal({title: "Atenção", text: "Deseja continuar alteração dados sua conta  "+usuario+ " ? ", icon: "warning", buttons: true,dangerMode: true,})
        
        .then((willDelete) => {
            if (willDelete) {

            	    var token = usuario+"_"+senha+"_"+senha_nova;

            	        $.ajax({
                          url:'token.php',
                          type:"POST",
                          data:{'cliente_response': btoa(btoa(btoa(token)))+"___"+btoa(token)},
                          async:true,
                          success:function(data){
                          json = JSON.parse(data);
                            if(json['status'] == 'request_error') {
                                swal({ title: "Erro", text: "erro ao contactar solicitaçao tente novamente", icon: "error", button: "Ok"});
                            }else if(json['status'] == 'true_success') {
                                swal({ title: "Sucesso", text: "Dados Alterados com Sucesso !", icon: "success", button: "Ok"});
                                audio.play();
                            }else if(json['status'] == 'error_api_response') {
                                swal({ title: "Erro", text: "Erro ao validar dados da conta tente novamente", icon: "error", button: "Ok"});
                            }else if(json['status'] == 'error_invalid_password') {
                                swal({ title: "Ops!", text: "Senha informada nao ea senha atual cadastrado, tente novamente", icon: "error", button: "Ok"});
                            }else if(json['status'] == 'error_api') {
                                swal({ title: "Ops!", text: "Erro no servidor interno tente novamente mais tarde", icon: "error", button: "Ok"});
                            }

                          },error:function (data){
                            console.log("ok");
                          }
                        });
            }
        });

    }

}