<?php
error_reporting(0);
session_start();

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

require_once  getcwd()."/world-sms/perfil/login_.php";

date_default_timezone_set("america/Fortaleza");

require_once  getcwd()."/conexao/code.php";

$user = trim($_SESSION['id_usuario']);

$sql = "SELECT * FROM `usuarios` WHERE access_key ='$user'";
$transacoes= mysqli_query($conexao17, $sql);
$dados = mysqli_fetch_assoc($transacoes);

 $dt_out =  $dados['dt_out'];

if($dt_out === '0000-00-00 00:00:00'){
    $data_acc = 'Usuario Ainda Nao Fez Login';
    $hora = ' ';
    $acesso = $data_acc;
    
}else{
    $hora = explode(' ',$dt_out)[1];
    $data_acc = explode(' ',$dt_out)[0];
     $data_acc =  date('d/m/Y',strtotime($data_acc));
    
    $acesso = " $data_acc - $hora";
}


$access_key = $dados['access_key'];
              
$sql_transa = "SELECT * FROM `historicos` WHERE access_key ='$access_key'";
$resul_transa = mysqli_query($conexao17,$sql_transa);
$rows_transa = mysqli_fetch_assoc($resul_transa);


if(empty($rows_transa['id_transacao'])){
    $rows_transa['id_transacao'] = "sem Transaçao"; 
}
                
if($dados['total_venda'] == 30){
    $venda_saldo = "50";
}else if($dados['total_venda'] == 50){
    $venda_saldo = "100";
}else if($dados['total_venda'] == 70){
    $venda_saldo = "150";
}else if($dados['total_venda'] == 90){
    $venda_saldo = "200";
}else if($dados['total_venda'] == 110){
    $venda_saldo = "250";
}else if($dados['total_venda'] == 130){
    $venda_saldo = "300";
}else{
  $venda_saldo = "Sem registro do valor";
}

$comsafa =  $dados['usuario'];
$result_cursos = "SELECT * FROM `creditos` WHERE `usuario` = '$comsafa' ORDER BY `data_usuario` ASC";
$resultado_cursos = mysqli_query($conexao17, $result_cursos);

$res = mysqli_fetch_assoc($resultado_cursos);

    
?>
<!DOCTYPE HTML>
<html lang="pt-br">  
    <head>  
        <meta charset="utf-8">
        <title>WORLDPREMIUM-CHKS</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

     <!--Canonical SEO -->
    <link rel="canonical" href="http://worldpremiumchks.com"/>

     <!--Bootstrap core CSS -->    
    <link href="/world-sms/css/perfil.bootstrap.min.css" rel="stylesheet" />

     <!--Animation library for notifications -->  
    <link href="/world-sms/css/perfil.animate.min.css" rel="stylesheet"/>

      <!--Paper Dashboard core CSS -->   
    <link href="/world-sms/css/perfil.paper-dashboard.css" rel="stylesheet"/>

    <link href="/world-sms/css/perfil.demo.css" rel="stylesheet" />

     <!-- Fonts and icons   -->  
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="https://cliente.worldpremiumchks.com/perfil/themify-icons.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/b88f04064b.js"></script>
    </head>
    <style type="text/css">
        .card{
            margin: 1%;
        }
    </style>
    <body>
    <?php if($dados == ""){ 
      echo '<div class="notification is-danger">
                <div class="text-center"><br>
                <h4><font color= "red"><i> NAO FOI POSSIVEL PROCESSAR (ERRO KEY)<i></font></h4>
                <br><br>
                <a href="/">Voltar</a>
           </div>';

    }else{?>
    
        <div class="col-lg-12 col-md-7">
            <div class="card">
                    <br>
                    <h4 style="text-align: center;">EXTRATO DO USUARIO <?php echo $dados['usuario'];?></h4>


                <div class="card-body" style="margin-left: 5%;">
                    <label>Nome: </label><i> <?php echo $dados['nome'];?></i><br>    
                    <label>Usuario: </label><i> <?php echo $dados['usuario'];?></i><br>    
                    <label>E-mail: </label><i> <?php echo $dados['email'];?></i><br> 
                    <label>Data Cadastro: </label><i> <?php echo date("d/m/Y",strtotime($dados['data_cadastro'])); ?></i><br>
                    <label>Ultimo Acesso: </label><i> <?php echo $acesso ?> </i><br><br>
                    <hr>
                    <b>ULTIMA COMPRA DE SALDO REALIZADA</b>
                    <hr>
                    <label>ID Da Transaçao </label><i> <?php echo $rows_transa['id_transacao'];?></i><br>       
                    <label>Status Da compra: </label><i> <?php echo $rows_transa['status'];?></i><br>
                    <label>External Refereçe: </label><i> <?php echo $dados['access_key'];?></i><br>
                    <label>Valor Da Compra: </label><i> <?php echo $dados['total_venda'];?></i><br>
                    <label>Saldo Comprado: </label><i> <?php echo $venda_saldo ?> (credito)</i><br>
                    <label>Logins Aprovados: </label><i> <?php echo $dados['login_aprovadas'];?></i><br>
                    <label>Ccs Aprovados: </label><i> <?php echo $dados['ccs_aprovadas'];?></i><br>
                    <label>Saldo Atual: </label><i><?php echo $dados['base_saldo'];?> (credito)</i><br>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-7">
            <div class="card">
                    <br>
                    <h4 style="text-align: center;">Ultima Movimentação Creditos</h4>


                <div class="card-body" style="margin-left: 5%;">
                    <?php $uses =  0;
                        while($dados_tansacoes_order = mysqli_fetch_assoc($resultado_cursos)){ 
                            
                            $saldototalen += $dados_tansacoes_order['saldo_id'];
                            $uses ++;
                            $cliente = $dados_tansacoes_order['cliente_id'];
                            $data = date('d/m/Y', strtotime($dados_tansacoes_order['data_usuario']));
                            $saldo = $dados_tansacoes_order['saldo_id'];
                        }?>
                    
                    
                        <hr>
                        <div class="d-flex justify-content-center">
                            <div class="row"><b>Foi Feito Um Total De</b>: <?php echo  $uses; ?><b> Envios , Somados e um toltal de</b>: <?php echo  $saldototalen; ?> <b>(creditos) , abaixo o ultimo envio!</b>
                            </div>
                            <hr>
                            
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Cliente Compartilhado (s)</label>
                                        <li><?php echo $cliente;?></li>
                                </div>
                            </div>
                    
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Saldo Compartilhado</label>
                                    <li><?php echo $saldo;?> Creditos</li>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Data Entrega Da Transação </label>
                                        <li><?php echo $data; ?></li>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-7">
            <div class="card">
                    <br>
                    <h4 style="text-align: center;">HISTORICO DE ACESSOS</h4>


                <div class="card-body" style="margin-left: 5%;">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">IP</th>
                                    <th scope="col">DISPOSITIVO</th>
                                    <th scope="col">DATA</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sessions = json_decode(file_get_contents("../login-usuario/sessions.json"),true)[$user];
                                foreach ($sessions as $key => $value):?>
                                    <tr>
                                        <th scope="row"><?php $key++; echo $key?></th>
                                        <td><?php echo $value['ip']?></td>
                                        <td><?php echo base64_decode($value['useragent'])?></td>
                                        <td><?php echo date("d/m/Y H:i:s" , $value['time'])?></td>
                                    </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                    <br>
                </div>
            </div>
        </div>

    <?php }?>
      <!--Footer-->
  
    </body>
</html>
