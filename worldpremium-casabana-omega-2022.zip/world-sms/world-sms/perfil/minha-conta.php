<?php 
session_start();
error_reporting(0);

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

$id = $_SESSION['id_usuario'];

    $sql = "select * from usuarios where access_key = '{$id}' ";
    $fim= mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);

    if($dados['base_saldo'] <= 0 || $dados['base_saldo'] == 1){
       $_SESSION['sem_saldo'] = true;
       $response = '0';
       $id = '#';
       $id2 = 'onclick="erro()"';
    }else{
       $response = '1';
       $id = '/cp/world-sms';
       $id2 = '';
    }

    $token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.'.base64_encode('{"id":"'.$id.'","usuario":"'.md5(base64_decode(hash('sha256', (get_magic_quotes_gpc() ? stripslashes($id) : $id)).''.$dados['usuario'])).'"}');

if (!$_GET){
    header("Location: ?token=$token");
}

?>
<doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <script src="https://kit.fontawesome.com/b88f04064b.js"></script>
    <link rel="apple-touch-icon" sizes="76x76" href="/world-sms/image/Logo.png">
    <link rel="icon" type="img/png" href="/world-sms/image/Logo.png">

    <title><?php echo $dados['usuario'];?> - MINHA CONTA</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="icon" href="/world-sms/image/Logo.png">
    <!-- Canonical SEO -->
    <link rel="/world-sms/css/canonical" href="http://worldpremiumchks.com"/>

    <!-- Bootstrap core CSS     -->
    <link href="/world-sms/css/perfil.bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="/world-sms/css/perfil.animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="/world-sms/css/perfil.paper-dashboard.css" rel="stylesheet"/>
    <link href="/world-sms/css/perfil.style.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/world-sms/css/perfil.demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="/world-sms/css/perfil.themify-icons.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--<script src="//code-sa1.jivosite.com/widget/PMWits2AqP" async></script>--->
</head>
<body>
  <!--Google Tag Manager (noscript)-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --> 

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
        Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
        Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://worldpremiumchks.com" class="simple-text">
                    WORLDPREMIUM-CHKS
                </a>
            </div>
        <ul class="nav">
         <li>
                    <a <?php echo $id2; ?>href='<?php echo $id; ?>' style='cursor: pointer;'>
                        <i class="fa fa-bars"></i>
                        <p>Menu Principal</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="fas fa-user"></i>
                        <p>Perfil</p>
                    </a>
                </li>
                
                 <li >
                    <a href='/perfil/meu-extrato'>
                        <i class="fas fa-history"></i>
                        <p>Historicos De Compra</p>
                    </a>
                </li>
                
                <li>
                    <a target="_blank"  onclick="actions()" style='cursor: pointer;'>
                        <i class="fas fa-file-pdf"></i>
                        <p>Extratos</p>
                    </a>
                </li>
                
                
                 <li >
                    <a onclick="rank()" style='cursor: pointer;'>
                        <i class="fa fa-industry"></i>
                        <p>Rank</p>
                    </a>
                </li>

                <li>
                    <a target="_blank"  href='//worldpremiumchks.com/prices' style='cursor: pointer;'>
                        <i class="fas fa-shopping-cart"></i>
                        <p>Compra Creditos</p>
                    </a>
                </li>

                <li >
                    <a href='/perfil/amigos-compartilhado'>
                        <i class="fas fa-history"></i>
                        <p>Amigos Compartilhados</p>
                    </a>
                </li>
                <li >
                    <a href='/perfil/meus-sms'>
                        <i class="fa fa-commenting"></i>
                        <p>Meus SMS</p>
                    </a>
                </li>
                
                <li>
                    <a href="/goout">
                        <i class="fa fa-sign-out"></i>
                        <p>Sair</p>
                    </a>
                </li>
                
                
                <li>
                    <a target="_blank" href="https://t.me/WORLDPREMIUMCHKSCENTRAL">
                        <i class="fa fa-commenting"></i>
                        <p>Contato</p>
                    </a>
                </li>
                <li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" id='fixa'>
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Perfil usuario</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fas fa-bell"></i>
                                    <p class="notification">1</p>
                                    <p>Notifications</p>
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Sem notificaçoes</a></li>
                                
                              </ul>
                            </li>
                        <li>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

        <div class="content">
            <div class="container-fluid" >
                <div class="row" id='conteudo'>
                    <div class="col-lg-4 col-md-5">
                        <div class="card card-user">
                            <div class="image">
                                <img src="https://images.unsplash.com/photo-1522124624696-7ea32eb9592c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                  <img class="avatar border-white" src="/world-sms/image/icone.png" alt="..."/>
                                  <h4 class="title"><?php echo $dados['nome'];?><br />
                                     <a href="#"><small>@<?php echo $dados['usuario'];?></small></a>
                                  </h4>
                                </div>
                                <p class="description text-center">
                                    Dados do perfil atualizado 
                                </p>
                            </div>
                            <hr>
                            <div class="text-center">
                                <div class="row">
                                    <div class="col-md-3 col-md-offset-1">
                                        <h5><?php echo $dados['base_saldo'];?><br /><small>saldo</small></h5>
                                    </div>
                                    <div class="col-md-4">
                                        <h5>0<br /><small>bloqueado</small></h5>
                                    </div>
                                    <div class="col-md-3">
                                        <h5>0<br /><small>pedente</small></h5>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="usuario" value="<?php echo $dados['usuario'];?>">
                            
                        </div>
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Precisa de ajuda?</h4>
                            </div>
                            <div class="content">
                                <ul class="list-unstyled team-members">
                                            <li>
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <div class="avatar">
                                                            <img src="/world-sms/image/placeholders/avatars/03.png" alt="Circle Image" class="img-circle img-no-padding img-responsive">
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        ADM SOMBRIO
                                                        <br />
                                                        <span class="text-muted"><small>Offiline</small></span>
                                                    </div>

                                                    <div class="col-xs-3 text-right">
                                                        <btn><a href="https://T.me/ADMSOMBRIO" target="_blank" class="btn btn-sm btn-success btn-icon"><i class="fa fa-envelope"></i></a></btn>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <div class="avatar">
                                                            <img src="/world-sms/image/placeholders/avatars/02.png" alt="Circle Image" class="img-circle img-no-padding img-responsive">
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        TERROR-CHKS
                                                        <br />
                                                        <span class="text-success"><small>Offiline</small></span>
                                                    </div>

                                                    <div class="col-xs-3 text-right">
                                                        <btn><a href="https://T.me/adm_terror" target="_blank" class="btn btn-sm btn-success btn-icon"><i class="fa fa-envelope"></i></a></btn>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <div class="avatar">
                                                            <img src="/world-sms/image/placeholders/avatars/01.png" alt="Circle Image" class="img-circle img-no-padding img-responsive">
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        DNLH
                                                        <br />
                                                        <span class="text-danger"><small>Online</small></span>
                                                    </div>

                                                    <div class="col-xs-3 text-right">
                                                        <btn><a href="https://T.me/DNLH15" target="_blank" class="btn btn-sm btn-success btn-icon"><i class="fa fa-envelope"></i></a></btn>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Editar Perfil</h4>
                            </div>
                            <div class="content">                                   
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Nome</label>
                                                <div id="p1"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Usuario</label>
                                                <input type="text" class="form-control border-input"  placeholder="usuario" disabled value="<?php echo $dados['usuario'];?>" required autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email </label>
                                                <input type="email" class="form-control border-input" name="email" placeholder="Email" disabled value="<?php echo $dados['email'];?>" required autofocus>
                                            </div>
                                        </div>
                                    </div>
                                     <input type='hidden' id='id_usuario' value='<?php echo $_SESSION['id_usuario'] ?>'>
                                     <input type='hidden' id='response' value='<?php echo $response; ?>'>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Senha</label>
                                                <div id="p2"></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Confirmar Senha</label>
                                                <div id="p3"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Data de cadastro</label>
                                                <input type="text" class="form-control border-input" disabled placeholder="Company" value="<?php echo date("d/m/Y",strtotime($dados['data_cadastro'])); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                         <div id="p4"></div>
                                    </div>
                                    <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="/">
                                Worldpremium-chks
                            </a>
                        </li>
                        <li>
                            <a href="https://t.me/WORLDPREMIUMCHKSCENTRAL">
                               Quem somos
                            </a>
                        </li>
                        <li>
                            <a href="https://t.me/WORLDPREMIUMCHKSCENTRAL">
                                Contato
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://worldpremiumchks.com">Worldpremium-chks</a>
                </div>
            </div>
        </footer>
    </div>
</div>
</body>

    <!--   Core JS Files   -->
    <script src="/world-sms/js/perfil.jquery.min.js" type="text/javascript"></script>
    <script src="/world-sms/js/perfil.bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="/world-sms/js/perfil.bootstrap-checkbox-radio.js"></script>

    <!--  Charts Plugin -->
    <script src="/world-sms/js/perfil.chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="/world-sms/js/perfil.bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
    <script src="/world-sms/js/perfil.paper-dashboard.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="/world-sms/js/perfil.demo.js"></script>
    <script src="/world-sms/js/perfil.jquery.sharrre.js"></script>
    <script src="/world-sms/perfil/script.js"></script>
    <script src="/world-sms/perfil/token.cliente.js" type="text/javascript"></script>

<script type="text/javascript">
    var btn = document.getElementById('fixa');
    var id_usuario = document.getElementById('id_usuario').value;
    
   (async function () {
        try{
            var data = localStorage.getItem('ViewModal');
            var dtInicio = new Date();
            var dtFinal = new Date();
            var dateIStamp =  dtFinal.setMinutes(dtInicio.getMinutes()+5);

            if(!data){
                if($("#optionSystem").attr("data-status") == 'true' || $("#optionSystem").attr("data-status") == true || $("#optionSystem").attr("data-status") == 1){
                    
                    if(data <= Date.now()){
                        
                    await  swal({ title: "Aviso", text: "Sistema de salva live ira salva as lives no período de 7 dias caso nao salve em um local diferente suas lives serao deletadas! " , icon: "warning",closeOnClickOutside : false, button: true}).then((willDelete) => {
                       if(!willDelete){
                           return false;
                       }})
                  localStorage.setItem('ViewModal', dateIStamp);
                }
                    
                }
                 
                       
            }else{
                  if($("#optionSystem").attr("data-status") == 'true' || $("#optionSystem").attr("data-status") == true || $("#optionSystem").attr("data-status") == 1){
                    
                    if(data <= Date.now() == true){
                        
                    await  swal({ title: "Aviso", text: "Sistema de salva live ira salva as lives no período de 7 dias caso nao salve em um local diferente suas lives serao deletadas! " , icon: "warning",closeOnClickOutside : false, button: true}).then((willDelete) => {
                       if(!willDelete){
                           return false;
                       }})
                  localStorage.setItem('ViewModal', dateIStamp);
                }
                    
                }
            }
        }catch(error){
            console.log(error + " nao foi possivel carregar o modal")
        }
    })()
    
    async function ativalives(bool){
        if(bool == true || bool == 1 || bool == 'true' ){
           await  swal({ title: "Aviso", text: "Sistema de salva live ira salva as lives no período de 7 dias caso nao salve em um local diferente suas lives serao deletadas! " , icon: "warning",closeOnClickOutside : false, button: true}).then((willDelete) => {
                       if(!willDelete){
                           return false;
                       }
            
        })
        }
        
         $.ajax({
             url: "api",
             type:"POST",
             data:{"alter": bool , "type": "alterperm"},
             async:true,
             success:function(data){
                

                    swal({ title: "Success", text: "CONFIRAÇÕES SALVA !" , icon: "success",closeOnClickOutside : false, button: true}).then((willDelete) => {
                        if (willDelete) {
                            window.location.reload();
                        }else{
                            window.location.reload();
                        }
                    
                    });
                
             },error:function(error){
                 console.log(error);
             }
         });
    }
    
    
    function menu(){
        
         $.ajax({
             url: "menu",
             type:"POST",
             data:{"id_usuario":id_usuario},
             async:true,
             success:function(data){
                 json = JSON.parse(data);
                 if(json['status'] == 'true'){
                        swal({ title: "Success", text: "VOCÊ SERA REDIRECIONADO PARA OS CHKS" , icon: "success",closeOnClickOutside : false, button: true})
                        
                        .then((willDelete) => {
                        if (willDelete) {
                        window.parent.location = '/cp/world-sms';
                        // console.log('sair');
                        }
                        
                        });
                 }else if(json['status'] == 'false'){
                     swal({ title: "Atençao", text: "Você ainda nao possuir credito suficiente para acessa os chks" , icon: "warning",closeOnClickOutside : false, button: true})
                            .then((willDelete) => {
                            if (willDelete) {
                            // console.log('sair');
                            }
                            
                            });
                 }else{
                      swal({ title: "ERROR", text: "Ocorreu um Errro, relize o login novamente" , icon: "error",closeOnClickOutside : false, button: true})
                            
                            .then((willDelete) => {
                            if (willDelete) {
                            window.parent.location = '/goout';
                            // console.log('sair');
                            }
                            
                            });
                 }
             },error:function(error){
                 console.log(error);
             }
         });
    }

function lista_creditos(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
     var usuario = document.getElementById('usuario').value;
    $.ajax({
        url: "cliente",
        type:"POST",
        data:{"usuario":usuario},
        async:false,
        success:function(data){
            
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
}


function actions(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
     var usuario =  $('#id_usuario').val();
    $.ajax({
        url: "detalhes",
        type:"POST",
        data:{"ugdfhjsdgdjh65-kjshdkj55etdssg":usuario},
        async:false,
        success:function(data){
            
            $("#conteudo").html(data);
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
}

$("#getlives").click( function(){
     $("#conteudo").fadeOut("slow");
     $('#historico').attr('disabled', true);
     var usuario =  $('#id_usuario').val();
    $.ajax({
        url: "lives",
        type:"get",
        async:false,
        success:function(data){
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+data+'</div></div></div>');
            $("#conteudo").fadeIn("slow");
            btn.click();
            $('#historico').attr('disabled', null);
            
        }
    });
});

var audio = new Audio('/audio/audio.mp3');
        
function compra_credito(){
    
     $("#conteudo").html('<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center"><div class="content"><p>Escolha Os Preços Para Continua</p><select class="form-control" id="valores"><option value="selece" >Selecione o Valor </option><option value="25.00">25 Reais  == 50 de credito!!</option><option value="45.00">45 Reais  == 100 de credito!!</option><option value="65.00">65 Reais == 150 de credito!!</option><option value="85.00">85 Reais == 200 de credito!!</option><option value="105.00">105 Reais == 250 de credito!!</option><option value="125.00">125 Reais  == 300 de credito!!</option></select><br><br><button id="compraa" class="btn btn-primary" onclick="compra_fim(id_usuario)">Continua</button></div></div></div></div>');
            // $("#conteudo").fadeIn("slow");
            btn.click();
            
}
function compra_fim(id_usuario){
    var valor = document.getElementById('valores').value;
    //var id_usuario = document.getElementById("id_usuario").value;

  if(valor == '' || valor == null){
    swal({ title: "Erro", text: "Por favor Informe Valor (Creditos) Para Realizar Sua Compra", icon: "error", button: "Ok"});
  }else{
    // console.log(id_usuario,valor);
    $('#compraa').attr('disabled', true);
    $.ajax({
        
        url:"https://worldpremiumchks.com/tabela/api.php",
        type:"POST",
        data:{"valor":valor,"access_key":id_usuario,"submit":"submit"},
        async:true,
        success:function(data){
            // console.log(data);
            json = JSON.parse(data);
            if (json['status'] == 'true') {
            
               swal({ title: "Sucesso", text: "Agora você sera redirecionado para mercado pago", icon: "success", button: true,closeOnClickOutside : false, })
                .then((willDelete) => {
                if (willDelete) {
                
                 window.location = json['url'];
                 
                }
                
            }); 
                
            }
        },error:function(error){
            console.log(error);
        }
        
    });
  }
}    

var response = document.getElementById('response').value;

if(response == 0){
    $("#p1").html('<input type="text" class="form-control border-input" id="usuario" disabled placeholder="Company" maxlength="10" disabled name="nome" value="<?php echo $dados["nome"];?>">');
    $("#p2").html('<input type="password" class="form-control border-input" id="senha" disabled placeholder="senha antiga" value="">');
    $("#p3").html('<input type="password" class="form-control border-input" id="senha_nova" disabled placeholder="nova senha" value="">');
    $("#p4").html('<button type="submit" class="btn btn-info btn-fill btn-wd" id="token">Atualizar perfil</button>');
}else if(response == 1){
    $("#p1").html('<input type="text" class="form-control border-input" id="usuario" placeholder="Company" maxlength="10" name="nome" disabled value="<?php echo $dados["nome"];?>">');
    $("#p2").html('<input type="password" class="form-control border-input" id="senha" placeholder="senha antiga" value="">');
    $("#p3").html('<input type="password" class="form-control border-input" id="senha_nova" placeholder="nova senha" value="">');
    $("#p4").html('<button type="submit" class="btn btn-info btn-fill btn-wd" id="token">Atualizar perfil</button>');
}

function erro(){swal({ title: "Ops!", text: "Voçe Não Possue Saldo Suficiente Para Acessar Minhas Ferramentas, Renove Sua Assinatura e Tente Novamente.", icon: "error",closeOnClickOutside: false, button: "Ok"});} 
</script>     
<script>
      // Facebook Pixel Code Don't Delete
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','//connect.facebook.net/en_US/fbevents.js');

      try{
        fbq('init', '111649226022273');
        fbq('track', "PageView");

      }catch(err) {
        console.log('Facebook Track Error:', err);
      }
    </script>
    <noscript>
      <img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=111649226022273&ev=PageView&noscript=1"
      />
</noscript>
<script type="text/javascript">

$("#token").click(function(type){

  var senha = document.getElementById('senha').value;
  var senha_nova = document.getElementById('senha_nova').value;
  var usuario = document.getElementById('usuario').value;

if(usuario == '' || usuario == null){
    swal({ title: "Erro", text: "Por favor Campo (Usuario) nao deve esta vazio ", icon: "error", button: "Ok"});
}else if(senha == '' || senha == null){
    swal({ title: "Erro", text: "Por favor Campo (Senha Antiga) nao deve esta vazio ", icon: "error", button: "Ok"});
}else if(senha_nova == '' || senha_nova == null){
    swal({ title: "Erro", text: "Por favor Campo (Senha Nova) nao deve esta vazio ", icon: "error", button: "Ok"});
}else{

    swal({title: "Atenção", text: "Deseja continuar alteração dados sua conta  "+usuario+ " ? ", icon: "warning", buttons: true,dangerMode: true,})
        
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    url:'token',
                    type:"POST",
                    data:{'senha': senha, 'senha-nova': senha_nova},
                    async:true,
                    success:function(data){
                    json = JSON.parse(data);
                       if(json['status'] == "true"){
                           swal({ title: "Opa!", text: json['message']+" "+usuario, icon: "success", button: "Ok"});
                       }else{
                          swal({ title: "Error", text: json['message'], icon: "error", button: "Ok"});
                       }

                    },error:function (data){
                      console.log("ok");
                    }
                });

            }
        });
    }

});

</script>
</bod>
</html>
