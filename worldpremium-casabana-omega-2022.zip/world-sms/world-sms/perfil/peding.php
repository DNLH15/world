<?php

session_start();
error_reporting(0);

require_once  getcwd()."/world-sms/perfil/login_.php";
require_once  getcwd()."/conexao/code.php";

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

    $id = $_POST['id_usuario'];

    $sql = "SELECT * FROM `transacoes` WHERE access_key = '$id'";
    $fim= mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);

  
    if(empty($dados)){
        echo "<span style=' padding:20px; font-size:25px; margin:20px;'  >Opss ! , Ainda Não Há Nenhuma Transação Pendente!!</span>";
        exit();
    }
?>

<html>
<head>
  <title>Pagamentos Pendentes</title>
</head>
<body>
<table class="table table-hover" id='corpo'>
  <thead class ='thead'>
 <tr>
      <th scope="col">Id da Transação</th>
      <th scope="col">Ordem da Transação</th>
      <th scope="col" >status</th>
      <th scope="col">credito </th>
      <th scope="col">Atualiza status </th>
      
      
      
    </tr>
  </thead>
  <tbody class='tbody'>
    <tr>
        
  
  
      <?php
        $total = 0;
        
      do{
          if($dados['status'] == 'pending' ||$dados['status'] == 'pendig' ):
          
    ?>

    
    <td><?php echo $dados['id_transacao']; ?></td>
    <td><?php echo $dados['merchant_order_id']; ?></td>
    <td><? echo $dados['status']?></td>
    <td><?php echo $dados['valor']; ?></td>
    <td><i class="fas fa-sync-alt" onclick = "refresh('<?php echo $dados['id_transacao']; ?>','<?php echo $dados['merchant_order_id']; ?>')"></i></td>
    
  </tr>
      <?php
      endif;
      } while($dados = mysqli_fetch_assoc($fim));
      
    ?>

  </tbody>
</table>
<hr style='height:10px color="white";'>
