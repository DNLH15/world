<?php
session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

require_once  getcwd()."/world-sms/perfil/login_.php";
require_once  getcwd()."/conexao/code.php";

$id = $_SESSION['id_usuario'];

$sql = "select * from usuarios where access_key = '{$id}' ";
$fim= mysqli_query($conexao, $sql);
$dados= mysqli_fetch_assoc($fim);

?>

<doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <script src="https://kit.fontawesome.com/b88f04064b.js"></script>
    <link rel="apple-touch-icon" sizes="76x76" href="/world-sms/image/Logo.png">
    <link rel="icon" type="img/png" href="/world-sms/image/Logo.png">

    <title> MINHAS LIVES</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="icon" href="/world-sms/image/Logo.png">

    <!-- Canonical SEO -->
     <link href="/world-sms/css/canonical" href="http://worldpremiumchks.com"/>

    <!-- Bootstrap core CSS     -->
     <link href="/world-sms/css/perfil.bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="/world-sms/css/perfil.animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="/world-sms/css/perfil.paper-dashboard.css" rel="stylesheet"/>
    <link href="/world-sms/css/perfil.style.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/world-sms/css/perfil.demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="/world-sms/css/perfil.themify-icons.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    


</head>
<body>


<div class="card">
    <div class="header"><h4 class="title"><div style="text-align: center;">Escolha um dos chekckers</div></h4></div><br>
     <input type="hidden" id="usuario" value="<?php echo $dados['usuario'];?>">
     <input type="hidden" id="token-response" value="<?php echo $dados['senha'];?>">
    <div class="d-flex justify-content-left" id="categoria" style="text-align: left;">
        
       <hr>
    </div>
</div>
      

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $.ajax({
        url: "api",
        type: "GET",
        data:{
            "action": "getliveskeys",
        },success:function(data){
            var json = JSON.parse(data);
            
            if (json['notFound']){
                 $("#categoria").append(`
                 <div class="row" style="margin-left: 5px;"><div class="col-md-6">
                    <div class="form-group">Usuario sem lives! </div>
                 </div>`);
                 return;
            }
            
            for (index in json){
                $("#categoria").append(`<div class="row" style="margin-left: 5px;" onclick="selectshowlives('${json[index]}')"><div class="col-md-6"><div class="form-group"><label for="exampleInputEmail1">checker:</label> ${json[index]}</div></div></div><hr>`);
                
            }
        }
        
        
    });
    
    
    function selectshowlives( chk ){
        $("#conteudo").animate({
            width: "toggle"
        });
        
        $.ajax({
        url: "api",
        type: "GET",
        data:{
            "action": "getlives",
            checker: chk
        },success:function(data){
            var json = JSON.parse(data);
            
            
            
            $('#historico').attr('disabled', true);
     
     
            if (json['notFound'] ){
                $("#conteudo").fadeIn("slow");
            
                $('#conteudo').html(`<div class="card"><div class="header"><h4 class="title"><div style="text-align: center;">Usuario sem lives!</div></h4></div><br><div class="d-flex justify-content-left" id="categoria" style="text-align: left;"><div class="row" style="display:block"><button type="button" style = "float:left; margin-left: 25px;" onclick="(function(){window.location.reload();})();" class="btn btn-primary">Volta</button><br></div><br></div><br></div>`);
                
                return;
            }
            
            var conteudo = `<table class="table"><thead><tr><th scope="col">#</th><th scope="col">Live</th><th scope="col">Date</th><th scope="col">Ação</th></tr></thead><tbody>`;
            var x = 0;
            
            for (index in json){
                
                var opt = parseInt(x) +1;
                var obj = json[index];
                var date = new Date(obj['timelive']*1000);
                var datee = date.toLocaleDateString("pt-BR");
                conteudo += `<tr id="${index}">
                <th scope="row" >${opt}</th>
                <td>${obj['live']}</td>
                <td>${datee}</td>
                <td><button type="button" onclick = "deletelive('${index}' , '${chk}')" class="btn btn-danger">apaga</button></td>
                </tr>`;
                
                x++;
                
            }
            
            conteudo += `</tbody></table>`;
            
            conteudo += `<hr><div class="row"><button type="button" style = "float:left; margin-left: 25px;" onclick="(function(){window.location.reload();})();" class="btn btn-primary">Volta</button><br></div><br>`;
            
            
            $("#conteudo").html( '<div class="col-lg-0 col-md-0"><div class="card card-user"><div class="text-center">'+conteudo+'</div></div></div>');
            
            $("#conteudo").fadeIn("slow");
            $('#historico').attr('disabled', null);
            
            
        }
        
        
        });
    }
    
    
    
    function deletelive(id_live , chk){
        $.ajax({
        url: "api",
        type: "GET",
        data:{
            "action": "delllive",
            "id_live": id_live,
            "chk": chk
        },success:function(data){
            // console.log(data);
            $(`#${id_live}`).remove();
        }
        
        
    }); 
    }
</script>
</body>
</html>