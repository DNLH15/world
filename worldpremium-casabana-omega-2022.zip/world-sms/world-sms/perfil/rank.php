<?php

session_start();
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

require_once  getcwd()."/world-sms/perfil/login_.php";
require_once  getcwd()."/conexao/code.php";

    $sql = "SELECT usuario,base_saldo,login_aprovadas,ccs_aprovadas,data_time,usuario FROM `usuarios` ORDER BY login_aprovadas DESC";
    $fim= mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);
    
?>
<html>
<head>
  <title>Rank</title>
</head>
<body>
<table class="table table-hover" id='corpo'>
  <thead class ='thead'>
    <tr>
      <th scope="row">Rank</th>
      <th scope="col">nome</th>
      <th scope="col" >Logins</th>
      <th scope="col">Cadastro</th>
      
      
      
    </tr>
  </thead>
  <tbody class='tbody'>
      <center><h2 ><b>Rank Dos Logins Aprovados</b></h2></center><br>
    <tr>
  
      <?php
        $total = 0;
        
      do{
          
       $total ++;
       if($total < 6):
       
    ?>

      <td> # <?php echo $total?></td>
    <td><?php echo $dados['usuario']; ?></td>
    <td><?php echo $dados['login_aprovadas']; ?></td>
    <td><?php echo $dados['data_time']; ?></td>
    
  </tr>
      <?php
      endif;
      } while($dados = mysqli_fetch_assoc($fim));
      
    ?>

  </tbody>
</table>
<hr style='height:10px color="white";'>
<?php

require_once  getcwd()."/conexao/code.php";


    $sql = "SELECT nome,base_saldo,login_aprovadas,ccs_aprovadas,data_time,usuario FROM `usuarios` ORDER BY ccs_aprovadas DESC";
    $fim= mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);
    
?>
<table class="table table-hover" id='corpo'>
  <thead class='thead'>
    <tr>
      <th scope="row">Rank</th>
      <th scope="col">nome</th>
      <th scope="col" >Cc's </th>
      <th scope="col">Cadastro</th>
      
      
      
    </tr>
  </thead>
  <tbody class='tbody'>
      <center><h2 ><b>Rank Das CC's Aprovadas</b></h2></center><br>
    <tr>
        
  
  
      <?php
        $total = 0;
        
      do{
          
       $total ++;
       if($total < 6):
       
    ?>

      <td> # <?php echo $total?></td>
    <td><?php echo $dados['usuario']; ?></td>
     <td><?php echo $dados['ccs_aprovadas']; ?></td>
    <td><?php echo $dados['data_time']; ?></td>
    
  </tr>
      <?php
      endif;
      } while($dados = mysqli_fetch_assoc($fim));
      
    ?>

  </tbody>
</table>
<hr style='height:10px color="black";'>

</body>
</html>

