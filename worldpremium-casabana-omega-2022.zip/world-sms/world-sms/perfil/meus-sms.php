 <?php

session_start();
error_reporting(0);

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
    file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
    die('Proxy access not allowed'); 
} 

$smsregistro = file_get_contents(getcwd()."/world-sms/cp/smsregistro.json");

$id = $_SESSION['usuario'];
$token = $_SESSION['id_usuario'];
   
    $result_cursos = "SELECT * FROM creditos WHERE usuario = '$id'";
    $resultado_cursos = mysqli_query($conexao, $result_cursos);

    $sql = "select * from usuarios where access_key = '{$token}'";
    $fim = mysqli_query($conexao, $sql);
    $dados= mysqli_fetch_assoc($fim);

    if($dados['base_saldo'] <= 0 || $dados['base_saldo'] == 1){
       $_SESSION['sem_saldo'] = true;
       $response = '0';
       $id = '#';
       $id2 = 'onclick="erro()"';
    }else{
       $response = '1';
       $id = '/cp/world-sms';
    }

    
?>
<doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="/world-sms/image/Logo.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/world-sms/image/Logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>WORLDPREMIUM-CHKS</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="icon" href="/world-sms/image/Logo.png">

    <!-- Canonical SEO -->
    <link rel="/world-sms/css/canonical" href="http://worldpremiumchks.com"/>

    <!-- Bootstrap core CSS     -->
    <link href="/world-sms/css/perfil.bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="/world-sms/css/perfil.animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="/world-sms/css/perfil.paper-dashboard.css" rel="stylesheet"/>
    <link href="/world-sms/css/perfil.style.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/world-sms/css/perfil.demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="/world-sms/css/perfil.themify-icons.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 <!--Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NKDMSK6');</script>
    <!--End Google Tag Manager -->
</head>
<body>
  <!--Google Tag Manager (noscript)-->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript)  -->

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    
       <!--Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
        Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"-->
    

       <div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://worldpremiumchks.com" class="simple-text">
                    WORLDPREMIUM-CHKS
                </a>
            </div>
        <ul class="nav">
         <li>
                    <a <?php echo $id2; ?> href="<?php echo $id; ?>" style="cursor: pointer;">
                        <i class="fa fa-bars"></i>
                        <p>Menu Principal</p>
                    </a>
                </li>
                <li class="active">
                    <a href="/perfil/minha-conta">
                        <i class="fa fa-user"></i>
                        <p>Perfil</p>
                    </a>
                </li>
                <li>               
                  <li  id='transacao'>
                    <a onclick="javascript:history.back()" style='cursor: pointer;'>
                         <i class="fa fa-retweet"></i>
                        <p>Voltar</p>
                    </a>
                </li>
                
                <li>
                    <a href="/goout">
                        <i class="fa fa-sign-out"></i>
                        <p>Sair</p>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="https://t.me/WORLDPREMIUMCHKS">
                        <i class="fa fa-commenting"></i>
                        <p>Contato</p>
                    </a>
                </li>
              <li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid" >
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" id='fixa'>
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Perfil usuario</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-bell"></i>
                                    <p class="notification">1</p>
                                    <p>Notifications</p>
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Sem notificaçoes</a></li>
                                
                              </ul>
                            </li>
                        <li>
                    </li>
                </ul>

            </div>
        </div>
    </nav>   
       <div style="
display: flex;
flex-direction: row;
justify-content: center;
align-items: center">
                    <div class="col-lg-8 col-md-7 text-center ">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><div style="text-align: center;">Ultima Movimentação WORLD-SMS</div></h4>
                            </div><br>
                        <?php foreach (json_decode($smsregistro,true)[$token] as $dados_tansacoes_order ){ $dados_tansacoes_order = array_reverse($dados_tansacoes_order);?>
                       <hr>
                            <!--<div class="content">-->
                                    <div class="d-flex justify-content-center">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Numero Virtual</label>
                                                <li><?php echo $dados_tansacoes_order['numero']?></li>
                                            </div>
                                        </div>
                                    
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Operadora</label>
                                                <li><?php echo $dados_tansacoes_order['operadora']?></li>
                                            </div>
                                          </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Serviço</label>
                                                <li><?php echo $dados_tansacoes_order['service']?> </li>
                                            </div>
                                          </div>

                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>SMS Recebido</label>
                                                <li><?php echo $dados_tansacoes_order['message']?> </li>
                                            </div>
                                          </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Status</label>
                                                <li><?php echo $dados_tansacoes_order['status']?></li>
                                            </div>
                                          </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Data da solicitação  </label>
                                               <li><?php echo $dados_tansacoes_order['datetime'] ?></li>
                                            </div>
                                        </div>
                                    </div>
                                </hr>
                                   <?php } ?>

                                        <?php
                                           $response = json_decode($smsregistro,true)[$token][0]['numero'];
                                           if($response == ""){
                                            echo "<br><br>";
                                            echo "<span style='font-size:25px; margin:20px;'  >Opss ! , Você ainda não solicitou nenhum número virtual para ser exibido !!</span>";
                                            echo "<br>";
                                            echo "<hr>";
                                            echo "<br><br>";
                                        }
                                        
                                        ?>

                                        </div>
                                    <!--</div>-->
                                </div>

                            </div>
                        </div>
                    </div>
            </div>
        </div>
</body>

       <!--Core JS Files   -->
    <script src="/world-sms/js/perfil.jquery.min.js" type="text/javascript"></script>
    <script src="/world-sms/js/perfil.bootstrap.min.js" type="text/javascript"></script>

     
    <script src="/world-sms/js/perfil.bootstrap-checkbox-radio.js"></script>

      
    <script src="/world-sms/js/perfil.chartist.min.js"></script>

      
    <script src="/world-sms/js/perfil.bootstrap-notify.js"></script>

      
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    
    <script src="/world-sms/js/perfil.paper-dashboard.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

     
    <script src="/world-sms/js/perfil.demo.js"></script>
    <script src="/world-sms/js/perfil.jquery.sharrre.js"></script>
    <script src="/world-sms/js/perfil.script.js"></script>
    <script type="text/javascript">function erro(){swal({ title: "Ops!", text: "Voçe Não Possue Saldo Suficiente Para Acessar Minhas Ferramentas, Renove Sua Assinatura e Tente Novamente.", icon: "error",closeOnClickOutside: false, button: "Ok"});} </script>

<script>
     
      !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','//connect.facebook.net/en_US/fbevents.js');

      try{
        fbq('init', '111649226022273');
        fbq('track', "PageView");

      }catch(err) {
        console.log('Facebook Track Error:', err);
      }
    </script>
    <noscript>
      <img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=111649226022273&ev=PageView&noscript=1"
      />
    </noscript>

</bod>
</html>
