<?php

error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

date_default_timezone_set('America/Brasilia');
session_start();

 require_once  getcwd()."/world-sms/perfil/login_.php";
 require_once  getcwd()."/conexao/code.php";
 require_once  getcwd()."/pagamentos/send_email.php";

$access_tokens = $_POST['id_usuario'];
$id_transacao = $_POST['id_transacao'];
$merchant_order_id = $_POST['merchant_order_id'];
$mp_access = 'APP_USR-6741360348715042-012022-85543b7c652c2c131da73e3e2c5b3ff6-407915842';


if(empty($access_tokens)){
    die("Informaçoes de usuario Pendente");
    exit();
}

if(empty($id_transacao) and empty($access_tokens) and empty($merchant_order_id)){
    exit();
}


$ch = curl_init();
curl_setopt_array($ch, array(
	CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/'.$id_transacao.'?access_token='.$mp_access,
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_HTTPHEADER => array(
		'content-type:application/json'
	),
));

 $r1 = curl_exec($ch);
$valor = json_decode($r1,true)['transaction_details']['total_paid_amount'];


if($valor == '10'){
    $saldo =  "10";
} else if($valor == '20'){
    $saldo =  "50";
    
}else if ($valor == '40'){
    $saldo = '100';
}else if($valor == '60'){
    $saldo =  "150";
}else if($valor == '80' ){
    $saldo ='200';
}else if($valor == '100'){
    $saldo ='150';   
}else if($valor == '120'){
    $saldo =  "300";
}
		    
  if (json_decode($r1,true)['status'] == 'approved') {
  	$sql = "SELECT count(*) as total FROM historicos  WHERE id_transacao = '$id_transacao'";
  	$resul = mysqli_query($conexao,$sql);
  	$dados = mysqli_fetch_assoc($resul);
		if($dados['total'] == 0){
		    send($id_transacao,$merchant_order_id,$access_tokens,"Aprovado!!");
			$sql = "INSERT INTO historicos(id_transacao,access_key,data_transacao,status,valor) VALUES ('$id_transacao','$access_tokens',NOW(),'Aprovado','$valor')";
			$conexao -> query($sql);
			
			
            $sql = "SELECT base_saldo FROM `usuarios` WHERE access_key = '$access_tokens'";
            $resul = mysqli_query($conexao,$sql);
            $dados = mysqli_fetch_assoc($resul);
            $saldo = $dados['base_saldo'] + $saldo;
  	
  	
			$sql = "UPDATE usuarios set base_saldo = $saldo where  access_key = '$access_tokens'";
			$conexao -> query($sql);
            
            
            $sql = "DELETE FROM `transacoes` WHERE id_transacao ='$id_transacao'";
            $conexao -> query($sql);
            
            echo json_encode(array("status"=>"true","msg"=> "saldo add Com Sucesso"));
		}else{
			echo json_encode(array("status"=>"false","msg"=> "Saldo Ja Adicionado Na Conta !!"));
		}

  }else if(json_decode($r1,true)['status'] == 'cancelled'){
      echo json_encode(array("status"=>"cancelled","msg"=> "Entre em contato com mercado pago!!"));
        $sql = "INSERT INTO historicos(id_transacao,access_key,data_transacao,status,valor) VALUES ('$id_transacao','$access_tokens',NOW(),'Cancelado','$valor')";
        $conexao -> query($sql);
        send($id_transacao,$merchant_order_id,$access_tokens,"Cancelado");
        $sql = "DELETE FROM `transacoes` WHERE id_transacao ='$id_transacao'";
            $conexao -> query($sql);
        
  }else{
  	$error = json_decode($r1,true)['status'];
  	echo json_encode(array("status"=>"d","msg"=> "$error"));

  }
  
  
 ?>