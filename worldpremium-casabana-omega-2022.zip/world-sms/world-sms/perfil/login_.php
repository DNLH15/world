<?php

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
	file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
	die('Proxy access not allowed'); 
} 

session_start();

if(!isset($_SESSION['novato'])){
    session_destroy();
    header("Location: /login/login-usuario");
    echo "<script>location.href='/login/login-usuario'</script>";
    exit();
}