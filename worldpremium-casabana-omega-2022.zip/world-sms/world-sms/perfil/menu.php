<?php
error_reporting(0);

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
	file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
	die('Proxy access not allowed'); 
} 

require_once  getcwd()."/world-sms/perfil/login_.php";

$id_saldo = $_POST['id_usuario'];

if(!isset($id_saldo)  || empty($id_saldo)){
    echo "id do usuario e obrigatorio";
	header('location: https://worldpremiumchks.com');
	echo '<script type="text/javascript">window.location.href="https://worldpremiumchks.com"</script>';
	exit();
}


$ip = $_SERVER['REMOTE_ADDR'];

require_once  getcwd()."/conexao/code.php";
 
$sql = "SELECT * FROM usuarios where access_key = '$id_saldo'";
$realiza = mysqli_query($conexao,$sql);
$dados = mysqli_fetch_assoc($realiza);

if ($realiza == true) {
	 $saldo = $dados['base_saldo'];
	$usuario = $dados['usuario'];
	if ($saldo == 0  ||  $saldo ==1) {
        echo json_encode(array("status"=> "false","msg"=>"Usuario ainda nao possui saldo suficiente "));

	}
	else{
	    echo json_encode(array("status"=> "true","msg"=>"Usuario Possuir Saldo Suficiente"));
	    session_start();
        $tempolimite = 600; 
        $_SESSION['registro'] = time();
        $_SESSION['limite'] = $tempolimite;
        $_SESSION['logado'] = true;
        $_SESSION['usuario'] = $usuario;
        
        $query = "UPDATE `usuarios` SET  ip_plubic = '$ip'  WHERE access_key = '$id_saldo'";
        $result = mysqli_query($conexao, $query);
	}
}else{
	echo "<h3>Nao e possivel acessar esse diretorio. Atualizando pagina em 3 segundos.... </h3>";
	sleep(3);
	header('location: https://worldpremiumchks.com');
	exit();
}

echo $msg;