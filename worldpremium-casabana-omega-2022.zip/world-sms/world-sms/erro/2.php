
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>404 | Ops! algo deu errado....</title>

<link href="https://fonts.googleapis.com/css?family=Oswald:700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="/worldpremium/erro/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="/worldpremium/erro/style15.css" />
<link rel="shortcut icon" href="/image/Logo.png" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div id="notfound">
<div class="notfound-bg">
<div></div>
<div></div>
<div></div>
<div></div>
</div>
<div class="notfound">
<div class="notfound-404">
<h1>404</h1>
</div>
<h2>Pagina não encontrada</h2>
<p>Parece pagina solicitada não existe, tente novamente caso erro persistir entre em contato com administrador do site</p>
<a href="javascript:history.back()">Voltar</a>
</div>
</div>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-23581568-13');
</script>
</body>
</html>
