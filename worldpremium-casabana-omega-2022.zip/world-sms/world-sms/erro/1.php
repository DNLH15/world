<?php

session_start();
error_reporting(0);

$token = base64_encode(rand(0000,9999).''.rand(0000,9999));
$token_response = base64_encode('https://worldpremiumchks.com/'.rand(0000,9999));

if (!$_GET){
    header("Location: ?token=VpKUGpoS4LW8n9ke0W8SiZL$tokenGV05CyJeswS5oM7mk3eveZDToA$tokenEebzgcuBtf5aLihfEHm2E/Mo06LO5$tokennAMj1$tokenVQ====");
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Ops ! algo deu errado</title>
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    <link rel="shortcut icon" href="/image/Logo.png" />

    <!-- css -->
    <link href="bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="materialdesignicons.min.css" rel="stylesheet" type="text/css" />
    <link href="style.min.css" rel="stylesheet" type="text/css" />
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="20">
    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top" id="navbar">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="/">
                <img src="/image/logo-dark-1.png" alt="" class="logo-dark" height="28" />
                <img src="/image/logo-light-1.png" alt="" class="logo-light" height="28" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="" data-feather="menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto navbar-center" id="navbar-navlist">
                    <li class="nav-item">
                        <a href="//t.me/WORLDPREMIUMCHKSCENTRAL" class="nav-link active">Contato</a>
                    </li>
                    <li class="nav-item">
                        <a href="/tabela" class="nav-link">Preços</a>
                    </li>
                    <li class="nav-item">
                        <a href="//t.me/WORLDPREMIUMCHKSCENTRAL" class="nav-link">Ajuda</a>
                    </li>
                    <li class="nav-item">
                        <a href="/" class="nav-link">Menu Inicial</a>
                    </li>
                    <li class="nav-item">
                        <a href="//t.me/WORLDPREMIUMCHKSCENTRAL" class="nav-link">Nosso Grupo Telegram</a>
                    </li>
                </ul>
                <a href="/" class="btn btn-sm rounded-pill nav-btn ms-lg-3">Login Membros</a>
            </div>
        </div>
        <!-- end container -->
    </nav>
    <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="hero-8 bg-center position-relative" style="background-image: url(//images8.alphacoders.com/601/thumb-1920-601973.jpg);" id="home">
        <div class="bg-overlay bg-dark"></div>
        <div class="container">
            <div class="row justify-content-center hero-content">
                <div class="col-lg-9">
                    <div class="text-center">
                        <i class="text-white sw-1_5 icon-lg icon-spin mb-4" data-feather="star"></i>
                        <h1 class="font-weight-semibold mb-4 text-white hero-8-title">Hum... Parece estamos em atualização no momento, mas não se preocupe logo estaremos online</h1>
                        <p class="mb-5 text-white-70 w-lg-75 mx-auto">Lamento por este inconveniente, mas essas atualizações são necessárias para manter site online E atualizado.</p>
                        <a href="//t.me/WORLDPREMIUMCHKSCENTRAL" class="btn btn-light">Contate-nos <i class="icon-sm ms-1"
                                data-feather="arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- Services start -->
    <section class="section" id="services">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-lg-7 text-center">
                    <h2 class="fw-bold">Porque o site esta em atualização ?</h2>
                    <p class="text-muted">Quando você acessar nosso site exibir essa página, significa que os admiradores do site estão fazendo manutenção momento para correção de erros ou atualização do sistema, mas não se preocupe logo em breve site retornara sua função atual.</p>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <div class="service-box text-center px-4 py-5 position-relative mb-4">
                        <div class="service-box-content p-4">
                            <div class="icon-mono service-icon avatar-md mx-auto mb-4">
                                <i class="" data-feather="box"></i>
                            </div>
                            <h4 class="mb-3 font-size-22">Atualização Design</h4>
                            <p class="text-muted mb-0">Aguardando manutenção do site cliente pode ficar das novidades de novos design, templates mais leve, bonito, mais fácil de interagir com ambiente.</p>
                        </div>
                    </div>
                </div>
                <!-- end col -->

                <div class="col-lg-4">
                    <div class="service-box text-center px-4 py-5 position-relative mb-4 active">
                        <div class="service-box-content p-4">
                            <div class="icon-mono service-icon avatar-md mx-auto mb-4">
                                <i class="" data-feather="layers"></i>
                            </div>
                            <h4 class="mb-3 font-size-22">Como entro contato com admiradores ?</h4>
                            <p class="text-muted mb-0">Muito simples, você pode entrar contato conosco pelo canal ajuda ou clicando<a href="//t.me/WORLDPREMIUMCHKSCENTRAL"><font color='red'> aqui </font></a> para ajuda-lo</p>
                        </div>
                    </div>
                </div>
                <!-- end col -->

                <div class="col-lg-4">
                    <div class="service-box text-center px-4 py-5 position-relative mb-4">
                        <div class="service-box-content p-4">
                            <div class="icon-mono service-icon avatar-md mx-auto mb-4">
                                <i class="" data-feather="server"></i>
                            </div>
                            <h4 class="mb-3 font-size-22">Servidores otimizados</h4>
                            <p class="text-muted mb-0">Servidores otimizados, mais desempenho acesso em nosso site e uma das integrações pode incorporar nas atualizações</p>
                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->

    </section>
    <!-- Services end -->

    <!-- Features start -->
    <section class="section bg-light" id="features">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-lg-7 text-center">
                    <h2 class="fw-bold">Agüente só mais um pouco!</h2>
                    <p class="text-muted">Lamentamos muito que esteja passando por essa situação no momento, mas as atualizações serão finalizadas mais rápido possível para você obter melhor de nossos produtos.</p>
                </div>
            </div>           
    </section>
<!-- javascript -->
    <script src="bootstrap.bundle.min.js"></script>
    <script src="smooth-scroll.polyfills.min.js"></script>

    <script src="https://unpkg.com/feather-icons"></script>

    <!--Particles JS-->
    <script src="particles.js"></script>
    <script src="particles.app.js"></script>

    <!-- App Js -->
    <script src="app.js"></script>

</body>

</html>