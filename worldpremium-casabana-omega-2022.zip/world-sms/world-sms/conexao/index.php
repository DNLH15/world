<html>
<head>
<title>WORLDPREMIUM-CHKS</title>

<script>
window.parent.location = 'https://worldpremiumchks.com';
window.self.close();
</script>

</head>
</body>
</html>