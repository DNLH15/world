<?php

error_reporting(0);

 $servidor = "24.152.39.78";
 $usuario = "root";
 $senha = "vpsbancoacessoA456#@casaty";
 $dbname = "codebase";
 //Criar a conexao
 $conexao = mysqli_connect($servidor, $usuario, $senha, $dbname) or die(json_encode(array("status"=> "error", "message"=> "error communicating with server, refresh page or contact support help: support.contato@worldpremiumchks.com",  "code"=> "500")));
 $conexao17 = mysqli_connect($servidor, $usuario, $senha, $dbname) or die(json_encode(array("status"=> "error", "message"=> "error communicating with server, refresh page or contact support help: support.contato@worldpremiumchks.com",  "code"=> "500")));



?>
