<?php

session_start();
error_reporting(0);
date_default_timezone_set('America/Fortaleza');

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
	file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
	die('Proxy access not allowed'); 
} 

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

$access_key = $_SESSION['id_usuario'];

function letras($size){
    $basic = '01234789abcdef';
    $return= "";
    for($count= 0; $size > $count; $count++){
        $return.= $basic[rand(0, strlen($basic) - 1)];
    }
    return $return;
}

function dados($string,$start,$end){
    $str = explode($start,$string);
    $str = explode($end,$str[1]);
    return $str[0];
}

$smstoken = letras(10).'-'.letras(8).'-'.letras(8).'-'.letras(8).'-'.$access_key;
$token = letras(10).'_'.letras(5).'_'.letras(5).'_'.letras(5).'__'.letras(16).'___1e1f-'.letras(7).'-cc87-c778-'.letras(7).'-6B44-cB34-'.letras(7).'-e999-219B-'.letras(7).'-9dB3-'.letras(9); //token world-sms
$id = explode("___", $token)[1];
$tipo = explode('-', $id); 
$id1 = explode("-", $tipo[0])[0];
$id2 =  $tipo[2];
$id3 =  $tipo[3];
$id4 =  $tipo[5];
$id5 =  $tipo[6];
$id6 =  $tipo[8];
$id7 =  $tipo[9];
$id8 =  $tipo[11];
$idss = "$id1$id2$id3$id4$id5$id6$id7$id8";

$fim = file_get_contents("http://24.152.38.212/api-v1/valores.php?token=$idss");
$saldo = file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$idss&action=getBalance");
$selectSms1 = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios WHERE access_key = '{$access_key}'"));
$smsclientes = mysqli_query($conexao,"SELECT * FROM usuarios ORDER BY usuario ASC limit 40");
if($selectSms1['quantidade'] == 0 || $selectSms1['quantidade'] == ""){$selectSms = "0"; $selectSms4 = "0";}else{$selectSms = $selectSms1['quantidade']; $selectSms4 = $selectSms1['registro'];}
$fim2 = mysqli_fetch_assoc(mysqli_query($conexao, "select * from usuarios where access_key = '{$access_key}'"));
$keytoken = letras(32);

$consultblock =  mysqli_num_rows(mysqli_query($conexao,"SELECT * FROM operadora WHERE access_key = '{$access_key}'")); if($consultblock == 2){$url = 'id="block-suspenso"'; $url2 = 'id="block-suspenso"'; $url3 = 'id="block-suspenso"';}

$data['atual'] = date('Y-m-d H:i:s');
$id = $_SESSION['id_usuario'];

//Diminuir 20 segundos 
$data['online'] = strtotime($data['atual'] . " - 300 seconds");
$data['online'] = date("Y-m-d H:i:s",$data['online']);
$id_saldo['online_id'] = $_SESSION['id_usuario']." - 300 seconds";
$smsregistro = file_get_contents(getcwd()."/world-sms/cp/smsregistro.json");

$tokenapi = explode("=",'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ey'.base64_encode('eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NjU2OTc3MTEsImlhdCI6MTYzNDE2MTcxMSwicmF5IjoiMDRmMTg1YzQ1NDI2NGE3ZjdiNDA5NDRhMTQyMzQ5M2MiLCJzdWIiOjc3MzI0M30.L8vGgy3CApuQ22_hPvSRb9t-oOJDu-wUDfutLYw2BSLSXLAPJxccnIKq_f9wFZGIB24btLENSANzBRUvqacJH_WfKZQM3hqQ1PmGcCIPTI9BLNtGtm1N6c6-pcvacEKG1OfkP1HPYX6fsv7_wq-qubzO4nHi1vNQI5S0W6eAJpfAF6leD2Yk_QuY70o0b_H3jJUol2hSvWveywKBdZr546KaBwxCXk_vACqEIzQZ3meK8DBedD0LcSVJaheY3J633iDto4VQ2Bz7rJWQg9bK0koGr6GeimG3aXbx5T54hg6H9XDOuaHmF_VxetNQDszkdZYGfSGBIBgU4iypjsqeKA'))[0];

if(strpos($saldo,"NO_BALANCE") || strpos($saldo,"ACCESS_BALANCE:0.00")!==false){$url = 'id="saldo-sms"'; $url2 = 'id="saldo-sms"'; $url3 = 'id="saldo-sms"'; $url6 = 'id="saldo-sms"'; $url7 = 'id="saldo-sms"'; $url8 = 'id="saldo-sms"'; $url9 = 'id="saldo-sms"'; $url10 = 'id="saldo-sms"';}else{$url = 'id="receber-sms"'; $url2 = 'id="receber-sms-aleatorio"'; $url3 = 'id="sms-whatsapp"'; $url6 = 'id="receber-sms-server-1"'; $url7 = 'id="receber-sms-server-2"'; $url8 = 'id="receber-sms-internacional"'; $url9 ='id="receber-sms-internacional-aleatorio"'; $url10 = 'id="receber-sms-whatsapp-internacional"';}

if($saldo_id == ""){
	$saldo_id = "0";
}

$ip = ["http://server-three-worldpremiumchks.online", "http://server-two-worldpremiumchks.online", "http://server-four-worldpremiumchks.online"];
$serves17 = $ip[array_rand($ip)];

$time = date("H");
$segunds = date("s");

if(strpos(date("l"), "Sunday")!==false){$jivo = "//desativado.sistema.com";}else{
if ($time >= 12 && $time < 22) {
    $jivo = "//code-sa1.jivosite.com";
}else if ($time >= 8 && $time < 12 ) {
    $jivo = "//code-sa1.jivosite.com";
}else{
    $jivo = "//desativado.sistema.com";
 }
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/world-sms/image/Logo.png">
    <title id="title">WORLD-SMS | WORLDPREMIUM-CHKS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<!-- Vendors Style-->
	<link rel="stylesheet" href="/world-sms/css/tipo/vendors_css.css">
	<!--amcharts -->
	<link href="https://www.amcharts.com/lib/3/plugins/export/export.css" rel="stylesheet" type="text/css" /> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo urldecode($jivo); ?>/widget/PMWits2AqP" async></script>
	<!-- Style-->  
	<link rel="stylesheet" href="/world-sms/css/tipo/style.css">
	<link rel="stylesheet" href="/world-sms/css/tipo/skin_color.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="//cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="/world-sms/js/confetti.js"></script>
  </head>
<style type="text/css">

 @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

.alert{
  background: #32B84C;
  padding: 20px 40px;
  min-width: 420px;
  position: absolute;
  right: 0;
  top: 10px;
  border-radius: 4px;
  border-left: 8px solid #ffa502;
  overflow: hidden;
  opacity: 0;
  pointer-events: none;
}
.alert.showAlert{
  opacity: 1;
  pointer-events: auto;
}
.alert.show{
  animation: show_slide 1s ease forwards;
}
@keyframes show_slide {
  0%{
    transform: translateX(100%);
  }
  40%{
    transform: translateX(-10%);
  }
  80%{
    transform: translateX(0%);
  }
  100%{
    transform: translateX(-10px);
  }
}
.alert.hide{
  animation: hide_slide 2s ease forwards;
}
@keyframes hide_slide {
  0%{
    transform: translateX(-10px);
  }
  40%{
    transform: translateX(0%);
  }
  80%{
    transform: translateX(-10%);
  }
  100%{
    transform: translateX(100%);
  }
}
.alert .fa-exclamation-circle{
  position: absolute;
  left: 20px;
  top: 50%;
  transform: translateY(-50%);
  color: #7A0418;
  font-size: 30px;
}
.alert .msg{
  padding: 0 20px;
  font-size: 18px;
  color: rgb(3, 3, 3);
}
.alert .close-btn{
  position: absolute;
  right: 0px;
  top: 50%;
  transform: translateY(-50%);
  background: #32B84C;
  padding: 20px 18px;
  cursor: pointer;
}
.alert .close-btn:hover{
  background: #32B84C;
}
.alert .close-btn .fas{
  color: #030303;
  font-size: 22px;
  line-height: 40px;
}
</style>
<body class="hold-transition dark-skin sidebar-mini theme-warning fixed">
<div class="wrapper">
	<div id="loader"></div>
  <header class="main-header">
<!-- alert noticiation center v1.0 BY DNLH -->
    <div class="alert hide">
         <span class="fas fa-exclamation-circle"></span>
         <span class="msg" id="message-one"></span>
        <div class="close-btn">
            <span class="fas fa-times"></span>
        </div>
    </div>
<!-- alert noticiation center v1.0 BY DNLH -->
	<div class="d-flex align-items-center logo-box justify-content-start">	
		<!-- Logo -->
		<a href="#" class="logo">
		  <!-- logo-->
		  <div class="logo-mini w-30">
			  <span class="light-logo"><img src="/world-sms/image/logo-world.png" alt="logo"></span>
			  <span class="dark-logo"><img src="/world-sms/image/logo-world.png" alt="logo"></span>
			  <input type="hidden" id="usuarioone" value="<?php echo $selectSms1['usuario'];?>">
                    <input type="hidden" id="token-response" value="<?php echo $selectSms1['senha'];?>">
		  </div>
		  <div class="logo-lg">
			  <span class="light-logo"><img src="/world-sms/image/logo-dark-world.png" alt="logo"></span>
			  <input type="hidden" id="keytoken" value="<?php echo $keytoken; ?>">
			  <input type="hidden" id="smstoken" value="<?php echo $smstoken; ?>">
			  <input type="hidden" id="tokenapi" value="<?php echo $tokenapi; ?>">
			  <input type="hidden" id="segunds" value="<?php echo $segunds; ?>">
			  <span class="dark-logo"><img src="/world-sms/image/logo-light-world.png" alt="logo"></span>
		  </div>
		</a>	
	</div>  
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
	  <div class="app-menu">
		<ul class="header-megamenu nav">
			<input type="hidden" id="tokenid" name="tokenid" value="<?php echo $_SESSION['tokenid']; ?>">
			<li class="btn-group nav-item">
				<input type="hidden" id="id" value="<?php echo $token; ?>">
				<a href="#" class="waves-effect waves-light nav-link push-btn btn-primary-light" data-toggle="push-menu" role="button">
					<i data-feather="align-left"></i>
			    </a>
			</li>
		</ul> 
	  </div>
      <div class="navbar-custom-menu r-side">
        <ul class="nav navbar-nav">		  
	<!-- User Account-->
          <li class="dropdown user user-menu">
          	<input type="hidden" id="token" value="<?php echo $access_key; ?>">
            <a href="#" class="waves-effect waves-light dropdown-toggle btn-primary-light" data-bs-toggle="dropdown" title="User">
				<i data-feather="user"></i>
            </a>
            <ul class="dropdown-menu animated flipInX">
              <li class="user-body">
				 <a class="dropdown-item" href="/perfil/minha-conta"><i class="ti-user text-muted me-2"></i> Minha Conta</a>
				 <a class="dropdown-item" href="/perfil/minha-conta"><i class="ti-wallet text-muted me-2"></i> Minhas Compras</a>
				 <a class="dropdown-item" href="/perfil/meu-extrato"><i class="ti-money text-muted me-2"></i> Extrato</a>
				 <div class="dropdown-divider"></div>
				 <a class="dropdown-item" href="/goout"><i class="ti-lock text-muted me-2"></i> Sair</a>
              </li>
            </ul>
          </li>	
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar position-relative">	
	  	<div class="multinav">
	  		<input type="hidden" id="name" value="<?php echo $fim2['usuario']; ?>">
		  <div class="multinav-scroll" style="height: 100%;">	
			  <!-- sidebar menu-->
			  <ul class="sidebar-menu" data-widget="tree">
			  	<li class="treeview">
				  <a href="#">
					<i data-feather="sliders"></i>
					<span>Servidor SMS Brazil (1)</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
				<li>
				  <a href="#?receber-sms" <?php echo $url; ?>>
					<i class="fa fa-comments"></i>
					<span>Receber SMS</span>
				  </a>
				</li>
				<li>
				  <a href="#?receber-sms-aleatorio" <?php echo $url2; ?>>
					<i class="fa fa-comments"></i>
					<span>Receber SMS (Aleatório)</span>
				  </a>
				</li>
			</ul>
		    </li>
		    <li class="treeview">
				  <a href="#">
					<i data-feather="sliders"></i>
					<span>Servidor SMS Brazil (2)</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
				<li>
				    <a href="#?receber-sms" <?php echo $url6; ?>>
					  <i class="fa fa-comments"></i>
					  <span>Receber SMS</span>
				    </a>
				</li>
				<li>
				    <a href="#?receber-sms-aleatorio" <?php echo $url7; ?>>
					  <i class="fa fa-comments"></i>
					  <span>Receber SMS (Aleatório)</span>
				    </a>
				</li>
				</ul>
		        </li>
				<li class="treeview">
				  <a href="#">
					<i data-feather="sliders"></i>
					<span>Servidor SMS (internacional)</span>
					<span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  </a>
				  <ul class="treeview-menu">
				<li>
				    <a href="#?receber-sms-internacional" <?php echo $url8; ?>>
					  <i class="fa fa-comments"></i>
					  <span>Receber SMS</span>
				    </a>
				</li>
				<li>
				    <a href="#?receber-sms-internacional-aleatorio" <?php echo $url9; ?>>
					  <i class="fa fa-comments"></i>
					  <span>Receber SMS (Aleatório)</span>
				    </a>
				</li>
				</ul>
			    </li>
				<li>
				  <a href="#?receber-sms-whatsapp" <?php echo $url3; ?>>
					<i class="fa fa-comments"></i>
					<span>Receber SMS (Whatsapp Brazil)</span>
				  </a>
				</li>
				<li>
				  <a href="#?receber-sms-whatsapp-internacional" <?php echo $url10; ?>>
					<i class="fa fa-comments"></i>
					<span>Receber SMS (Whatsapp Internacional)</span>
				  </a>
				</li>
				<li>
				  <a href="/perfil/minha-conta">
					<i class="fa fa-user"></i>
					<span>Minha Conta</span>
				  </a>
				</li>
				<li>
				  <a onclick="token_id()">
					<i class="fa fa-cog"></i>
					<span>Minhas Ferramentas</span>
				  </a>
				</li>
				<li>
				  <a target="_blank" href="//worldpremiumchks.com/tabela">
					<i class="fa fa-bolt"></i>
					<span>Adicionar Creditos</span>
				  </a>
				</li>
				<li>
				  <a href="/cp/world-sms">
					<i class="fa fa-bars"></i>
					<span>Menu Inicial</span>
				  </a>
				</li>
				<li>
				  <a id="lista-sms" href="#?minha-lista-sms-disponiveis">
					<i class="fa fa-mobile"></i>
					<span>Serviços SMS Diponiveis</span>
				  </a>
				</li>
				<li>
				  <a id="pesquisa" href="#?pesquisa-meus-servicos-disponiveis">
					<i class="fa fa-search"></i>
					<span>Pesquisar serviço</span>
				  </a>
				</li>
				<li>
				  <a id="limitesms" href="#?desbloquear-limite-diario">
					<i class="fa fa-bolt"></i>
					<span>Desbloquear (Limite Diario)</span>
				  </a>
				</li>
				<li>
				  <a href="/perfil/meus-sms">
					<i class="fa fa-user"></i>
					<span>Meus SMS</span>
				  </a>
				</li>
				<li>
				  <a href="/goout">
					<i class="fa fa-outdent"></i>
					<span>Sair</span>
				  </a>
				</li>					     
			</ul>
			  <div class="sidebar-widgets">
				<div class="mx-25 mb-30 p-30 text-center bg-primary-light rounded5">
					<img src="/world-sms/image/world.png" alt="">
					<h4 class="my-3 fw-500 text-uppercase text-primary">COMECE AGORA</h4>
					<span class="fs-12 d-block mb-3 text-black-50">Receba sms dos seus serviços favoritos em um só lugar!</span>
				</div>
				<div class="copyright text-center m-25">
					<p><strong class="d-block"><strong>WORLDPREMIUM CHKS</strong></strong> © 2018-<?php echo date('Y'); ?> All Rights Reserved</p>
				</div>
			  </div>
		  </div>
		</div>
    </section>
  </aside>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
	  <div class="container-full">
		<!-- Main content -->
		<section class="content">			
			<div class="row">	
				<div class="col-12">
					<div class="box">
						<div class="box-body">
							<div class="row justify-content-between">
								<div class="col-xxxl-4 col-xl-5 col-12">
									<div class="p-10">
										<h5 class="text-uppercase fw-600">SALDO ATUAL</h5>
										<h1 class="fw-700 text-dark mt-20"><span id='online_id'><?php echo $saldo_id['base_saldo']; ?></span> R$</h1><br>
										<div class="d-md-flex d-block justify-content-between align-items-center">
											<div>
												<div class="d-flex align-items-center gap-items-3">
													<div class="w-70 h-70 bg-success-light rounded20 l-h-80 text-center">
														<input type="hidden" id="id_usuario" name="id_usuario" value="<?php echo $_SESSION['id_usuario'];?>">
														<i class="text-success ti-arrow-down fs-24"></i>
													</div>
													<div>
														<h3 class="my-0 text-dark fw-700"><span id='sms_registro'>0</span></h3>
														<p class="mb-0">SMS Solicitados</p>
													</div>
												</div>
											</div>
											<div id="tela"></div>
											<div>
												<div class="d-flex align-items-center gap-items-3">
													<div class="w-70 h-70 bg-primary-light rounded20 l-h-80 text-center">
														<i class="text-primary ti-arrow-up fs-24"></i>
													</div>
													<div>
														<h3 class="my-0 text-dark fw-700"><span id='sms_recebidos'><?php echo $selectSms; ?></span></h3>
														<p class="mb-0">SMS Recebidos</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xxxl-8 col-xl-7 col-12">
									<div class="row">
										<div class="col-lg-3 col-md-6 col-12">
											<div class="box bg-warning bg-brick-dark rounded30 mb-md-30 mt-30 mb-0">
												<div class="box-body">
													<div>
														<h4>Creditos</h4>
													</div>
													<div class="mt-100">
														<h3 class="fw-600"><span id='online_saldo'><?php echo $saldo_id['base_saldo']; ?></span></h3>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-md-6 col-12">
											<div class="box bg-primary bg-brick-dark rounded30 mb-md-30 mt-30 mb-0">
												<div class="box-body">
													<div>
														<h4>Saldo SMS</h4>
													</div>
													<div class="mt-100">
														<h3 class="fw-600">0</h3>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-md-6 col-12">
											<div class="box bg-success bg-brick-dark rounded30 mb-md-30 mt-30 mb-0">
												<div class="box-body">
													<div>
														<h4>SMS</h4>
													</div>
													<div class="mt-100">
														<h3 class="fw-600"><span id='sms_recebidos'><?php echo $selectSms; ?></span></h3>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-md-6 col-12">
											<div class="box bg-danger bg-brick-dark rounded30 mb-md-30 mt-30 mb-0">
												<div class="box-body">
													<div>
														<h4>SMS Registrados</h4>
													</div>
													<div class="mt-100">
														<h3 class="fw-600"><span id='total_sms'>0</span></h3>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>	
			<!-- exibir tabela preços serviços -->
				<div class="box">														
					<div id="tabela">
						<table class="table table-white">
                                <thead>
                                    <tr>
                                        <th scope="col">Serviços</th>
                                        <th scope="col">Numeros</th>
                                        <th scope="col">Valor</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Detalhes</th>
                                    </tr>
                                </thead>
                            <tbody>
                             <?php $lines = 0; foreach (json_decode($fim,true)["services"] as $service => $info){ ?>
                            	<tr>
                                   <th scope="row"><?php echo $service; ?></th>
                                   <td><?php echo $info[0]["quant"]; ?></td>
                                   <td><?php echo $info['valor']; ?> Creditos</td>
                                   <td><span class="badge badge-success"><?php  echo $info['status']; ?></span></td>
                                   <td><button type="button"  onclick="pesquise('<?php echo $service; ?>')" class="btn btn-outline-info"><div id="botao-animado-one">Detalhes</div></button></td>
                                </tr>
                              <?php $lines ++; if($lines>= 5){break;}} ?>
                             </tbody>
                        </table>						
					</div>
				</div>
			<!-- exibir tabela preços serviços -->
				<div class="col-12">
					<div class="box">
					  <div class="box-body">
						  <ul id="webticker-3">
                         <?php while($rows_1 = mysqli_fetch_assoc($smsclientes)){ ?>
							<li class="br-1"> 
								<div class="mx-20">
									<div class="d-flex justify-content-center">
										<h6 class="fw-300 me-5">CLIENTE<span class="px-5">-</span><?php echo $rows_1['usuario']; ?> </h6>
									</div>
									<div class="d-block text-center">
										<h3 class=" fw-400 my-0"><?php if($rows_1['quantidade'] == ""){echo $rows_1 = "0";}else{echo $rows_1['quantidade'];}  ?> <span>SMS</span></h3>
										<p class="mb-0"><span class="fw-300">RECEBIDO</p>
									</div>
								</div>
							</li>
                        <?php } ?>
						  </ul>
					  </div>
					</div>
				</div>
			</div>
		</section>
		<!-- /.content -->
	  </div>
  </div>

<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
		  <li class="nav-item">
			<a class="nav-link" href="https://t.me/WORLDPREMIUMCHKSCENTRAL">Contato</a>
		  </li>
		</ul>
    </div>
	  <div id="users"></div>
	  <a data-href="escolher-operadora?token=<?php echo $access_key; ?>&id=<?php echo $keytoken; ?>" id="janela" aria-label="LinkedIn" onclick="off_x=(screen.width/2)-300;off_y=event.clientY-360;window.open(this.getAttribute('data-href'), 'targetWindow', 'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=700,text-align=center,position=absolute,align-items=center,left='+off_x+',top='+off_y); return false;"></a>
  </footer>
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>  
</div>
<!-- Vendor JS -->
	<script src="/world-sms/js/tipo/vendors.min.js"></script>
	<script src="/world-sms/js/tipo/pages/chat-popup.js"></script>
    <script src="/world-sms/css/tipo/time/icons/feather-icons/feather.min.js"></script>	
	<script src="/world-sms/css/tipo/time/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
	<script src="https://www.amcharts.com/lib/4/core.js"></script>
	<script src="https://www.amcharts.com/lib/4/charts.js"></script>
	<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
	<script src="/world-sms/css/tipo/time/vendor_components/Web-Ticker-master/jquery.webticker.min.js"></script>	
	<script src="/world-sms/js/tipo/template.js"></script>
	<script src="/world-sms/js/tipo/pages/dashboard5.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
<script type="text/javascript">

        if( navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i)){
           $("#tela").html('<br>');
           $("#tabela").html('<div class="box"><div class="box-body"><div class="chart h-350" id="order-chart"></div></div></div>');
           $("#users").html('&copy; 2018 - <?php echo date("Y"); ?> <a href="https://www.multipurposethemes.com/">WORLDPREMIUM CHKS</a>. All Rights Reserved.');
        }else{ 
        	console.log("desktop"); 
        }

var name =  document.getElementById('name').value;
var smstoken =  document.getElementById('smstoken').value;
var tokenid = document.getElementById('tokenid').value;
var token = document.getElementById('token').value;
var id = document.getElementById('id').value;
var keytoken = document.getElementById('keytoken').value;
var tokenapi = document.getElementById('tokenapi').value;

document.getElementById("pesquisa").onkeypress = function(e) {
    if (e.keyCode == 13) {
       $("#pesquisa").click();
    }
  }

$("#receber-sms").click(function(){
	$("#title").html('WORLD-SMS');
    swal({ title: "Ola, "+name+"!", text: "Comece agora receber SMS de forma simples e fácil! Temos vários serviços que você pode escolher, Whatsapp, Facebook, Ifood, e entre outros variados serviços. Digite na barra pesquisa abaixo qual serviço você gostaria de receber seu SMS", content: "input", icon: "/world-sms/image/feliz.png", dangerMode: true, button: { text: "Continuar",closeModal: false,},})
    .then(servico => {
        if (!servico) throw null;
          
          var id = document.getElementById('id').value;
          var token = document.getElementById('token').value;
          var keytoken = document.getElementById('keytoken').value;
          var name =  document.getElementById('name').value;
          var servico = servico.toLowerCase();
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
        'accept': "application/json",
        'X-token-world-sms': keytoken,
        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
        if(json1['status'] == "true"){

        $.ajax({
            url:'/cp/tipo',
            type:"POST",
            headers: {
              'accept': "application/json",
              'X-token-world-sms': keytoken,
              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
            },
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{busca: servico, tipo:"busca"}}),
            async:true,
            success:function(data){
            var json = data;
                if(json['status'] == "true"){
              	   swal({title: "Legal "+name, text: "Você obteve pelo serviço "+json['service']+" no valor de "+json['valor']+" creditos, gostaria de continuar sua solicitação ao serviço solicitado?", icon: "success", buttons: ["Não, quero alterar", "Sim"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
              	   .then((willDelete) => {
                    if (willDelete) {
                        responsesmsid(keytoken,token,id,name);
                        time_3();
                        function time_3(){
                           //var inteval = setInterval(function(){
                        $.ajax({
                            url:'/cp/tipo',
                            type:"POST",
                            headers: {
                               'accept': "application/json",
                               'X-token-world-sms': keytoken,
                               'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                            },
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{busca: servico, tipo:"verifysms"}}),
                            async:true,
                            success:function(data){
                            var json2 = data;
                              if(json2['status'] == "true"){
                              	//stopInterval();
                              	swal({title: "Vamos Revisar "+name+ "?", text: "Você optou pelo serviço "+servico+" no valor de "+json2['valor']+" creditos, operadora ("+json2['operadora']+"), gostaria continuar sua solicitação", icon: "/world-sms/image/lupa.png", buttons: ["Prefiro Cancelar", "Sim"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
                              	.then((willDelete) => {
                                  if(willDelete){
                                  	 Swal.fire('Aguarde.......');
                                        $.ajax({
                                            url:'/cp/tipo',
                                            type:"POST",
                                            headers: {
                                               'accept': "application/json",
                                               'X-token-world-sms': keytoken,
                                               'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                            },
                                            dataType: "json",
                                            contentType: "application/json",
                                            data: JSON.stringify({token: token, id: id, keytoken: keytoken, operadora: json2['operadora'], type:{busca: servico, tipo:"solictysms"}}),
                                            async:true,
                                            success:function(data){
                                            var json30 = data;
                                              if(json30['status'] == "true"){
                                              	 console.log("true number generator");
                                                 response(token,id,data,keytoken,name);
                                                 const notification = new Notification("Seu número virtual foi criado "+name+", veja os detalhes", {
                                                    body: "Seu número virtual e ("+data['numero']+")",
                                                    icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                                                 });
                                              }else{
                                                 swal({title: "Erro!", text: data['message']+" codigo erro: "+data['id'], icon: "/world-sms/image/triste.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                                              }
                                            },error:function (data){
                                             console.log("ok");
                                            }
                                        });                                  
                                  }else{
                                  	$.ajax({
                                      url:'/cp/tipo',
                                      type:"POST",
                                      headers: {
                                        'accept': "application/json",
                                        'X-token-world-sms': keytoken,
                                        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                      },
                                      dataType: "json",
                                      contentType: "application/json",
                                      data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo: "deltype"}}),
                                      async:true,
                                      success:function(data){
                                          var json3 = data;
                                          console.log(json3);
                                      },error:function (data){
                                        console.log("ok");
                                      }
                                    });
                                  }
                                });
                              }else{time_3();console.log("aguardando resposta do cliente...");}
                            },error:function (data){
                              console.log("ok");
                            }
                        });
                    }
                     function stopInterval(){ window.clearInterval(inteval);console.log("stop interval success");}
                     setTimeout(function(){Swal.fire('cancelado por inatividade do cliente'); console.log("cancelado por inatividade do cliente"); },9000000);
                    }else{
                    	$("#receber-sms").click();
                    }
                });
              }else{
              	if(json['id'] == "1"){
              	   swal({title: "Ops!", text: json['message'], icon: "/world-sms/image/triste.png", buttons:["Sim", "Não, vou cancelar"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
              	    .then((willDelete) => {
                      if (willDelete) {
                         console.log('solicitacao cancelada pelo cliente.');
                      }else{
                    	 $("#receber-sms").click();
                      }
                    });
                }else{
                  swal({title: "Ops!", text: json['message'], icon: "/world-sms/image/triste.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
              	    .then((willDelete) => {
                        if (willDelete) {
                            $("#receber-sms").click();
                        }
                    });
                }
              }  
            },error:function (data){
                console.log("ok");
            }
        });
      }else{
      	if(json1['id'] == "0"){
      		swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
      	}else{
      	   swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms").click();
            	$.ajax({
                  url:'/cp/tipo',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"deltype"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }
        });
       }
      }
    },error:function (data){
       console.log("ok");
    }

    });
});

function responsesmsid(keytoken,token,id,name){

  Swal.fire({title: '<h4><strong><font color="white">Por favor '+name+', escolha sua operadora para continuarmos sua solicitação</font></strong></h4><br><style type="text/css">img { width: 100px } img, p { display: inline-block; } .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02 }</style><font color="white"><img src="/world-sms/image/operadoras/oi.png" id="id_oi" class="rounded"></img></i><img src="/world-sms/image/operadoras/vivo.png" id="id_vivo" class="rounded"></img></i><img src="/world-sms/image/operadoras/claro.png" id="id_claro" class="rounded"></img></i><img src="/world-sms/image/operadoras/tim.png" id="id_tim" class="rounded"></img></i><img src="/world-sms/image/operadoras/correios.png" id="id_correios" class="rounded"></img></font>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});

$("#id_oi").click(function(){
   var id2 = 'oi';
   smsid(id2);
});

$("#id_vivo").click(function(){
   var id2 = 'vivo';
   smsid(id2);
});

$("#id_claro").click(function(){
   var id2 = 'claro';
   smsid(id2);
});

$("#id_tim").click(function(){
   var id2 = 'tim';
   smsid(id2);
});

$("#id_correios").click(function(){
   var id2 = 'correios';
   smsid(id2);
});


function smsid(id2){

var token = document.getElementById('token').value;
var keytoken = document.getElementById('keytoken').value;

    swal({title: "Estamos quase lá !", text: "Você escolheu operadora "+id2+", deseja continuar sua solicitação a operadora escolhida?" , icon: "/world-sms/image/feliz2.png", buttons: ["Não, vou alterar", "Sim"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
        .then((willDelete) => {
            if (willDelete){
                swal({title: "Aguarde...", icon: "warning"});
                    $.ajax({
                        url:'/cp/tipo',
                        type:"POST",
                        headers: {
                            'accept': "application/json",
                            'X-token-world-sms': keytoken,
                            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                        },
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({token: token, operadora: id2, keytoken: keytoken, type:{tipo:"operadora"}}),
                        async:true,
                        success:function(data){
                        var json23 = data;
                           if(json23['status'] == "true"){console.log('true sucesso');} 
                        },error:function (data){
                          console.log("ok");
                        }
                    }); 
                }
           });
        }
    }

var id = document.getElementById('id').value;
var token = document.getElementById('token').value;
var keytoken = document.getElementById('keytoken').value;

function response(token,id,data,keytoken,name){
time_1();
var json30 = data;
function time_1(){
//var intevalone = setInterval(function(){
	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"statussms"}}),
        async:true,
        success:function(data){
        var json5 = data;
          if(json5['status'] == "true"){
          	if(json5['sms-solicity'] == "2"){
          	   Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Recebemos seu sms com sucesso! Veja a baixo status da mensagem</font></h4><br><h4><font color="red"> '+json5['msg']+' </font></h4>', showDenyButton: true, confirmButtonText: 'Receber outro sms', denyButtonText: `Não quero`,}).then((result) => {
          	   	if(result.isConfirmed) {
                     Swal.fire({html:'<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 10px; margin: 10px; border: 10px solid: #F72F02}</style><img src=/world-sms/image/alert.png></img><h3><strong><font color="white">Atenção '+name+'!</font></strong></h3><br><h4><font color="white"> Você esta prestes a solicitar outro sms no número ('+json5['numero']+'), o custo do sms será cobrado no mesmo valor atual do serviço. Gostaria continuar sua solicitação? </font></h4>', showDenyButton: true, confirmButtonText: 'Sim', denyButtonText: `Não`,}).then((result) => {
                    if(result.isConfirmed){
          	            time_1();
          	            smsclick();
          	            console.log('receber outro sms ativo');
                    }else{
                    	console.log('concluido [1]');
                        smsrecebido(token,id,keytoken);
                    }})
                }else{
                  smsrecebido(token,id,keytoken);
                  console.log('concluido [2]');
                }
            })
          	    const notification = new Notification("Chegou uma Nova Mensagem "+name+"!", {
                  body: "Mensagem: "+json5['msg'],
                  icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                });
          	    $("#title").html('Nova Mensagem - '+json5['msg']);
          	    var audio = new Audio('/audio/toque.mp3');
          	    audio.play();
          	    /*var stopmessage = setInterval(function(){
          	    	 Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS com sucesso '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Como não identificamos sua presença no painel, concluímos que você recebeu seu SMS com sucesso e finalizamos o seu serviço. Caso não tenha visto seu código SMS, veja o extrato em seu perfil na opção <font color="red">meus sms</font></h4>', showCloseButton: true, focusConfirm: false,});
                     console.log('concluido [1]');
                     smsrecebido(token,id,keytoken);	
                     stopmessage1();
          	    },240000);*/
          	    function stopmessage1(){ window.clearInterval(stopmessage);console.log("stop interval success");}
            }else{
               Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Recebemos seu sms com sucesso! Veja a baixo status da mensagem</font></h4><br><h4><font color="red"> '+json5['msg']+' </font></h4>', showCloseButton: true, focusConfirm: false,});
          	    const notification = new Notification("Chegou uma Nova Mensagem "+name+"!", {
                  body: "Mensagem: "+json5['msg'],
                  icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                });
          	    $("#title").html('Nova Mensagem - '+json5['msg']);
          	    var audio = new Audio('/audio/toque.mp3');
          	    audio.play();
            }
          }else if(json5['status'] == "waiting_for_the_code"){
             time_1();
          }else{
            Swal.fire(json5['message']);
            //stopIntervalone();
          } 
        },error:function (data){
            console.log("ok");
        }
    });
}
//}, 6000);
    smsclick();
    function stopIntervalone(){window.clearInterval(intevalone);console.log("stop interval success");}
    function smsclick(){
       Swal.fire({ title: 'Aguardando SMS....', html: '<img src="/world-sms/image/relogio.png"</img><br><h3><font color="white">Copie seu número virtual:<br><font color="red"> ( '+json30['numero']+' )</font><br> insira em seu serviço escolhido, para recebermos seu sms! Lembre-se você tem 15 minutos para utilizar seu numero virtual, caso não queira continuar cancele sua solicitação clicando botão abaixo</font></h3><br><button type="button" id="cancelar" class="btn btn-danger">Cancelar</button>', timer: 9000000, timerProgressBar: true, didOpen: () => {
       Swal.showLoading()
       const b = Swal.getHtmlContainer().querySelector('b')
       timerInterval = setInterval(() => {
       b.textContent = Swal.getTimerLeft()
    }, 100)
    },willClose: () => {
      clearInterval(timerInterval)
    },
}).then((result) => {
    if (result.dismiss === Swal.DismissReason.timer) {
      console.log('serviso cancelado por inatividade');
      //stopIntervalone();
      $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"camcelsms"}}),
        async:true,
        success:function(data){	
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
    }else{
      smsclick();
    }
})
$("#cancelar").click(function(){
	console.log("canceladoooo");
	//stopIntervalone();
	Swal.fire('Serviço foi Cancelado');
	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
          'accept': "application/json",
          'X-token-world-sms': keytoken,
          'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"camcelsms"}}),
        async:true,
        success:function(data){
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
});

 }
}

});

function smsrecebido(token,id,keytoken){

	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
          'accept': "application/json",
          'X-token-world-sms': keytoken,
          'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"smsconcluido"}}),
        async:true,
        success:function(data){
           console.log(data);
        },error:function (data){
            console.log("ok");
        }
    });
   
}

$("#saldo-sms").click(function(){
	swal({title: "Ops!", text: "Parece estamos sem estoque números no momento, mas não se preocupe logo em breve nosso sistema estará online", icon: "/world-sms/image/triste.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
});

$("#lista-sms").click(function(){
Swal.fire({title: '<strong><h3><font color="white"> Veja abaixo nossa lista de serviços disponíveis </font></h3></strong>', html:'<br><br><h3><tr><font color="white"><?php foreach (json_decode($fim,true)["services"] as $service => $info){ ?><div style="text-align: center;"> Serviço:<font color="red"> <?php echo $service; ?></font><br><br> Numeros: <?php echo $info[0]["quant"]; ?><br><br> Valor: <?php echo $info['valor']; ?> <br><br> Status:<span class="badge badge-success"> <?php  echo $info['status']; ?></span></font><br><br></tr><?php } ?></h3>', showCloseButton: true, focusConfirm: false,});
});

$("#pesquisa").click(function(){
	$("#title").html('WORLD-SMS');
  
  swal({ title: "Ola, "+name+"!", text: "Procure seu serviço favorito, netflix google,ifood, 99pop, whatsapp, digitando no campo de pesquisa abaixo", content: "input", icon: "/world-sms/image/feliz.png", dangerMode: true, button: { text: "Continuar",closeModal: false,},})
    .then(pesquisaservico => {
        if (!pesquisaservico) throw null;

	var id = document.getElementById('id').value;
    var token = document.getElementById('token').value;
    var keytoken = document.getElementById('keytoken').value;
    var pesquisaservico = pesquisaservico.toLowerCase();

	if(pesquisaservico == '' || pesquisaservico == null){
       swal({title: "Ops!", text: "A barra pesquisa não deve esta vazia", icon: "/world-sms/image/triste.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
	}else{
		$("#botao-animado").html("pesquisando.....");

	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
        'accept': "application/json",
        'X-token-world-sms': keytoken,
        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{busca: pesquisaservico, tipo:"buscaservice"}}),
        async:true,
        success:function(data){
        var json8 = data;
          if(json8['status'] == "true"){
          	   $("#botao-animado").html("pesquisar");
          	   swal({title: "Eu acho que encontrei sua pesquisa !",  icon: "/world-sms/image/feliz.png", button: "Quero ver", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
          	   Swal.fire({title: '<strong><h3><font color="white"> Que legal! Encontrei resultado nessa pesquisa.. </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"></img><br><br><div style="text-align: center;"><h3><font color="white">Serviço:<font color="red"> '+json8['service']+'</font><br>Numeros Disponiveis: '+json8['numeros']+'</br> Valor: '+json8['valor']+'</br> Status: '+json8['status_service']+'</br></h3></div>', showCloseButton: true, focusConfirm: false,});
          }else{
            swal(json8['message']);
            $("#botao-animado").html("pesquisar");
          }
        },error:function (data){
            console.log("ok");
        }
    });
   }
  });
});

function pesquise(key){

    var id = document.getElementById('id').value;
    var token = document.getElementById('token').value;
    var keytoken = document.getElementById('keytoken').value;
    $("#botao-animado-one").html("pesquisando.....");

	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{busca: key, tipo:"buscaservice"}}),
        async:true,
        success:function(data){
        var json8 = data;
          if(json8['status'] == "true"){
          	   $("#botao-animado").html("pesquisar");
          	   $("#botao-animado-one").html("pesquisar");
          	   Swal.fire({title: '<strong><h3><font color="white"> Que legal! Encontrei resultado nessa pesquisa.. </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"></img><br><br><div style="text-align: center;"><h3><font color="white">Serviço:<font color="red"> '+json8['service']+'</font><br>Numeros Disponiveis: '+json8['numeros']+'</br> Valor: '+json8['valor']+'</br> Status: '+json8['status_service']+'</br></h3></div>', showCloseButton: true, focusConfirm: false,});
          }else{
            Swal.fire(json8['message']);
            $("#botao-animado-one").html("pesquisar");
          }
        },error:function (data){
            console.log("ok");
        }
    });
}

var id = document.getElementById('id').value;
var token = document.getElementById('token').value;
var keytoken = document.getElementById('keytoken').value;

$("#receber-sms-aleatorio").click(function(){
	$("#title").html('WORLD-SMS');
    Swal.fire('Aguarde.......');
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
    if(json1['status'] == "true"){
	
	swal({title: "Ola, "+name+"!", text: "Crie seu numero virtual de forma simples e fácil para desfrutar de todos os seus serviços favoritos! o custo do sms aleatório e de 4 créditos", icon: "/world-sms/image/feliz.png", buttons:["Cancelar", "Continuar"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
        .then((willDelete) => {
            if (willDelete){

              swal({title: "Atenção!", text: "Números aleatórios não têm funcionalidade nos serviços listados no painel, por favor não tente utilizar o número virtual gerado em nossos serviços listados no painel, não retornara resposta do serviço", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {
            if (willDelete){
            	 Swal.fire('Aguarde.......');
            	$.ajax({
                    url:'/cp/tipo',
                    type:"POST",
                    headers: {
                       'accept': "application/json",
                       'X-token-world-sms': keytoken,
                       'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                    },
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({token: token, id: id, keytoken: keytoken, operadora: "vivo", type:{busca: "outros", tipo:"solictysms"}}),
                    async:true,
                    success:function(data){
                    var json10 = data;
                        if(json10['status'] == "true"){
                            response_outros(token,id,data,keytoken,name);
                            const notification = new Notification("Seu número virtual foi criado "+name+", veja os detalhes", {
                               body: "Seu número virtual e ("+data['numero']+")",
                               icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                            });
                        }else{
                            swal({title: "Erro!", text: data['message']+" codigo erro: "+data['id'], icon: "/world-sms/image/triste.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                        }
                    },error:function (data){
                      console.log("ok");
                    }
                });
            }
          });                    
        }
    });
function response_outros(token,id,data,keytoken,name){
time_2();
var json10 = data;
function time_2(){
//var intevalone = setInterval(function(){
	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"statussms"}}),
        async:true,
        success:function(data){
        var json5 = data;
          if(json5['status'] == "true"){
          	if(json5['sms-solicity'] == "2"){
          	   Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Recebemos seu sms com sucesso! Veja a baixo status da mensagem</font></h4><br><h4><font color="red"> '+json5['msg']+' </font></h4>', showDenyButton: true, confirmButtonText: 'Receber outro sms', denyButtonText: `Não quero`,}).then((result) => {
          	   	if(result.isConfirmed) {
                     Swal.fire({html:'<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 10px; margin: 10px; border: 10px solid: #F72F02}</style><img src=/world-sms/image/alert.png></img><h3><strong><font color="white">Atenção '+name+'!</font></strong></h3><br><h4><font color="white"> Você esta prestes a solicitar outro sms no número ('+json5['numero']+'), o custo do sms será cobrado no mesmo valor atual do serviço. Gostaria continuar sua solicitação? </font></h4>', showDenyButton: true, confirmButtonText: 'Sim', denyButtonText: `Não`,}).then((result) => {
                    if(result.isConfirmed){
          	            time_2();
          	            smsclick();
          	            console.log('receber outro sms ativo');
                    }else{
                    	console.log('concluido [1]');
                        smsrecebido(token,id,keytoken);
                    }})
                }else{
                  smsrecebido(token,id,keytoken);
                  console.log('concluido [2]');
                }
            })
          	    const notification = new Notification("Chegou uma Nova Mensagem "+name+"!", {
                  body: "Mensagem: "+json5['msg'],
                  icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                });
          	    $("#title").html('Nova Mensagem - '+json5['msg']);
          	    var audio = new Audio('/audio/toque.mp3');
          	    audio.play();
          	    /*var stopmessage2 = setInterval(function(){
          	    	Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS com sucesso '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Como não identificamos sua presença no painel, concluímos que você recebeu seu SMS com sucesso e finalizamos o seu serviço. Caso não tenha visto seu código SMS, veja o extrato em seu perfil na opção <font color="red">meus sms</font></h4>', showCloseButton: true, focusConfirm: false,});
                    console.log('concluido [1]');
                    smsrecebido(token,id,keytoken);
                    stopmessage3();
          	    },240000);*/
          	    function stopmessage3(){ window.clearInterval(stopmessage2);console.log("stop interval success");}
            }else{
               Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Recebemos seu sms com sucesso! Veja a baixo status da mensagem</font></h4><br><h4><font color="red"> '+json5['msg']+' </font></h4>', showCloseButton: true, focusConfirm: false,});
          	    const notification = new Notification("Chegou uma Nova Mensagem "+name+"!", {
                  body: "Mensagem: "+json5['msg'],
                  icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                });
          	    $("#title").html('Nova Mensagem - '+json5['msg']);
          	    var audio = new Audio('/audio/toque.mp3');
          	    audio.play();
            }
          }else if(json5['status'] == "waiting_for_the_code"){
             time_2();
          }else{
            Swal.fire(json5['message']);
            //stopIntervalone();
          } 
        },error:function (data){
            console.log("ok");
        }
    });
}
//}, 6000);
    smsclick();
    function stopIntervalone(){window.clearInterval(intevalone);console.log("stop interval success");}
    function smsclick(){
       Swal.fire({ title: 'Aguardando SMS....', html: '<img src="/world-sms/image/relogio.png"</img><br><h3><font color="white">Copie seu número virtual:<br><font color="red"> ( '+json10['numero']+' )</font><br> insira em seu serviço escolhido, para recebermos seu sms! Lembre-se você tem 15 minutos para utilizar seu numero virtual, caso não queira continuar cancele sua solicitação clicando botão abaixo</font></h3><br><button type="button" id="cancelar" class="btn btn-danger">Cancelar</button>', timer: 9000000, timerProgressBar: true, didOpen: () => {
       Swal.showLoading()
       const b = Swal.getHtmlContainer().querySelector('b')
       timerInterval = setInterval(() => {
       b.textContent = Swal.getTimerLeft()
    }, 100)
    },willClose: () => {
      clearInterval(timerInterval)
    },
}).then((result) => {
    if (result.dismiss === Swal.DismissReason.timer) {
      console.log('serviso cancelado por inatividade');
      //stopIntervalone();
      $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"camcelsms"}}),
        async:true,
        success:function(data){	
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
    }else{
      smsclick();
    }
})
$("#cancelar").click(function(){
	console.log("canceladoooo");
	//stopIntervalone();
	Swal.fire('Serviço foi Cancelado');
	$.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"camcelsms"}}),
        async:true,
        success:function(data){
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
});

 }
}
}else{
    if(json1['id'] == "0"){
      		swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
    }else{
        swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms").click();
            	$.ajax({
                  url:'/cp/tipo',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"deltype"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }
        });
      }
    }
    },error:function (data){
       console.log("ok");
    }
  });
});

const startit = () => {
    setTimeout(function () {
      console.log("start");
      confetti.start();
    }, 1000);
  };

    const stopit = () => {
      setTimeout(function () {
        console.log("stop");
        confetti.stop();
     }, 12000);
    };
    var audio_confete = new Audio('/audio/audio.mp3');
    startit();
    stopit();

setInterval(function(){

     var id_usuario_input = document.getElementById('id_usuario').value;
     var tokenid = document.getElementById('tokenid').value;
    $.ajax({
      url: "/saldo",
      type: "POST",
      headers: {
        'accept': "application/json",
        'X-token-world-sms': keytoken,
        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
      },
      dataType: "json",
      contentType: "application/json",
      data: JSON.stringify({id_usuario: id_usuario_input, id: tokenid}),
      async:true,
      success:function(data){
      var json = data;
    
       if (json['status'] == "false") {
        $("#iniciar").attr("disabled", true);
          notificar();   
   
       }else if(json['status'] == "d"){
           maquina_d();
           return false;
       }else if(json['status'] == 'redirect'){
            swal({ title: "Atençao! ", text: "Seu Saldo Nao é Suficiente para Acessa Os Nossos Chks , Faça Uma Recarga", icon: "/world-sms/image/alert_icon.png", button: true, dangerMode: true}) .then((willDelete) => {
                if (willDelete) {
            
                      window.location = '/new-index/?pagina=3';
            
                 }
            
            }); 
       }
       else{
          $("#online_id").html(atob(json['msg']));
          $("#online_saldo").html(atob(json['msg']));
          $("#sms_recebidos").html(json['sms_recebidos']);
          $("#sms_registro").html(json['registro']);
          $("#total_sms").html(json['total_sms']);
          
        
       }
      },
      error:function(error){
        console.log(error);
      }
    });

},5000);

Swal.fire({title: '<img src="/world-sms/image/atencao2.png"></img><br><br><strong><h3><font color="red"> Atenção '+name+', essa mensagem é muito importante! </font></h3></strong>', html:'<strong><h3><font color="white">Para utilizar painel<font color="red"> WORLD-SMS </font>voçe precisa concordar com nossas regras de política e privacidade do site, veja abaixo os termos para uso do painel</h3></strong><br><br><div style="text-align: left;">1: Proibido flodar ou abusar do sistema.<br>2: Proibido vender ou repassar acesso e/ou serviços do painel para terceiros sem autorização.<br>3: Proibido exesso de solicitações e/ou tentativa de ataque ao sistema.<br>4: Bloqueios, tentativa burla sistema painel para fins abuso.<br> 5: Sobrecarga painel realizando varias solicitações do serviço.<br> 6: Não será possiver realizar o reembolso de compras realizadas no site.</div><br><br> <div style="text-align: center;"> Quaisquer ações informadas forem cometidas pelo assinante, pode ocorrer bloqueio definitivo da conta no painel sem direito a reembolso da compra </div>',  confirmButtonColor: '#3085d6',confirmButtonText: 'Concordo',})
    .then((result) => {
    if(result.isConfirmed) {
        Swal.fire({title: '<strong><h3><font color="white"> Seja bem-vindo '+name+' ! </font></h3></strong>', html:'<br><br><img src="/world-sms/image/foguete.png"></img><br><br><h3><font color="white">Conheça seu novo painel <font color="red"><strong>WORLD-SMS</strong></font>, aqui você conhecera novas ferramentas para aprimorar sua área de trabalho atual, aproveite...</font></h3>', showCloseButton: true, focusConfirm: false,});
    }
});

$("#receber-sms-server-1").click(function(){
	$("#title").html('WORLD-SMS');
    swal({ title: "Ola, "+name+"!", text: "Comece agora receber SMS de forma simples e fácil! Temos vários serviços que você pode escolher, Whatsapp, Facebook, Ifood, e entre outros variados serviços. Digite na barra pesquisa abaixo qual serviço você gostaria de receber seu SMS", content: "input", icon: "/world-sms/image/feliz.png", dangerMode: true, button: { text: "Continuar",closeModal: false,},})
    .then(servico => {
        if (!servico) throw null;
          var id = document.getElementById('id').value;
          var token = document.getElementById('token').value;
          var keytoken = document.getElementById('keytoken').value;
          var name =  document.getElementById('name').value;
          var servico = servico.toLowerCase();
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
        'accept': "application/json",
        'X-token-world-sms': keytoken,
        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
        if(json1['status'] == "true"){
        	$.ajax({
              url:'/cp/service',
              type:"POST",
              headers: {
                'accept': "application/json",
                'X-token-world-sms': keytoken,
                'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
              },
              dataType: "json",
              contentType: "application/json",
              data: JSON.stringify({token: token, id: id, tokenjwt: tokenapi, type:{tipo: servico, country: "brazil"}}),
              async:true,
              success:function(data){
              var json2 = data;
                if(data['status'] == "ONLINE"){
        	       swal({title: "Legal "+name, text: "Você obteve pelo serviço "+json2['servico']+" no valor de "+json2['valor']+" creditos, gostaria de continuar sua solicitação ao serviço solicitado?", icon: "success", buttons: ["Não, quero alterar", "Sim"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
              	   .then((willDelete) => {
                    if (willDelete){
                    	Swal.fire('Aguarde.....');
                    	$.ajax({
                            url:'/cp/token',
                            type:"POST",
                            headers: {
                             'accept': "application/json",
                             'X-token-world-sms': keytoken,
                              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                            },
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({token: token, tokenjwt: tokenapi, tokenid: id, keytoken: keytoken, type:{tipo:"server-sms", busca: json2['servico'], service: "any", valor: json2['valor'], country: "brazil" }}),
                            async:true,
                            success:function(data){
                            var json3 = data;
                                if(data['status'] == "true"){
                                  responsewhatsapp(token,tokenapi,keytoken,name,data);
                	            }else{
                	              Swal.fire(data['message']);
                	              $.ajax({
                                    url:'/cp/token',
                                    type:"POST",
                                    headers: {
                                       'accept': "application/json",
                                       'X-token-world-sms': keytoken,
                                       'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                    },
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({token: token, id: id, tokenid: id, keytoken: keytoken, type:{tipo:"cancel-sms"}}),
                                    async:true,
                                    success:function(data){
                                      var json2 = data;
                                      console.log(json2);
                                    },error:function (data){
                                      console.log("ok");
                                    }});
                	            } 
                            },error:function (data){
                              console.log("ok");
                            }
                        });
                    }else{
                      $("#receber-sms-server-1").click();
                    }});
              	}else if(data['status'] == "OFF"){
              	  swal({title: "Ops!", text: "Ops, parece estamos sem estoque de números para o serviço "+servico+"! Mas não se preocupe, logo em breve estoque estará abastecido :)", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                }else{
                  swal({title: "Ops!", text: "Erro ao se comunicar com servidor, tente novamente ou entre contato com suporte ajuda", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                  console.log(data);
                }
            },error:function (data){
              console.log("ok");
            }});
        }else{
      	    swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms-server-1").click();

            	$.ajax({
                  url:'/cp/token',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, tokenjwt: tokenapi, id: id, tokenid: id, keytoken: keytoken, type:{tipo:"cancel-sms"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }});
          }
        },error:function (data){
            console.log("ok");
        }}); 
    });

});

$("#receber-sms-server-2").click(function(){
	$("#title").html('WORLD-SMS');
    Swal.fire('Aguarde.......');
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
    if(json1['status'] == "true"){
	    swal({title: "Ola, "+name+"!", text: "Crie seu numero virtual de forma simples e fácil para desfrutar de todos os seus serviços favoritos! o custo do sms aleatório e de 4 créditos", icon: "/world-sms/image/feliz.png", buttons:["Cancelar", "Continuar"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
        .then((willDelete) => {
            if (willDelete){
              swal({title: "Atenção!", text: "Números aleatórios não têm funcionalidade nos serviços listados no painel, por favor não tente utilizar o número virtual gerado em nossos serviços listados no painel, não retornara resposta do serviço", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
                .then((willDelete) => {
                	Swal.fire('Aguarde.......');
                    	$.ajax({
                            url:'/cp/token',
                            type:"POST",
                            headers: {
                             'accept': "application/json",
                             'X-token-world-sms': keytoken,
                              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                            },
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"server-sms", busca: "other", service: "virtual21", valor: "4", country: "brazil"}}),
                            async:true,
                            success:function(data){
                            var json3 = data;
                                if(data['status'] == "true"){
                                  responsewhatsapp(token,tokenapi,keytoken,name,data);
                	            }else{
                	              Swal.fire(data['message']);
                	              $.ajax({
                                    url:'/cp/token',
                                    type:"POST",
                                    headers: {
                                       'accept': "application/json",
                                       'X-token-world-sms': keytoken,
                                       'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                    },
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({token: token, id: id, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
                                    async:true,
                                    success:function(data){
                                      var json2 = data;
                                      console.log(json2);
                                    },error:function (data){
                                      console.log("ok");
                                    }});
                	            } 
                            },error:function (data){
                              console.log("ok");
                            }
                    });
                });
            }
        });
    }else{
      	swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms-server-1").click();

            	$.ajax({
                  url:'/cp/token',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, tokenjwt: tokenapi, id: id, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }});
        }
    },error:function (data){
      console.log("ok");
    }
    }); 
});
function maquina_d(){
  swal({ title: "Erro", text: "Sua conta foi usada para logar em outro local. Você será deslogado agora." , icon: "warning",closeOnClickOutside : false, button: true})

    .then((willDelete) => {
       if (willDelete) {
          window.parent.location = '/goout';
        console.log('sair');
        }

    });
}

function token_id(){

    var tokenresponse = document.getElementById('token-response').value;
    var usuario = document.getElementById('usuarioone').value;
    var identify = usuario+"|"+token;
    swal({ title: "Aguarde !", text: "redirecionando para área do cliente...", icon: "warning",closeOnClickOutside: false, button: "Ok"});
    
    $.ajax({
        url:'redirect',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({tokenresponse: btoa(btoa(btoa(identify)))+"___"+btoa(identify)}),
        async:true,
        success:function(data){
        var json = data;
        if(json['status'] == 'success'){
            var token = json['redirect'];
            setTimeout(function(){window.parent.location = '<?php echo $serves17; ?>/login/login-usuario?serverStatus=availabre'}, 1000);
        }else if(json['status'] == 'error_serve'){
            swal({ title: "Ops!", text: "Não foi possível continuar sua solicitação, tente novamente. Caso erro persistir contate nosso suporte ajuda", icon: "error",closeOnClickOutside: false, button: "Ok"});
        }
        },error:function (data){
          console.log("ok");
        }
    });
    setTimeout(function time(){swal({ title: "Ops!", text: "Não foi possível continuar sua solicitação, tente novamente. Caso erro persistir contate nosso suporte ajuda", icon: "error",closeOnClickOutside: false, button: "Ok"});},50000);
}

$("#limitesms").click(function(){
	Swal.fire({title: '<style type="text/css">img { width: 400px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .default-btn.btn-blue{ background-color: #622dfa; -webkit-box-shadow: 0px 15px 25px 0px rgba(98, 45, 250, 0.5); box-shadow: 0px 15px 25px 0px rgba(98, 45, 250, 0.5);} .btn {text-align: center; box-sizing: border-box; -webkit-appearance: none; -moz-appearance: none; appearance: none; background-color: transparent; border: 2px solid #e74c3c; border-radius: 0.6em; color: #e74c3c; cursor: pointer; display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-align-self: center; -ms-flex-item-align: center; align-self: center; font-size: 1rem; font-weight: 400; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700;} .first {-webkit-transition: box-shadow 300ms ease-in-out, color 300ms ease-in-out; transition: box-shadow 300ms ease-in-out, color 300ms ease-in-out;} .first:hover {box-shadow: 0 0 100px 100px #e74c3c inset;} .form-content .form-button .ibtn {border-radius: 6px; border: 0; padding: 6px 28px; background-color: #fff; color: #29A4FF; font-size: 14px; font-weight: 700; text-decoration: none; cursor: pointer; margin-right: 10px; outline: none; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; -webkit-box-shadow: 0 0 0 rgba(0, 0, 0, 0.16); box-shadow: 0 0 0 rgba(0, 0, 0, 0.16);} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 10px; border-radius: 8px;}</style><h4><strong><font color="white">Ola, '+name+'!</font></strong></h4 class="text"><img src=/world-sms/image/hero-1.png </img><br><h4><font color="white">Você Precisa de mais números virtuais mas usou todo o seu limite diário? não se preocupe você pode liberar seu limite diário clicando no botão abaixo! Por apenas 5 créditos, você pode liberar seu limite diário de 30 SMS em sua conta</h4></font><button type="button" id="smslimite" class="button first"><font color="white">Continuar</font></button>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});
    $("#smslimite").click(function(){
     Swal.fire({title: '<style type="text/css">img { width: 400px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><h2><font color="red">Atenção '+name+' !</font></h2><img src="/world-sms/image/aviso.png"></img><h4><strong><font color="white">Você esta preste a liberar seu limite diário no valor de 5 créditos, gostaria de continuar?</font></strong></h4><button type="button" id="smslibera" class="button first"><font color="white">Sim</font></button>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});

    $("#smslibera").click(function(){

        Swal.fire('Aguarde.......');
        $.ajax({
           url:'/cp/limite',
           type:"POST",
           headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
           },
           dataType: "json",
           contentType: "application/json",
           data: JSON.stringify({token: token, type:{tipo: "change_daily_limit"}}),
           async:true,
           success:function(data){
           var json = data;
            if(json['status'] == 'true'){
              startit();
              stopit();
              audio_confete.play();
              Swal.fire(data['message']);
            }else{
              Swal.fire(data['message']);
            }
          },error:function (data){
           console.log("ok");
          }
        });
    });
  });
});

$("#sms-whatsapp").click(function(){

	Swal.fire({title: '<style type="text/css">img { width: 300px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/whatsapp.png"></img><h4><strong><font color="white">Olá, '+name+' ! Finalmente o serviço whatsapp esta disponível no painel <font color="red">WORLD-SMS</font>. Agora com serviço ativo, você pode criar contas whatsapp à-vontade por apenas 5 créditos por sms recebido do serviço</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não`,}).then((result) => {
  
    if(result.isConfirmed) {
       Swal.fire({html:'<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 10px; margin: 10px; border: 10px solid: #F72F02}</style><img src=/world-sms/image/alert.png></img><h3><strong><font color="white">Atenção '+name+'!</font></strong></h3><br><h2><font color="white"> Os números gerados para o serviço whatsapp não temos garantia estão 100% virgens para criar novas contas, talvez os números criados podem já existir contas já ativas no serviço. Caso queria continuar, basta clica no botão abaixo </font></h2>', showDenyButton: true, confirmButtonText: 'Continuar com serviço', denyButtonText: `Não`,}).then((result) => {
        if(result.isConfirmed){
        	Swal.fire('Aguarde.....');
        $.ajax({
            url:'/cp/service',
            type:"POST",
            headers: {
                'accept': "application/json",
                'X-token-world-sms': keytoken,
                'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
            },
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, type:{tipo:"whatsapp", type: "verifiy-service", country: "brazil"}}),
            async:true,
            success:function(data){
        if(data['status'] == "ONLINE"){
            $.ajax({
                url:'/cp/token',
                type:"POST",
                headers: {
                  'accept': "application/json",
                  'X-token-world-sms': keytoken,
                  'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                },
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"solicty-sms-whatsapp", busca: "whatsapp", service: "virtual29", country: "brazil"}}),
                async:true,
                success:function(data){
                	if(data['status'] == "true"){
                       responsewhatsapp(token,tokenapi,keytoken,name,data);
                	}else{
                	  Swal.fire(data['message']);
                	} 
               },error:function (data){
                 console.log("ok");
               }
            });
        }else if(data['status'] == "OFF"){ 
          Swal.fire('Ops, parece estamos sem estoque de números para o serviço whatsapp! Mas não se preocupe, logo em breve estoque estará abastecido :)');
        }else{
           Swal.fire('Erro ao se comunicar com servidor, tente novamente ou entre contato com suporte ajuda');
           console.log(data);
        }
       },error:function (data){
         console.log("ok");
       }
    });          
      }})
    }
  })
});

function responsewhatsapp(token,tokenapi,keytoken,name,data){
time_4();
var json31 = data;
function time_4(){
	$.ajax({
        url:'/cp/token',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"status-sms"}}),
        async:true,
        success:function(data){
        var json40 = data;
            if(json40['status'] == "true"){
               Swal.fire({title: '<strong><h3><font color="white"> Recebemos seu SMS '+name+'! </font></h3></strong>', html:'<img src="/world-sms/image/feliz.png"</img><br><br><h4><font color="white">Recebemos seu sms com sucesso! Veja a baixo status da mensagem</font></h4><br><h4><font color="red"> '+json40['msg']+' </font></h4>', showCloseButton: true, focusConfirm: false,});
          	    const notification = new Notification("Chegou uma Nova Mensagem "+name+"!", {
                  body: "Mensagem: "+json40['msg'],
                  icon: "https://world-sms.worldpremiumchks.com/world-sms/image/320x220.png"
                });
          	    $("#title").html('Nova Mensagem - '+json40['msg']);
          	    var audio = new Audio('/audio/toque.mp3');
          	    audio.play();
            }else if(json40['status'] == "waiting_for_the_code"){
                time_4();
            }else{
               Swal.fire(json40['message']);
            } 
        },error:function (data){
            console.log("ok");
        }
    });
}

smsclick();
function stopIntervalone(){window.clearInterval(intevalone);console.log("stop interval success");}
    function smsclick(){
       Swal.fire({ title: 'Aguardando SMS....', html: '<img src="/world-sms/image/relogio.png"</img><br><h3><font color="white">Copie seu número virtual:<br><font color="red"> ( '+json31['numero']+' )</font><br> insira em seu serviço escolhido, para recebermos seu sms! Lembre-se você tem 15 minutos para utilizar seu numero virtual, caso não queira continuar cancele sua solicitação clicando botão abaixo</font></h3><br><button type="button" id="cancelar" class="btn btn-danger">Cancelar</button>', timer: 9000000, timerProgressBar: true, didOpen: () => {
       Swal.showLoading()
       const b = Swal.getHtmlContainer().querySelector('b')
       timerInterval = setInterval(() => {
       b.textContent = Swal.getTimerLeft()
    }, 100)
    },willClose: () => {
      clearInterval(timerInterval)
    },
}).then((result) => {
    if (result.dismiss === Swal.DismissReason.timer) {
      console.log('serviso cancelado por inatividade');
      $.ajax({
        url:'/cp/token',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
        async:true,
        success:function(data){	
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
    }else{
      smsclick();
    }
})
$("#cancelar").click(function(){
	console.log("canceladoooo");
	//stopIntervalone();
	Swal.fire('Serviço foi Cancelado');
	$.ajax({
        url:'/cp/token',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
        async:true,
        success:function(data){	
        var json6 = data;
          if(json6['status'] == "true"){
            console.log(json6);    
          }else{
            Swal.fire(json6['message']);
          }
        },error:function (data){
            console.log("ok");
        }
    });
});

 }
}

$("#receber-sms-internacional").click(function(){
	Swal.fire({title: '<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Ola, '+name+'! Agora você pode receber SMS internacional com a <font color="red">WORLD-SMS</font>. Receba SMS internacional de seus serviços favoritos, netflix, whatsapp, google, entre outros serviços com mais facilidade! Basta clicar no botão <font color="red">"continuar"</font> e escolha o pais de sua preferência para gerar o seu número virtual do seu serviço favorito.</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não Quero`,}).then((result) => {

    if(result.isConfirmed) {
      Swal.fire({html:'<style type="text/css">@keyframes bounce { 0%, 20%, 60%, 100% { -webkit-transform: translateY(0); transform: translateY(0);} 40%{-webkit-transform: translateY(-20px); transform: translateY(-20px);} 80%{ -webkit-transform: translateY(-10px); transform: translateY(-10px);}} img { width: 100px } img, p { display: inline-block; } .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02; cursor: pointer; transition: all 400ms ease;} .efeito:hover {animation: bounce 1s;} .text {font-family: "Montserrat"}</style><img id="id_usa" src="/world-sms/image/usa.png" class="rounded efeito"></img></i><img id="id_india" src="/world-sms/image/india.png" class="rounded efeito"></img></i><img id="id_china" src="/world-sms/image/china.png" class="rounded efeito"></img></i><img id="id_canada" src="/world-sms/image/canada.png" class="rounded efeito"></img></i><img id="id_mexico" src="/world-sms/image/mexico.png" class="rounded efeito"></img></i><img id="id_argentina" src="/world-sms/image/argentina.png" class="rounded efeito"></img><h3><strong><font color="white">Por favor '+name+', escolha seu pais para continuar sua solicitação</font></h2>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});

      $("#id_usa").click(function(){
        console.log("USA");
        var tipo = 'usa';
        pais_id(tipo);
      });

      $("#id_india").click(function(){
        console.log("india");
        var tipo = 'india';
        pais_id(tipo);
      });

      $("#id_china").click(function(){
        console.log("china");
        var tipo = 'china';
        pais_id(tipo);  
      });

      $("#id_canada").click(function(){
        console.log("canada");
        var tipo = 'canada';
        pais_id(tipo);  
      });

      $("#id_mexico").click(function(){
        console.log("mexico");
        var tipo = 'mexico';
        pais_id(tipo);  
      });

      $("#id_argentina").click(function(){
        console.log("argentina");
        var tipo = 'argentina';
        pais_id(tipo);  
      });

    function pais_id(tipo){
          Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Legal '+name+'! Você escolheu pais '+tipo+', gostaria continuar nesses pais escolhido?</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não`,}).then((result) => {
    if(result.isConfirmed){
      $("#title").html('WORLD-SMS');
      swal({ title: "Ola, "+name+"!", text: "Comece agora receber SMS de forma simples e fácil! Temos vários serviços que você pode escolher, Whatsapp, Facebook, Ifood, e entre outros variados serviços. Digite na barra pesquisa abaixo qual serviço você gostaria de receber seu SMS", content: "input", icon: "/world-sms/image/feliz.png", dangerMode: true, button: { text: "Continuar",closeModal: false,},})
      .then(servico => {
        if (!servico) throw null;
          var id = document.getElementById('id').value;
          var token = document.getElementById('token').value;
          var keytoken = document.getElementById('keytoken').value;
          var name =  document.getElementById('name').value;
          var servico = servico.toLowerCase();
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
        'accept': "application/json",
        'X-token-world-sms': keytoken,
        'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
        if(json1['status'] == "true"){
        	$.ajax({
              url:'/cp/service',
              type:"POST",
              headers: {
                'accept': "application/json",
                'X-token-world-sms': keytoken,
                'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
              },
              dataType: "json",
              contentType: "application/json",
              data: JSON.stringify({token: token, id: id, tokenjwt: tokenapi, type:{tipo: servico, country: tipo}}),
              async:true,
              success:function(data){
              var json2 = data;
                if(data['status'] == "ONLINE"){
        	       swal({title: "Legal "+name, text: "Você obteve pelo serviço "+json2['servico']+" no valor de "+json2['valor']+" creditos, gostaria de continuar sua solicitação ao serviço solicitado?", icon: "success", buttons: ["Não, quero alterar", "Sim"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
              	   .then((willDelete) => {
                    if (willDelete){
                    	Swal.fire('Aguarde.....');
                    	$.ajax({
                            url:'/cp/token',
                            type:"POST",
                            headers: {
                             'accept': "application/json",
                             'X-token-world-sms': keytoken,
                              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                            },
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"server-sms", busca: json2['servico'], service: "any", valor: json2['valor'], country: tipo }}),
                            async:true,
                            success:function(data){
                            var json3 = data;
                                if(data['status'] == "true"){
                                  responsewhatsapp(token,tokenapi,keytoken,name,data);
                	            }else{
                	              Swal.fire(data['message']);
                	              $.ajax({
                                    url:'/cp/token',
                                    type:"POST",
                                    headers: {
                                       'accept': "application/json",
                                       'X-token-world-sms': keytoken,
                                       'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                    },
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({token: token, id: id, keytoken: keytoken, type:{tipo:"cancel-sms"}}),
                                    async:true,
                                    success:function(data){
                                      var json2 = data;
                                      console.log(json2);
                                    },error:function (data){
                                      console.log("ok");
                                    }});
                	            } 
                            },error:function (data){
                              console.log("ok");
                            }
                        });
                    }else{
                      $("#receber-sms-internacional").click();
                    }});
              	}else if(data['status'] == "OFF"){
              	  swal({title: "Ops!", text: "Ops, parece estamos sem estoque de números para o serviço "+servico+"! Mas não se preocupe, logo em breve estoque estará abastecido :)", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                }else{
                  swal({title: "Ops!", text: "Erro ao se comunicar com servidor, tente novamente ou entre contato com suporte ajuda", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,});
                  console.log(data);
                }
            },error:function (data){
              console.log("ok");
            }});
        }else{
      	    swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms-internacional").click();

            	$.ajax({
                  url:'/cp/token',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, id: id, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }});
          }
        },error:function (data){
            console.log("ok");
        }}); 
    });
}else{
    $("#receber-sms-internacional").click();
}});}}});

});

$("#receber-sms-internacional-aleatorio").click(function(){
	Swal.fire({title: '<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Ola, '+name+'! Agora você pode receber SMS internacional com a <font color="red">WORLD-SMS</font>. Receba SMS internacional de seus serviços favoritos, netflix, whatsapp, google, entre outros serviços com mais facilidade! Basta clicar no botão <font color="red">"continuar"</font> e escolha o pais de sua preferência para gerar o seu número virtual do seu serviço favorito.</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não Quero`,}).then((result) => {

    if(result.isConfirmed) {
      Swal.fire({html:'<style type="text/css">@keyframes bounce { 0%, 20%, 60%, 100% { -webkit-transform: translateY(0); transform: translateY(0);} 40%{-webkit-transform: translateY(-20px); transform: translateY(-20px);} 80%{ -webkit-transform: translateY(-10px); transform: translateY(-10px);}} img { width: 100px } img, p { display: inline-block; } .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02; cursor: pointer; transition: all 400ms ease;} .efeito:hover {animation: bounce 1s;} .text {font-family: "Montserrat"}</style><img id="id_usa" src="/world-sms/image/usa.png" class="rounded efeito"></img></i><img id="id_india" src="/world-sms/image/india.png" class="rounded efeito"></img></i><img id="id_china" src="/world-sms/image/china.png" class="rounded efeito"></img></i><img id="id_canada" src="/world-sms/image/canada.png" class="rounded efeito"></img></i><img id="id_mexico" src="/world-sms/image/mexico.png" class="rounded efeito"></img></i><img id="id_argentina" src="/world-sms/image/argentina.png" class="rounded efeito"></img><h3><strong><font color="white">Por favor '+name+', escolha seu pais para continuar sua solicitação</font></h2>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});

      $("#id_usa").click(function(){
        console.log("USA");
        var tipo = 'usa';
        pais_id(tipo);
      });

      $("#id_india").click(function(){
        console.log("india");
        var tipo = 'india';
        pais_id(tipo);
      });

      $("#id_china").click(function(){
        console.log("china");
        var tipo = 'china';
        pais_id(tipo);  
      });

      $("#id_canada").click(function(){
        console.log("canada");
        var tipo = 'canada';
        pais_id(tipo);  
      });

      $("#id_mexico").click(function(){
        console.log("mexico");
        var tipo = 'mexico';
        pais_id(tipo);  
      });

      $("#id_argentina").click(function(){
        console.log("argentina");
        var tipo = 'argentina';
        pais_id(tipo);  
      });

    function pais_id(tipo){
          Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Legal '+name+'! Você escolheu pais '+tipo+', gostaria continuar nesses pais escolhido?</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não`,}).then((result) => {
    if(result.isConfirmed){
    	$("#title").html('WORLD-SMS');
    Swal.fire('Aguarde.......');
    $.ajax({
        url:'/cp/tipo',
        type:"POST",
        headers: {
            'accept': "application/json",
            'X-token-world-sms': keytoken,
            'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token: token, id: id, type:{tipo:"verify"}}),
        async:true,
        success:function(data){
        var json1 = data;
    if(json1['status'] == "true"){
	    swal({title: "Ola, "+name+"!", text: "Crie seu numero virtual de forma simples e fácil para desfrutar de todos os seus serviços favoritos! o custo do sms aleatório e de 5 créditos", icon: "/world-sms/image/feliz.png", buttons:["Cancelar", "Continuar"], dangerMode: true, closeModal: false, closeOnClickOutside : false,})
        .then((willDelete) => {
            if (willDelete){
              swal({title: "Atenção!", text: "Números aleatórios não têm funcionalidade nos serviços listados no painel, por favor não tente utilizar o número virtual gerado em nossos serviços listados no painel, não retornara resposta do serviço", icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
                .then((willDelete) => {
                	Swal.fire('Aguarde.......');
                    	$.ajax({
                            url:'/cp/token',
                            type:"POST",
                            headers: {
                             'accept': "application/json",
                             'X-token-world-sms': keytoken,
                              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                            },
                            dataType: "json",
                            contentType: "application/json",
                            data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"server-sms", busca: "other", service: "any", valor: "5", country: tipo}}),
                            async:true,
                            success:function(data){
                            var json3 = data;
                                if(data['status'] == "true"){
                                  responsewhatsapp(token,tokenapi,keytoken,name,data);
                	            }else{
                	              Swal.fire(data['message']);
                	              $.ajax({
                                    url:'/cp/token',
                                    type:"POST",
                                    headers: {
                                       'accept': "application/json",
                                       'X-token-world-sms': keytoken,
                                       'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                                    },
                                    dataType: "json",
                                    contentType: "application/json",
                                    data: JSON.stringify({token: token, id: id, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
                                    async:true,
                                    success:function(data){
                                      var json2 = data;
                                      console.log(json2);
                                    },error:function (data){
                                      console.log("ok");
                                    }});
                	            } 
                            },error:function (data){
                              console.log("ok");
                            }
                    });
                });
            }
        });
    }else{
      	swal({title: "Ops!", text: json1['message'], icon: "/world-sms/image/atencao.png", button: "Ok", dangerMode: true, closeModal: false, closeOnClickOutside : false,})
            .then((willDelete) => {if (willDelete) {
            	$("#receber-sms-internacional-aleatorio").click();

            	$.ajax({
                  url:'/cp/token',
                  type:"POST",
                  headers: {
                    'accept': "application/json",
                    'X-token-world-sms': keytoken,
                    'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                  },
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({token: token, id: id, keytoken: keytoken, tokenid: id, type:{tipo:"cancel-sms"}}),
                  async:true,
                  success:function(data){
                    var json2 = data;
                    console.log(json2);
                  },error:function (data){
                    console.log("ok");
                  }
                });
            }});
        }
    },error:function (data){
      console.log("ok");
    }
}); 
}else{
   $("#receber-sms-internacional-aleatorio").click();
  }});}}});
});

$("#receber-sms-whatsapp-internacional").click(function(){
	Swal.fire({title: '<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Ola, '+name+'! Agora você pode receber SMS internacional com a <font color="red">WORLD-SMS</font>. Receba SMS internacional de seus serviços favoritos, netflix, whatsapp, google, entre outros serviços com mais facilidade! Basta clicar no botão <font color="red">"continuar"</font> e escolha o pais de sua preferência para gerar o seu número virtual do seu serviço favorito.</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não Quero`,}).then((result) => {

    if(result.isConfirmed) {
      Swal.fire({html:'<style type="text/css">@keyframes bounce { 0%, 20%, 60%, 100% { -webkit-transform: translateY(0); transform: translateY(0);} 40%{-webkit-transform: translateY(-20px); transform: translateY(-20px);} 80%{ -webkit-transform: translateY(-10px); transform: translateY(-10px);}} img { width: 100px } img, p { display: inline-block; } .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02; cursor: pointer; transition: all 400ms ease;} .efeito:hover {animation: bounce 1s;} .text {font-family: "Montserrat"}</style><img id="id_usa" src="/world-sms/image/usa.png" class="rounded efeito"></img></i><img id="id_india" src="/world-sms/image/india.png" class="rounded efeito"></img></i><img id="id_china" src="/world-sms/image/china.png" class="rounded efeito"></img></i><img id="id_canada" src="/world-sms/image/canada.png" class="rounded efeito"></img></i><img id="id_mexico" src="/world-sms/image/mexico.png" class="rounded efeito"></img></i><img id="id_argentina" src="/world-sms/image/argentina.png" class="rounded efeito"></img><h3><strong><font color="white">Por favor '+name+', escolha seu pais para continuar sua solicitação</font></h2>', confirmButtonText: 'Cancelar', showCloseButton: true, focusConfirm: false,});

      $("#id_usa").click(function(){
        console.log("USA");
        var tipo = 'usa';
        pais_id(tipo);
      });

      $("#id_india").click(function(){
        console.log("india");
        var tipo = 'india';
        pais_id(tipo);
      });

      $("#id_china").click(function(){
        console.log("china");
        var tipo = 'china';
        pais_id(tipo);  
      });

      $("#id_canada").click(function(){
        console.log("canada");
        var tipo = 'canada';
        pais_id(tipo);  
      });

      $("#id_mexico").click(function(){
        console.log("mexico");
        var tipo = 'mexico';
        pais_id(tipo);  
      });

      $("#id_argentina").click(function(){
        console.log("argentina");
        var tipo = 'argentina';
        pais_id(tipo);  
      });

    function pais_id(tipo){
          Swal.fire({title: '<style type="text/css">img { width: 120px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/emoji_feliz.png"></img><h4><strong><font color="white">Legal '+name+'! Você escolheu pais '+tipo+', gostaria continuar nesses pais escolhido?</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não`,}).then((result) => {
    if(result.isConfirmed){
    	Swal.fire({title: '<style type="text/css">img { width: 300px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 30px; margin: 10px; border: 10px solid: #F72F02} .button {background-color: #4CAF50;border: 12px; color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer; line-height: 1; padding: 1.2em 2.8em; text-decoration: none; text-align: center; text-transform: uppercase; font-family: "Montserrat", sans-serif;font-weight: 700; font-size: 11px; border-radius: 8px;}</style><img src="/world-sms/image/whatsapp.png"></img><h4><strong><font color="white">Olá, '+name+' ! Finalmente o serviço whatsapp esta disponível no painel <font color="red">WORLD-SMS</font>. Agora com serviço ativo, você pode criar contas whatsapp à-vontade por apenas 5 créditos por sms recebido do serviço</font></strong></h4>', showDenyButton: true, confirmButtonText: 'Continuar', denyButtonText: `Não`,}).then((result) => {
  
    if(result.isConfirmed) {
       Swal.fire({html:'<style type="text/css">img { width: 200px } img, p { display: inline-block; } .text {font-family: "Montserrat"} .rounded { background: #B960C5; font-size: 24px; padding: 10px; margin: 10px; border: 10px solid: #F72F02}</style><img src=/world-sms/image/alert.png></img><h3><strong><font color="white">Atenção '+name+'!</font></strong></h3><br><h2><font color="white"> Os números gerados para o serviço whatsapp não temos garantia estão 100% virgens para criar novas contas, talvez os números criados podem já existir contas já ativas no serviço. Caso queria continuar, basta clica no botão abaixo </font></h2>', showDenyButton: true, confirmButtonText: 'Continuar com serviço', denyButtonText: `Não`,}).then((result) => {
        if(result.isConfirmed){
        	Swal.fire('Aguarde.....');
        $.ajax({
            url:'/cp/service',
            type:"POST",
            headers: {
                'accept': "application/json",
                'X-token-world-sms': keytoken,
                'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
            },
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, type:{tipo:"whatsapp", type: "verifiy-service", country: tipo}}),
            async:true,
            success:function(data){
        if(data['status'] == "ONLINE"){
            $.ajax({
                url:'/cp/token',
                type:"POST",
                headers: {
                  'accept': "application/json",
                  'X-token-world-sms': keytoken,
                  'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
                },
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({token: token, tokenjwt: tokenapi, keytoken: keytoken, tokenid: id, type:{tipo:"solicty-sms-whatsapp", busca: "whatsapp", service: "any", country: tipo}}),
                async:true,
                success:function(data){
                	if(data['status'] == "true"){
                       responsewhatsapp(token,tokenapi,keytoken,name,data);
                	}else{
                	  Swal.fire(data['message']);
                	} 
               },error:function (data){
                 console.log("ok");
               }
            });
        }else if(data['status'] == "OFF"){ 
          Swal.fire('Ops, parece estamos sem estoque de números para o serviço whatsapp! Mas não se preocupe, logo em breve estoque estará abastecido :)');
        }else{
           Swal.fire('Erro ao se comunicar com servidor, tente novamente ou entre contato com suporte ajuda');
           console.log(data);
        }
       },error:function (data){
         console.log("ok");
       }
    });}})}
  })
}else{
   $("#receber-sms-whatsapp-internacional").click();
   }});}}
});

});

function blockaccount(){
	swal({ title: "Error", text: "Conta Bloqueada por suspeita fraudes no sistema, entre em contato com adimistrador do sistema para desbloquear sua conta", icon: "error",closeOnClickOutside: false, button: "Ok"});
	$("#blockid").html('<li><a href="#?conta-bloqueada" id="block-suspenso"><i class="fa fa-comments"></i><span>Receber SMS</span></a></li><li><a href="#?conta-bloqueada" id="block-suspenso"><i class="fa fa-comments"></i><span>Receber SMS (Aleatório)</span></a></li>');
}

$("#block-suspenso").click(function(){swal({ title: "Error", text: "Conta Bloqueada por suspeita fraudes no sistema, entre em contato com adimistrador do sistema para desbloquear sua conta", icon: "error",closeOnClickOutside: false, button: "Ok"});});

function alert(){

       $('.alert').addClass("show");
       $('.alert').removeClass("hide");
       $('.alert').addClass("showAlert");
       var smsNotifiy = new Audio('/audio/sms-notifiy.mp3');
       smsNotifiy.play();

        setTimeout(function(){
            $('.alert').removeClass("show");
            $('.alert').addClass("hide");
        },4000);
    }

        $('.close-btn').click(function(){
           $('.alert').removeClass("show");
           $('.alert').addClass("hide");
        });

setInterval(function(){
 const d = new Date(); 
 var segunds = d.getSeconds();
  $.ajax({
    url:'/token.json',
    type:"GET",
        headers:{
           'accept': "application/json",
           'X-token-world-sms': keytoken,
           'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
        },
        dataType: "json",
    contentType: "application/json",
    async:true,
    success:function(data){
      if(data['status'] == "true"){
        alert();
        $("#message-one").html(data['nome']+' recebeu um novo sms do serviço '+data['servico']+' :)');
        $.ajax({
           url:'/delType',
           type:"GET",
           headers: {
              'accept': "application/json",
              'X-token-world-sms': keytoken,
              'Authorization':'WORLD-SMS-TOKEN-'+smstoken,
            },
            dataType: "json",
            contentType: "application/json",
           async:true,
           success:function(data){
             console.log("Ok");
           },error:function (data){
            console.log("ok");
           }
        });
      }
    },error:function (data){
      console.log("ok");
    }
  });
},5000);

</script>
 
</body>
</html>