 <?php

session_start();
error_reporting(0);
$datone = date('Y-m-d');
date_default_timezone_set('America/Fortaleza');

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

if(strpos($_SERVER['REQUEST_METHOD'], "POST")!==false){

//require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

function dados($string,$start,$end){

    $str = explode($start,$string);
    $str = explode($end,$str[1]);
    return $str[0];
}

function dados2($string,$start,$end,$num){
     $str = explode($start, $string);
     $str = explode($end, $str[$num]);
    return $str[0];

}

$response_api = json_decode(file_get_contents("php://input"),true);
$usauriosdb = json_decode(file_get_contents(getcwd().'/world-sms/login/keysaccess.json'),true);

if($response_api['token']){

  $chave = base64_decode(explode("ey", explode(".", $response_api['tokenjwt'])[1])[1]);
  $type = $response_api['type']['tipo'];
  $busca = urldecode(strtolower($response_api['type']['busca']));
  $option = $response_api['type']['option'];
  $keytoken = $response_api['keytoken'];
  $token = $response_api['token'];
  $operadora = urldecode($response_api['operadora']);
  $service1 = $response_api['type']['service'];
  $valor = $response_api['type']['valor'];
  $pais = $response_api['type']['country'];
  $id = explode("___", $response_api['tokenid'])[1];
  $tipo = explode('-', $id); 
  $id1 = explode("-", $tipo[0])[0];
  $id2 =  $tipo[2];
  $id3 =  $tipo[3];
  $id4 =  $tipo[5];
  $id5 =  $tipo[6];
  $id6 =  $tipo[8];
  $id7 =  $tipo[9];
  $id8 =  $tipo[11];
  $tokenchave = "$id1$id2$id3$id4$id5$id6$id7$id8";

$verifyquantidade = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));

if($verifyquantidade['token'] != $_SESSION['tokenid']){
  session_destroy();
  $_SESSION = array();
  $deletetoken = mysqli_query($conexao, "DELETE token FROM usuarios WHERE access_key = '$token'");
  echo json_encode(array("status"=> "error", "message"=> "sessao expirada, realize seu login", "token"=> $verifyquantidade['token'], "code"=> "500"));
  exit();
}else{

  $ch = curl_init();
  curl_setopt_array($ch, array(
    CURLOPT_URL => 'https://5sim.net/v1/user/profile',
    CURLOPT_ENCODING => "GZIP",
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_HTTPHEADER => array(
         'Authorization: Bearer '.$chave.'',
         'Accept: application/json'
    ),
    CURLOPT_CUSTOMREQUEST => "GET",
  ));
  $r0 = curl_exec($ch);

if(json_decode($r0,true)["balance"] >= 10){

  if($verifyquantidade['modified'] >= $datone){$datestatus = "false";}else{$updatevalue = mysqli_query($conexao,"UPDATE usuarios SET registro = '0', modified=NOW() WHERE access_key = '$token'");$datestatus = "true";}

        if($verifyquantidade['registro'] >= 30){
           echo json_encode(array("status"=> "error", "message"=> "Que pena! Por segurança em nosso painel, você exerceu seu limite diário de solicitação de sms, tente novamente amanha", "id"=> "0", "datestatus"=> $datestatus, "code"=> "400"));
           exit();
        }else{
          if($token || $chave || $keytoken){

            if($type == "solicty-sms-whatsapp"){

               $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM operadora WHERE token = '{$keytoken}'"));
            if($selectSms['numero_tel']){
               echo json_encode(array("status"=> "error", "message"=> "request currently pending", "date"=> $datestatus, "id"=> $token, "code"=> "500"));
               exit();
            }else{
                $fim = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuarios WHERE access_key = '$token'"));
                $valor = "5";
              if($valor >= $fim['base_saldo']){
                echo json_encode(array("status"=> "error", "message"=> "Você não possui saldo suficiente para comprar este serviço", "code"=> "500"));
                exit();
              }else{
                   $ch = curl_init();
                   curl_setopt_array($ch, array(
                      CURLOPT_URL => 'https://5sim.net/v1/guest/prices?country='.$pais.'&product='.$busca,
                      CURLOPT_ENCODING => "GZIP",
                      CURLOPT_RETURNTRANSFER => 1,
                      CURLOPT_SSL_VERIFYHOST => 0,
                      CURLOPT_SSL_VERIFYPEER => 0,
                      CURLOPT_HTTPHEADER => array(
                          'Accept: application/json'
                      ),
                      CURLOPT_CUSTOMREQUEST => "GET",
                    ));
                  $r1 = curl_exec($ch);
                if(json_decode($r1,true)[$pais][$busca]["virtual4"][count] >= 0){
                        $ch = curl_init();
                        curl_setopt_array($ch, array(
                          CURLOPT_URL => 'https://5sim.net/v1/user/buy/activation/'.$pais.'/'.$service1.'/'.$busca,
                          CURLOPT_ENCODING => "GZIP",
                          CURLOPT_RETURNTRANSFER => 1,
                          CURLOPT_SSL_VERIFYHOST => 0,
                          CURLOPT_SSL_VERIFYPEER => 0,
                          CURLOPT_HTTPHEADER => array(
                               'Authorization: Bearer '.$chave.'',
                               'Accept: application/json'
                          ),
                           CURLOPT_CUSTOMREQUEST => "GET",
                        ));
                      $r2 = curl_exec($ch);
                    if(json_decode($r2,true)["phone"]){
                        $numero_tel = json_decode($r2,true)["phone"];
                        $id_tel = json_decode($r2,true)["id"];
                        $verifyquantidade = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));
                        if($verifyquantidade['registro'] == "0" || $verifyquantidade['registro'] == ""){$tipo = 0 + 1;}else{$tipo = $verifyquantidade['registro'] + 1;}
                        $updatevalue = mysqli_query($conexao,"UPDATE usuarios SET registro = '$tipo', modified=NOW() WHERE access_key = '$token'");

                        $smsId = mysqli_query($conexao,"INSERT INTO operadora (token, access_key, code_operadora, id, email, status, numero_tel, code_sms, quantidade, registro_sms, service, modified) VALUES ('$keytoken', '$token', '$id_tel', 'outros', 'bot.sistema@worldpremiumchks.com', 'pendente', '$numero_tel', '0000', '1', '0', '$busca', '$datone')");
                        if(mysqli_insert_id($conexao)){
                           $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));
                           if($selectSms['quantidade'] == "0" || $selectSms['quantidade'] == ""){$tipo = 0 + 1;}else{$tipo = $selectSms['quantidade'] + 1;}
                           $updatevalue = mysqli_query($conexao,"UPDATE usuarios SET quantidade = '$tipo', modified=NOW() WHERE access_key = '$token'");

                           echo json_encode(array("status"=> "true", "numero"=> $numero_tel, "status-sms"=> json_decode($r2,true)["status"], "status-code"=> "waiting code", "id"=> $id_tel, "message"=> "virtual number created successfully",  "code"=> "200"));
                            exit();
                        }else{
                          echo json_encode(array("status"=> "error", "message"=> "we are currently unable to process your request, please try again or contact support help", "code"=> "500"));
                          exit();
                        }
                    }else{
                       echo json_encode(array("status"=> "error", "message"=> "error generating your virtual number try again. error code: ".$r2, "respose-api"=> $r2, "code"=> "500"));
                       exit();
                    }
                }else{
                  echo json_encode(array("status"=> "error", "message"=> "Estamos sem estoque números disponíveis para o serviço whatsapp, aguarde 1 hora para o sistema realizar a recarga automaticamente", "token"=> $keytoken, "code"=> "500"));
                  exit();
                }
              }
             }
            }else if($type == "server-sms"){
                 $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM operadora WHERE token = '{$keytoken}'"));
              if($selectSms['numero_tel']){
               echo json_encode(array("status"=> "error", "message"=> "request currently pending", "date"=> $datestatus, "id"=> $token, "code"=> "500"));
               exit();
              }else{
                 $fim = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT * FROM usuarios WHERE access_key = '$token'"));
                if($valor >= $fim['base_saldo']){
                  echo json_encode(array("status"=> "error", "message"=> "Você não possui saldo suficiente para comprar este serviço", "code"=> "500"));
                  exit();
                }else{
                   $ch = curl_init();
                      curl_setopt_array($ch, array(
                        CURLOPT_URL => 'https://5sim.net/v1/user/buy/activation/'.$pais.'/'.$service1.'/'.$busca,
                        CURLOPT_ENCODING => "GZIP",
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_HTTPHEADER => array(
                              'Authorization: Bearer '.$chave.'',
                              'Accept: application/json'
                        ),
                        CURLOPT_CUSTOMREQUEST => "GET",
                      ));
                      $r2 = curl_exec($ch);

                    if(json_decode($r2,true)["phone"]){

                        $numero_tel = json_decode($r2,true)["phone"];
                        $id_tel = json_decode($r2,true)["id"];
                        $verifyquantidade = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));
                        if($verifyquantidade['registro'] == "0" || $verifyquantidade['registro'] == ""){$tipo = 0 + 1;}else{$tipo = $verifyquantidade['registro'] + 1;}
                        $updatevalue = mysqli_query($conexao,"UPDATE usuarios SET registro = '$tipo', modified=NOW() WHERE access_key = '$token'");

                        $smsId = mysqli_query($conexao,"INSERT INTO operadora (token, access_key, code_operadora, id, email, status, numero_tel, code_sms, quantidade, registro_sms, service, modified) VALUES ('$keytoken', '$token', '$id_tel', '$service1', 'bot.sistema@worldpremiumchks.com', 'pendente', '$numero_tel', '0000', '1', '0', '$busca', '$datone')");
                        if(mysqli_insert_id($conexao)){
                           $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));
                           if($selectSms['quantidade'] == "0" || $selectSms['quantidade'] == ""){$tipo = 0 + 1;}else{$tipo = $selectSms['quantidade'] + 1;}
                           $updatevalue = mysqli_query($conexao,"UPDATE usuarios SET quantidade = '$tipo', modified=NOW() WHERE access_key = '$token'");

                           echo json_encode(array("status"=> "true", "numero"=> $numero_tel, "status-sms"=> json_decode($r2,true)["status"], "status-code"=> "waiting code", "id"=> $id_tel, "message"=> "virtual number created successfully",  "code"=> "200"));
                            exit();
                        }else{
                          echo json_encode(array("status"=> "error", "message"=> "we are currently unable to process your request, please try again or contact support help", "code"=> "500"));
                          exit();
                        }
                    }else{
                       echo json_encode(array("status"=> "error", "message"=> "error generating your virtual number try again. error code: ".$r2, "respose-api"=> $r2, "code"=> "500"));
                       exit();
                    }
                }
              }
            }else if($type == "status-sms"){
              $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM operadora WHERE token = '{$keytoken}'"));
                if($selectSms['numero_tel']){

                    $ch = curl_init();
                    curl_setopt_array($ch, array(
                        CURLOPT_URL => 'https://5sim.net/v1/user/check/'.$selectSms['code_operadora'],
                        CURLOPT_ENCODING => "GZIP",
                        CURLOPT_RETURNTRANSFER => 1,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                        CURLOPT_HTTPHEADER => array(
                          'Authorization: Bearer '.$chave.'',
                          'Accept: application/json'
                        ),
                        CURLOPT_CUSTOMREQUEST => "GET",
                      ));
                    $r3 = curl_exec($ch);

                    if(strpos($r3,'"sms":[],')!==false){
                      echo json_encode(array("status"=> "waiting_for_the_code", "message"=> "waiting for sms", "status-sms"=> json_decode($r3,true)["status"], "code"=> "400")); 
                      exit();
                    }else if(json_decode($r3,true)["sms"][0]["text"]){
                      $selectUsers = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios where access_key = '$token'"));
                      $verifyservice = file_get_contents("http://24.152.38.212/api-v1/valores.php?token=$tokenchave");
                      $message = json_decode($r3,true)["sms"][0]["text"];

                        /* ------------------------------------- sistema de registro clientes ------------------------------------- */
                           $usauriosdb = file_get_contents(getcwd().'/world-sms/cp/smsregistro.json');
                           $datadb = json_decode($usauriosdb, true);
                           $serviceone = $selectSms['service'];
                           $valor_1 = json_decode($verifyservice,true)["services"][$serviceone]["valor"];
                           $datadb[$token][] = array("numero"=> $selectSms['numero_tel'], "operadora"=> $selectSms['id'], "service"=> $selectSms['service'], "message"=> $message, 'status'=> 'concluido', "datetime"=> date('Y-m-d / H:m:s'), "valor"=> $valor_1);
                           $dsalva = json_encode($datadb,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
                           $salva = file_put_contents(getcwd().'/world-sms/cp/smsregistro.json', $dsalva);

                           $usauriosdb = file_get_contents(getcwd().'/world-sms/cp/smstokenregistro.json');
                           $datadb = json_decode($usauriosdb, true);
                           $serviceone = $selectSms['service'];
                           $datadb[$token][] = array("numero"=> $selectSms['numero_tel'], "operadora"=> $selectSms['id'], "service"=> $selectSms['service'], "message"=> $message, 'status'=> 'concluido', "datetime"=> date('Y-m-d / H:m:s'), "valor"=> $valor_1);
                           $dsalva = json_encode($datadb,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
                           $salva = file_put_contents(getcwd().'/world-sms/cp/smstokenregistro.json', $dsalva);
                        /* ------------------------------------- sistema de registro clientes ------------------------------------- */

                        /* ------------------------------------- sistema de cobrança ------------------------------------- */
                           $fim = mysqli_fetch_assoc(mysqli_query($conexao, "select * from usuarios where access_key = '$token'"));
                           $service = $selectSms['service'];
                           $tipo1 = $fim['base_saldo'] - 5;// aqui cobrara o saldo ...
                           $basesaldo = mysqli_query($conexao,"UPDATE usuarios SET base_saldo = '$tipo1', modified=NOW() WHERE access_key = '$token'");
                        /* ------------------------------------- sistema de cobrança ------------------------------------- */

                        /* ------------------------------------- sistema de notificaçao popup ------------------------------------- */
                           $notifiyusers = array("nome"=> $selectUsers['usuario'], "servico"=> $selectSms['service'], "response"=> time(), "time"=>  date("s"), "status"=> "true");
                           $notifiyusers = json_encode($notifiyusers,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
                           $salvaone = file_put_contents(getcwd().'/token.json', $notifiyusers);
                        /* ------------------------------------- sistema de notificaçao popup ------------------------------------- */

                          $ch = curl_init();
                            curl_setopt_array($ch, array(
                              CURLOPT_URL => 'https://5sim.net/v1/user/finish/'.$selectSms['code_operadora'],
                              CURLOPT_ENCODING => "GZIP",
                              CURLOPT_RETURNTRANSFER => 1,
                              CURLOPT_SSL_VERIFYHOST => 0,
                              CURLOPT_SSL_VERIFYPEER => 0,
                              CURLOPT_HTTPHEADER => array(
                                  'Authorization: Bearer '.$chave.'',
                                  'Accept: application/json'
                              ),
                              CURLOPT_CUSTOMREQUEST => "GET",
                            ));
                            $r4 = curl_exec($ch);

                        echo json_encode(array("status"=> "true", "msg"=> $message, "numero"=> $selectSms['numero_tel'], "status-sms"=> "concluido", "operadora"=> $selectSms['id'], "message"=> "sms received successfully", "code"=> "200"));
                        $deletToken = mysqli_query($conexao, "DELETE FROM sms WHERE access_key ='$token'");
                        $deleteSms = mysqli_query($conexao, "DELETE FROM operadora WHERE token ='$keytoken'");
                        exit();
                    }else{
                      echo json_encode(array("status"=> "waiting_for_the_code", "message"=> "waiting for sms", "status-sms"=> $r3, "code"=> "400")); 
                        exit();
                    }
                }else{
                    echo json_encode(array("status"=> "error", "message"=> "service not registered in our system", "code"=> "500")); 
                    exit();
                }
            }else if($type == "cancel-sms"){
              $selectSms = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM operadora WHERE token = '{$keytoken}'"));
              $verifyaccessKey = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM sms WHERE access_key = '$token'"));
                if($selectSms['numero_tel'] || $verifyaccessKey['operadora']){

                      $ch = curl_init();
                      curl_setopt_array($ch, array(
                          CURLOPT_URL => 'https://5sim.net/v1/user/cancel/'.$selectSms['code_operadora'],
                          CURLOPT_ENCODING => "GZIP",
                          CURLOPT_RETURNTRANSFER => 1,
                          CURLOPT_SSL_VERIFYHOST => 0,
                          CURLOPT_SSL_VERIFYPEER => 0,
                          CURLOPT_HTTPHEADER => array(
                                'Authorization: Bearer '.$chave.'',
                                'Accept: application/json'
                          ),
                           CURLOPT_CUSTOMREQUEST => "GET",
                        ));
                      $r5 = curl_exec($ch);

                    echo json_encode(array("status"=> "true", "message"=> "service canceled", "status-sms"=> $r5, "code"=> "200"));
                    $deletToken = mysqli_query($conexao, "DELETE FROM sms WHERE access_key ='$token'");
                    $deleteSms = mysqli_query($conexao, "DELETE FROM operadora WHERE token ='$keytoken'");
                    exit();
                }else{
                    echo json_encode(array("status"=> "error", "message"=> "service not registered in our system", "code"=> "500")); 
                    exit();
                }
            }else{
              echo json_encode(array("status"=> "error", "message"=> "service not informed or not entered", "code"=> "500"));
              exit();
            }
        }else{
           echo json_encode(array("status"=> "error", "message"=> "client token not found contact your system administrator to fix the problem error code: 567", "code"=> "500"));
           exit();
        }
    }
}else{
  echo json_encode(array("status"=> "error", "message"=> "error completing your request, try again", "token"=> $keytoken, "code"=> "400"));
  exit();
 }
}
}else{
  echo json_encode(array("status"=> "error", "message"=> "method not recognized GET POST PUT", "code"=> "500"));
    exit();
 }
}else{
  file_put_contents(getcwd()."/ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  echo json_encode(array("status"=> "error", "message"=> "method not recognized GET POST PUT", "code"=> "500"));
  exit();
}


?>