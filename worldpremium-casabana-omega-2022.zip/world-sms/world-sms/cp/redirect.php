<?php

session_start();
error_reporting(0);

require_once  getcwd()."/verificar_login.php";

date_default_timezone_set("Brazil/East");
	
    $response_api = json_decode(file_get_contents("php://input"),true);
    $token = urldecode($response_api['token-response']);
	$token = 'eyJzdGF0dXMiOiJ0cnVlIiwibWVzc2FnZSI6ImN1c3RvbWVyIGlzI.'.base64_encode(base64_encode('{"status":"true","message":"customer is logged in","cliente": '.$token.'}'));

    if(empty($token)) {
	   echo json_encode(array("status"=> "false", "message"=> "token redirect not recognized error mal format url", "code"=> "500"));
	   exit();
    }else{
      echo json_encode(array("status"=> "success", "message"=> "token redirect done successfully", "code"=> "300", "redirect"=> $token, "url"=> "https://worldpremiumchks.com", "code"=> "200"));
	  exit();
	}














?>