<?php

error_reporting(0);

function dados($string,$start,$end){

    $str = explode($start,$string);
    $str = explode($end,$str[1]);
    return $str[0];
}


 
 $response_api = json_decode(file_get_contents("php://input"),true);

if($response_api['type']['tipo']){

 $servico = $response_api['type']['tipo'];
 $pais = $response_api['type']['country'];

$ch = curl_init();
curl_setopt_array($ch, array(
  CURLOPT_URL => 'https://5sim.net/v1/guest/products/'.$pais.'/any',
  CURLOPT_ENCODING => "GZIP",
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  //CURLOPT_HEADER => 1,
  CURLOPT_HTTPHEADER => array(
          'Accept: application/json, text/plain, */*',
          'Accept-Language: pt-BR,pt;q=0.9',
          'Connection: keep-alive',
          'Host: 5sim.net',
          'Referer: https://5sim.net/',
          'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36 OPR/79.0.4143.73'
  ),
  CURLOPT_CUSTOMREQUEST => "GET",
  //CURLOPT_POSTFIELDS => ''
));
$fim = curl_exec($ch);
   
    foreach (json_decode($fim,true) as $key => $value){
       $tipo .= json_encode(array("servico"=>[ $key => ["quantidade"=> json_decode($fim,true)[$key][Qty],]]));
    }
  
if($servico == "whatsapp"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '5';
}else if($servico == "99pop" || $servico == "99"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';
}else if($servico == "caixa"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "ifood"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "keypay"){

  $id = "other";
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "abastece"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "kwai"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "dotz"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "stone"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "picpay"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "banqi"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "vk"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "netflix"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "discord"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "tiktok"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "amazon"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "yalla"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';
 
}else if($servico == "okru"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "viber"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "wechat"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "google"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "facebook"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "twitter"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "paypal"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "shopee"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "outros"){

  $id = 'other';
  if(dados($tipo,'"servico":{"other":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "instagram"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '2';

}else if($servico == "olx"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "telegram"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '4';

}else if($servico == "microsoft"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '3';

}else if($servico == "uber"){

  $id = $servico;
  if(dados($tipo,'"servico":{"'.$servico.'":{"quantidade":', '}') == 0){$status = 'OFF';}else{$status = 'ONLINE';}
  $valor = '5';

}

 echo  json_encode(array("servico"=> $id, "valor"=> $valor, "quantidade"=> dados($tipo,'"servico":{"'.$id.'":{"quantidade":', '}'), "status"=> $status, "code"=> "200", "message"=> "sucesso true", "country"=> $pais));
 exit();
}else{
  die(json_encode(array("status"=> "error", "message"=> "GET POST method not found", "code"=> "500")));
  exit();
}












?>