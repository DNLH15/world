<?php

session_start();
error_reporting(0);
$datone = date('Y-m-d');

if (@fsockopen($_SERVER['REMOTE_ADDR'], 80, $errstr, $errno, 1)) {
  file_put_contents(getcwd()."./ipsBlocks.txt", $_SERVER['REMOTE_ADDR']."\n\r",FILE_APPEND);
  die('Proxy access not allowed'); 
} 

require_once  getcwd()."/verificar_login.php";
require_once  getcwd()."/conexao/code.php";

$response_api = json_decode(file_get_contents("php://input"),true);
$usauriosdb = file_get_contents(getcwd().'/world-sms/login/keysaccess.json');

if($response_api['token']){

$token = $response_api['token'];


$verifyquantidade = mysqli_fetch_assoc(mysqli_query($conexao,"SELECT * FROM usuarios WHERE access_key = '{$token}'"));

if($verifyquantidade['token'] != json_decode($usauriosdb,true)[$token]['token']){
  session_destroy();
  $_SESSION = array();
  $deletetoken = mysqli_query($conexao, "DELETE token FROM usuarios WHERE access_key = '{$token}'");
  echo json_encode(array("status"=> "error", "message"=> "sessao expirada, realize seu login", "token"=> $token, "code"=> "500"));
  exit();
}else{

	if (5 >= $verifyquantidade['base_saldo']){
		echo json_encode(array("status"=> "error", "message"=> "você não possui saldo suficiente para continuar sua solicitação, realize uma recarga e tente novamente", "code"=> "500"));
        exit();
	}else{
	    if($verifyquantidade['registro'] == "0" || $verifyquantidade['registro'] == "1"){
	  	  echo json_encode(array("status"=> "error", "message"=> "você não pode solicitar limite diário, sua conta não esta limitada. Tente novamente apos sua conta estiver limitada", "code"=> "400"));
          exit();
	    }else{
            if($verifyquantidade['base_saldo']){
            $saldo = $verifyquantidade['base_saldo'] - 5;
         	  $updatevalue = mysqli_query($conexao,"UPDATE usuarios SET registro = '0', base_saldo = '$saldo', modified=NOW() WHERE access_key = '$token'");
         	  echo json_encode(array("status"=> "true", "message"=> "Seu limite diário foi liberado com sucesso", "token"=> $token, "code"=> "200"));
              exit();
            }else{
         	  echo json_encode(array("status"=> "error", "message"=> "não foi possível identificar o cliente, realize seu login novamente no painel", "code"=> "500"));
              exit();
            }
	    } 
	}
  }
}else{
  echo json_encode(array("status"=> "error", "message"=> "method not recognized GET POST PUT", "code"=> "500"));
  exit();
}













?>