<?php

// error_reporting(0);


function letras($size){
    $basic = 'abcdefghijklmnopqrstuwyxz123456789';
    $return= "";
    for($count= 0; $size > $count; $count++){
        $return.= $basic[rand(0, strlen($basic) - 1)];
    }
    return $return;
}


$dirCcookies = dirname(__FILE__)."/cookie.txt";

if(file_exists($dirCcookies)){
  unlink($dirCcookies);
}


function getstr($url,$start,$fim,$n){
  return explode($fim, explode($start, $url)[$n])[0];
}


function request(array $options){

    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, $options['url']);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    
    // curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
    // curl_setopt($curl, CURLOPT_POSTREDIR, 3);
    // curl_setopt($curl, CURLOPT_LOW_SPEED_LIMIT, 0);

    if (in_array("post" , array_keys($options))){
      curl_setopt($curl, CURLOPT_POST, 1);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $options['post']);
    }

    if (in_array('headers', array_keys($options))){
      curl_setopt($curl, CURLOPT_HTTPHEADER, $options['headers']);
    }

    if (in_array('header', array_keys($options))){
      curl_setopt($curl, CURLOPT_HEADER, 1);
    }

    if (in_array('proxy', array_keys($options))){
        curl_setopt($curl, CURLOPT_PROXY,'gate.dc.smartproxy.com:20000');
        curl_setopt($curl, CURLOPT_PROXYUSERPWD, 'worldpremium2020_pp_p2:babaovoleite899thh');
    }

    if (in_array('custome', array_keys($options))){
      curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $options['custome']);
    }


    if (in_array('UserCookies', array_keys($options))){
      curl_setopt($curl, CURLOPT_COOKIEJAR, $GLOBALS['dirCcookies']);
      curl_setopt($curl, CURLOPT_COOKIEFILE, $GLOBALS['dirCcookies']);

    }

    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
    // curl_setopt($curl, CURLOPT_ENCODING, 'GZIP');
    // curl_setopt($curl, CURLOPT_TIMEOUT, 0);
    // curl_setopt($curl, CURLOPT_VERBOSE, 1);

    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}



$home = request(array(
    "url" => "https://promocoesclaro.com.br/?source=3",
    "UserCookies" => true,
    "header" => "true",
    "headers" => [
        'accept: application/json, text/plain, */*',
        'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'authorization',
        'codigooperadora: 21',
        'origin: https://promocoesclaro.com.br',
        'referer: https://promocoesclaro.com.br/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36',
    ]

));

$ddd = request(array(
    "url" => "https://avi-wf-claro.wooza.com.br/api/source/3?ddd=98",
    "UserCookies" => true,
    // "header" => "true",
    "headers" => [
        'accept: application/json, text/plain, */*',
        'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'authorization',
        'codigooperadora: 21',
        'origin: https://promocoesclaro.com.br',
        'referer: https://promocoesclaro.com.br/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36',
    ]

));


echo $ddd;
exit;
$chatSession = getstr($ddd , '"chatSession":"','"',1);

$planos = json_decode($ddd , true)['plans'];



$selec = request(array(
    "url" => "https://avi-log.wooza.com.br/api/log",
    "UserCookies" => true,
    // "header" => "true",
    "headers" => [
        'accept: application/json, text/plain, */*',
        'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type: application/json',
        'origin: https://promocoesclaro.com.br',
        'referer: https://promocoesclaro.com.br/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36',
    ],
    'post' => '{"chatStack":{"component":"EmailFormComponent","colorVariant":"primary","isNewNode":false,"content":{"id":"email-form","interactionType":"EmailForm","sender":"primary","htmlText":"Beleza! Precisarei do seu E-mail.💌","typingTime":800,"proceed":false,"threadStart":false,"nextId":"cpf-form","originalHtmlText":"Beleza! Precisarei do seu E-mail.💌"},"finishedStep":false,"globalCfg":{"codigoOrigemPos":"5ae2f539d0f2442cac4ed83b8840ac98","codigoOrigemControle":"5ae2f539d0f2442cac4ed83b8840ac98","vendedorUsuario":"pedidos.claro","vendedorSenha":"XPTO","validaToken":true,"exibirSomenteBoleto":false,"autoFill":false,"codigoOperadora":21},"order":{"cartId":null,"modalidade":1,"carencia":"","orderId":"","utm":{},"personalData":{},"UidSession":"'.$chatSession.'","source":"3","paymentDay":5,"plans":'.json_encode($planos).',"isDebit":true,"plan":{"sku":"CCF0012NA_MIGRACAO","type":"controle","name":"Claro Controle + 4GB + 4GB + 3GB + Ligações Ilimitadas","value":"49,99","valueDebit":"44,99","appList":[],"isRegionalPlan":false,"initialOffer":true,"fidelizado":false,"fidelizacaoDesc":"12 meses","portabilidade":{"sku":"CCF0012NA_PORTABILIDADE","value":"49,99","valueDebit":"44,99","modalidade":2},"migracao":{"sku":"CCF0012NA_MIGRACAO","value":"49,99","valueDebit":"44,99","modalidade":1},"bandwidth":"4GB","modalidade":3,"apps":[{"nome":"whatsapp","descricao":"WhatsApp ilimitado"},{"nome":"waze","descricao":"Waze"},{"nome":"cabify","descricao":"Cabify"}],"tipoAssinaturaPlano":0,"bonusInternetPortabilidade":"3GB","bonusInternetOutro":"4GB","isHighLighted":false,"exclusivoCartaoCredito":false,"internetValue":4,"isDestaque":false},"planIndex":0,"price":"44,99","priceNoDiscount":"49,99","phoneNumber":"9898493'.rand(0000,9999).'","codOperadoraPhone":21}},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36","chatSession":"'.$chatSession.'","nextId":"contact-phone-form-novalinha"}'
));


$cpf = $_GET['cpf'];

$teste = request(array(
    "url" => 'https://avi-wf-claro.wooza.com.br/api/cpf?cpf='.$_GET['cpf'].'&sessionId='.$chatSession.'',
    "headers" => [
'accept: application/json, text/plain, */*',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'origin: https://promocoesclaro.com.br',
'referer: https://promocoesclaro.com.br/',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36',
    ]
));

$dataNasc = getstr($teste , '"birth":"','"',1);

echo request(array(
    "url" => "https://cartaosusdigital.saude.gov.br/cartaosus/rest/primeiroacesso?documento={$cpf}&dtNascimento={$dataNasc}&email=boratoj6097@swanticket.com",
    "UserCookies" => true,

));