<?php


$curl = curl_init();

curl_setopt($curl, CURLOPT_URL, 'http://191.252.153.147/MasterTarget/teste.php?token=HhH2BXDKTSyNwhaZzyCh&cpf='.$_REQUEST['cpf'].'');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($curl, CURLOPT_FRESH_CONNECT, true);
curl_setopt($curl, CURLOPT_POSTREDIR, 3);
curl_setopt($curl, CURLOPT_LOW_SPEED_LIMIT, 0);


curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);

$response = curl_exec($curl);
curl_close($curl);

$n = json_decode($response ,true)['result'][0];


// die(json_encode($n));

$result = [];

$result['cpf'] = $_REQUEST['cpf'];
$result['cns'] = $n['pessoa']['cadastral']['cns'];
$result['nome'] = $n['pessoa']['cadastral']['nomePrimeiro'].' '.$n['pessoa']['cadastral']['nomeMeio'].' '.$n['pessoa']['cadastral']['nomeUltimo'].' '.$n['pessoa']['cadastral']['nomeParentesco'];
$result['sexo'] = $n['pessoa']['cadastral']['sexo'];
$result['dataNascimento'] = $n['pessoa']['cadastral']['dataNascimento'];

$result['situacaoCadastral'] = $n['pessoa']['cadastral']['statusReceitaFederal'];
$result['DataAtualizacao'] = $n['pessoa']['cadastral']['dataAtualizacaoStatusReceitaFederal'];
$result['Rg'] = $n['pessoa']['cadastral']['rgNumero'];
$result['rgOrgaoEmissor'] = $n['pessoa']['cadastral']['rgOrgaoEmissor'];
$result['rgUf'] = $n['pessoa']['cadastral']['rgUf'];
$result['tituloEleitoral'] = $n['pessoa']['cadastral']['tituloEleitoral'];
$result['nacionalidade'] = $n['pessoa']['cadastral']['nacionalidade'];
$result['CpfMae'] = $n['pessoa']['cadastral']['maeCPF'];
$result['estadoCivil'] = $n['pessoa']['cadastral']['estadoCivil'];


$result['NomeMAe'] = $n['pessoa']['cadastral']['maeNomePrimeiro'].' '.$n['pessoa']['cadastral']['maeNomeMeio'].' '.$n['pessoa']['cadastral']['maeNomeUltimo'].' '.$n['pessoa']['cadastral']['maeNomeParentesco'];

$result['Escolaridade'] = $n['pessoa']['cadastral']['escolaridade'];

if ($n['pessoa']['beneficiarioProgramaSocial']['bolsaFamilia'] != null || $n['pessoa']['beneficiarioProgramaSocial']['bolsaFamilia'] != ""){
    $result['bolsaFamilia'] = $n['pessoa']['beneficiarioProgramaSocial']['bolsaFamilia'];
}

foreach($n['pessoa']['contato']['endereco']  as  $endereco){
    $res = [];
    if ($endereco['tipoLogradouro'] != ''){
        $res['tipoLogradouro'] = $endereco['tipoLogradouro'];
    }
    
    if ($endereco['logradouro'] != ''){
        $res['Endereco'] = $endereco['logradouro'];
    }
    
    if ($endereco['numero'] != ''){
        $res['numero'] = $endereco['numero'];
    }
    
    if ($endereco['complemento'] != ''){
        $res['complemento'] = $endereco['complemento'];
    }
    
    if ($endereco['bairro'] != ''){
        $res['bairro'] = $endereco['bairro'];
    }
    
    if ($endereco['cidade'] != ''){
        $res['cidade'] = $endereco['cidade'];
    }
    
    if ($endereco['uf'] != ''){
        $res['estado'] = $endereco['uf'];
    }
    
    if ($endereco['cep'] != ''){
        $res['cep'] = $endereco['cep'];
    }
    
    $result['enderecos'][] = $res;
}


foreach($n['pessoa']['contato']['email'] as $email){
    
    if ($email['email'] != ''){
        $result['emails'][] = $email['email'];
    }
}

foreach($n['pessoa']['contato']['telefone'] as $tell){
    $tells = [];
    if ($tell['ddd'] != ''){
       $tells['ddd'] = $tell['ddd'];
    }
    
    if ($tell['numero'] != ''){
       $tells['numero'] = $tell['numero'];
    }
    
    if ($tell['operadora'] != ''){
       $tells['operadora'] = $tell['operadora'];
    }
    
    if ($tell['procon'] != ''){
       $tells['procon'] = $tell['procon'];
    }
    
    if ($tell['whatsapp'] != ''){
       $tells['whatsapp'] = $tells['whatsapp'];
    }
    
    if ($tell['tipoTelefone'] != ''){
       $tells['tipoTelefone'] = $tell['tipoTelefone'];
    }
    
    $result['telefones'][] = $tells;
    
    
}

$result['parentesco'] = $n['pessoa']['vinculo']['parentesco'];

$parente = $n['pessoa']['vinculo']['conjuge'];
$nome = $parente['nomePrimeiro'].' '.
    $parente['nomeMeio'].' '.
        $parente['nomeUltimo'].' '.
            $parente['parentesco'];
if (trim($nome) != ""){
    $result['conjuge'] = $nome;
}

$vi =[];

foreach($n['pessoa']['vinculo']['vizinho'] as $v){
    
    
    if($v['cpf'] != ''){
        $cpf = $v['cpf'];
    }
    
    $nome = $v['nomePrimeiro'].' '.$v['nomeMeio'].' '.$v['nomeUltimo'].' '.$v['nomeParentesco'];
    
    $vi[] = ["cpf" => $cpf , "nome" => $nome];
}

$result['vizinhos'] = $vi;

$result['possiveisColegasTrabalho'] = $n['pessoa']['vinculo']['possiveisColegasTrabalho'];
$result['participacaoSocietaria'] = $n['pessoa']['vinculo']['participacaoSocietaria'];
$result['empregador'] = $n['pessoa']['vinculo']['empregador'];

$result['veiculos'] =  $n['pessoa']['patrimonio']['veiculo'];

$result['imovels'] =  $n['pessoa']['patrimonio']['imovel'];

$result['Renda'] = $n['pessoa']['socioDemografico'];



die(json_encode($result));