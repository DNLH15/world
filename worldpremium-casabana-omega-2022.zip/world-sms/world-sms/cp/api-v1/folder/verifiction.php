<?php
header('Content-Type: application/json');

$cone =  include("../../conexao/code.php");

$id = $_GET['id'];


$sql = "SELECT COUNT(*) as total FROM `usuarios` WHERE `id_telegram` = '$id'";
$fim= mysqli_query($conexao, $sql);
$dados= mysqli_fetch_assoc($fim);

if ($dados['total'] == 0){
    die(json_encode(array("code" => "404","msg" => "<b>Desculpa , mas vc nao esta longado !</b>"),JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT));
}else{
	    
	    $users =  file_get_contents("../../login-usuario/keysaccess.json");
	    $users = json_decode($users , true);
	    
        $sql = "SELECT *  FROM `usuarios` WHERE `id_telegram` = '$id'";
        $fim= mysqli_query($conexao, $sql);
        $dados= mysqli_fetch_assoc($fim);
        
        $key_acess = $dados['access_key'];
        
        if ($users[$key_acess]){
            $users[$key_acess]['id_telegram'] = $id;
            $dsalva = json_encode($users,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT);
            file_put_contents("../../login-usuario/keysaccess.json",$dsalva);
        }
        $dataCas = date('d/m/Y H:i:s',strtotime($dados['data_cadastro']));
        
        
		die(json_encode(array("code" => "200", "msg" => "<b>Esta e sua conta , as lives que enviarei seram dela !</b>\n<b>Nome:</b> {$dados[nome]}\n<b>Usuario:</b> {$dados[usuario]}\n<b>Email:</b> {$dados[email]}\n<b>Data Cadastro:</b> {$dataCas}\n<b>Sado:</b> {$dados[base_saldo]}\n<b>ccs aprovadas:</b> {$dados[ccs_aprovadas]}\n<b>login aprovadas:</b> {$dados[login_aprovadas]}"),JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT));
}




