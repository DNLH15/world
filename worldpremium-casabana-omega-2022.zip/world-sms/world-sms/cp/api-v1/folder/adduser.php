<?php

$cone =  include("../../conexao/code.php");


$id = $_GET["id"];
$user = $_GET['user'];
$pwd = $_GET['senha'];

$sql = "SELECT COUNT(*) as total FROM `usuarios` WHERE `id_telegram` = '$id'";
$fim= mysqli_query($conexao, $sql);
$dados= mysqli_fetch_assoc($fim);

if ($dados['total'] == 0){
	$senha = sha1(base64_encode(md5($pwd)));

    if (strpos($user,"@") !==false and strpos($user,".") !==false){
        $sql = "SELECT count(*) as total FROM `usuarios` WHERE `email` = '$user' and `senha` ='$senha'";
    }else{
        $sql = "SELECT count(*) as total FROM `usuarios` WHERE `usuario` = '$user' and `senha` ='$senha'";
    }
	$fim= mysqli_query($conexao, $sql);
	$xx= mysqli_fetch_assoc($fim);

	if ($xx['total'] == 0){
	
		die(json_encode(array("status" => "404","msg"=>"usuario ou senha invalidos $user - $pwd")));
	}else{

		$sql = "SELECT `access_key` FROM `usuarios` WHERE `usuario` = '$user'";
		
		if (strpos($user,"@") !==false and strpos($user,".") !==false){
        	$sql = "SELECT `access_key` FROM `usuarios` WHERE `email` = '$user'";
         }else{
         	$sql = "SELECT `access_key` FROM `usuarios` WHERE `usuario` = '$user'";
         }
		$fim= mysqli_query($conexao, $sql);
		$key= mysqli_fetch_assoc($fim)['access_key'];


		$sql = "UPDATE `usuarios` SET `id_telegram`= '$id' WHERE `access_key` = '$key'";
		$fim= mysqli_query($conexao, $sql);

		die(json_encode(array("status" => "200","msg"=>"usuario altenticado" , "key" => $key)));
	}

}else{
		if (strpos($user,"@") !==false and strpos($user,".") !==false){
        	$sql = "SELECT `access_key` FROM `usuarios` WHERE `email` = '$user'";
         }else{
         	$sql = "SELECT `access_key` FROM `usuarios` WHERE `usuario` = '$user'";
         }
         
		$fim= mysqli_query($conexao, $sql);
		$key= mysqli_fetch_assoc($fim)['access_key'];


		$sql = "UPDATE `usuarios` SET `id_telegram`= '$id' WHERE `access_key` = '$key'";
		$fim= mysqli_query($conexao, $sql);

		die(json_encode(array("status" => "200","msg"=>"usuario altenticado" , "key" => $key)));
}




