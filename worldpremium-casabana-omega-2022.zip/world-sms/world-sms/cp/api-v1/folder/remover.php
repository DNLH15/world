<?php


$cone =  include("../../conexao/code.php");


if ($_GET["delete"]){
    $id = $_GET['id'];
    $sql = "UPDATE `usuarios` SET `id_telegram` = '' WHERE `id_telegram` = '$id'";
    $fim= mysqli_query($conexao, $sql); 
}


$key = $_GET['e'];

if ($_GET['lives']){
    $sql = "SELECT `base_saldo` FROM `usuarios` WHERE `access_key` = '$key'";
    $fim= mysqli_query($conexao, $sql);
    if (mysqli_fetch_assoc($fim)['base_saldo'] >= 5){
        die(json_encode(array("status" => 200)));
    }else{
        die(json_encode(array("status" => 500)));
    }
    die();
}

$sql = "SELECT `base_saldo` FROM `usuarios` WHERE `access_key` = '$key'";
$fim= mysqli_query($conexao, $sql);
$saldo = mysqli_fetch_assoc($fim)['base_saldo'];

if ($saldo <= 2){
    die(json_encode(array("status" => 500)));
}
$saldo = $saldo -1;

$sql = "UPDATE `usuarios` SET `base_saldo` = '$saldo' WHERE `access_key` = '$key'";
$fim= mysqli_query($conexao, $sql);