<?php

error_reporting(0);

if(strpos($_SERVER['REQUEST_METHOD'], "GET")!==false){

if(!$_GET['token'] == ""){

   $token = $_GET['token'];
   $fim = file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$token&action=getNumbersStatus&country=73");

  $whatsapp = json_decode($fim,true)["wa_0"]["quant"];
  $valor_wap = '4';
  $code1 = 'wa';
  if($whatsapp == 0){$status1 = 'OFF';}else{$status1 = 'OFF';}

  $pop_99 = json_decode($fim,true)["ki_0"]["quant"];
  $valor_99 = '4';
  $code2 = 'ki';
  if($pop_99 == 0){$status2 = 'OFF';}else{$status2 = 'ONLINE';}

  $caixa = json_decode($fim,true)["my_0"]["quant"];
  $valor_caixa = '2';
  $code3 = 'my';
  if($caixa == 0){$status3 = 'OFF';}else{$status3 = 'ONLINE';}

  $ifood = json_decode($fim,true)["pd_0"]["quant"];
  $valor_ifood = '4';
  $code4 = 'pd';
  if($ifood == 0){$status4 = 'OFF';}else{$status4 = 'ONLINE';}

  $keypay = json_decode($fim,true)["ra_0"]["quant"];
  $valor_keypay = '3';
  $code5 = 'ra';
  if($keypay == 0){$status5 = 'OFF';}else{$status5 = 'ONLINE';}

  $abastece = json_decode($fim,true)["ot_0"]["quant"];
  $valor_abastece = '4';
  $code6 = 'ot';
  if($abastece == 0){$status6 = 'OFF';}else{$status6 = 'ONLINE';}

  $kwai = json_decode($fim,true)["vp_0"]["quant"];
  $valor_kawai = '2';
  $code7 = 'vp';
  if($kwai == 0){$status7 = 'OFF';}else{$status7 = 'ONLINE';}

  $dotz = json_decode($fim,true)["ot_0"]["quant"];
  $valor_dotz = '4';
  $code8 = 'ot';
  if($dotz == 0){$status8 = 'OFF';}else{$status8 = 'ONLINE';}

  $stone = json_decode($fim,true)["ot_0"]["quant"];
  $valor_stone = '4';
  $code9 = 'ot';
  if($stone == 0){$status9 = 'OFF';}else{$status9 = 'ONLINE';}

  $picpay = json_decode($fim,true)["ev_0"]["quant"];
  $valor_picpay = '3';
  $code10 = 'ev';
  if($picpay == 0){$status10 = 'OFF';}else{$status10 = 'ONLINE';}

  $banqi = json_decode($fim,true)["vc_0"]["quant"];
  $valor_banqi = '3';
  $code11 = 'vc';
  if($banqi == 0){$status11 = 'OFF';}else{$status11 = 'ONLINE';}

  $vk = json_decode($fim,true)["vk_0"]["quant"];
  $valor_vk = '2';
  $code12 = 'vk';
  if($vk == 0){$status12 = 'OFF';}else{$status12 = 'ONLINE';}

  $netflix = json_decode($fim,true)["nf_0"]["quant"];
  $valor_netflix = '2';
  $code13 = 'nf';
  if($netflix == 0){$status13 = 'OFF';}else{$status13 = 'ONLINE';}

  $discord = json_decode($fim,true)["ds_0"]["quant"];
  $valor_discord = '4';
  $code14 = 'ds';
  if($discord == 0){$status14 = 'OFF';}else{$status14 = 'ONLINE';}

  $tiktok = json_decode($fim,true)["lf_0"]["quant"];
  $valor_tiktok = '2';
  $code15 = 'lf';
  if($tiktok == 0){$status15 = 'OFF';}else{$status15 = 'ONLINE';}

  $amazon = json_decode($fim,true)["am_0"]["quant"];
  $valor_amazon = '4';
  $code16 = 'am';
  if($amazon == 0){$status16 = 'OFF';}else{$status16 = 'ONLINE';}

  $yalla = json_decode($fim,true)["yl_0"]["quant"];
  $valor_yalla = '2';
  $code17 = 'yl';
  if($yalla == 0){$status17 = 'OFF';}else{$status17 = 'ONLINE';}

  $ok_ru = json_decode($fim,true)["ok_0"]["quant"];
  $valor_ok_ru = '2';
  $code18 = 'ok';
  if($ok_ru == 0){$status18 = 'OFF';}else{$status18 = 'ONLINE';}

  $viber = json_decode($fim,true)["vi_0"]["quant"];
  $valor_viber = '2';
  $code19 = 'vi';
  if($viber == 0){$status19 = 'OFF';}else{$status19 = 'ONLINE';}

  $wechat = json_decode($fim,true)["wb_0"]["quant"];
  $valor_wechat = '2';
  $code20 = 'wb';
  if($wechat == 0){$status20 = 'OFF';}else{$status20 = 'ONLINE';}

  $google = json_decode($fim,true)["go_0"]["quant"];
  $valor_google = '3';
  $code21 = 'go';
  if($google == 0){$status21 = 'OFF';}else{$status21 = 'ONLINE';}

  $facebook = json_decode($fim,true)["fb_0"]["quant"];
  $valor_facebook = '3';
  $code22 = 'fb';
  if($facebook == 0){$status22 = 'OFF';}else{$status22 = 'ONLINE';}

  $twitter = json_decode($fim,true)["tw_0"]["quant"];
  $valor_twitter = '2';
  $code23 = 'tw';
  if($twitter == 0){$status23 = 'OFF';}else{$status23 = 'ONLINE';}

  $paypal = json_decode($fim,true)["ts_0"]["quant"];
  $valor_paypal = '4';
  $code24 = 'ts';
  if($paypal == 0){$status24 = 'OFF';}else{$status24 = 'ONLINE';}

  $shopee = json_decode($fim,true)["ka_0"]["quant"];
  $valor_shopee = '3';
  $code25 = 'ka';
  if($shopee == 0){$status25 = 'OFF';}else{$status25 = 'ONLINE';}

  $outros = json_decode($fim,true)["ot_0"]["quant"];
  $valor_outros = '4';
  $code26 = 'ot';
  if($outros == 0){$status26 = 'OFF';}else{$status26 = 'ONLINE';}

  $instagram = json_decode($fim,true)["ig_0"]["quant"];
  $valor_instagram = '2';
  $code27 = 'ig';
  if($instagram == 0){$status27 = 'OFF';}else{$status27 = 'ONLINE';}

  $olx = json_decode($fim,true)["sn_0"]["quant"];
  $valor_olx = '3';
  $code28 = 'sn';
  if($olx == 0){$status28 = 'OFF';}else{$status28 = 'ONLINE';}

  $telegram = json_decode($fim,true)["tg_0"]["quant"];
  $valor_telegram = '4';
  $code29 = 'tg';
  if($telegram == 0){$status29 = 'OFF';}else{$status29 = 'ONLINE';}

  $microsoft = json_decode($fim,true)["mm_0"]["quant"];
  $valor_microsot = '3';
  $code30 = 'mm';
  if($microsoft == 0){$status30 = 'OFF';}else{$status30 = 'ONLINE';}

  $uber = json_decode($fim,true)["ub_0"]["quant"];
  $valor_uber = '5';
  $code31 = 'ub';
  if($uber == 0){$status31 = 'OFF';}else{$status31 = 'ONLINE';}

  die(json_encode(array("status"=> "true", "services"=> ["whatsapp"=> [$whatsapp, "valor"=> $valor_wap, "status"=> $status1, "code"=> $code1], "99pop"=> [$pop_99, "valor"=> $valor_99, "status"=> $status2, "code"=> $code2], "99food"=> [$pop_99, "valor"=> $valor_99, "status"=> $status2, "code"=> $code2], "99pay"=> [$pop_99, "valor"=> $valor_99, "status"=> $status2, "code"=> $code2], "caixa"=> [$caixa, "valor"=> $valor_caixa, "status"=> $status3, "code"=> $code3], "ifood"=> [$ifood, "valor"=> $valor_ifood, "status"=> $status4, "code"=> $code4], "keypay"=> [$keypay, "valor"=> $valor_keypay, "status"=> $status5, "code"=> $code5 ], "kwai"=> [$kwai, "valor"=> $valor_kawai, "status"=> $status7, "code"=> $code7], "abateceai"=> [$abastece, "valor"=> $valor_abastece, "status"=> $status6, "code"=> $code6], "dotz"=> [$dotz, "valor"=> $valor_dotz, "status"=> $status8, "code"=> $code8], "banco stone"=> [$stone, "valor"=> $valor_stone, "status"=> $status9, "code"=> $code9], "picpay"=> [$picpay, "valor"=> $valor_picpay, "status"=> $status10, "code"=> $code10], "banqi"=> [$banqi, "valor"=> $valor_banqi, "status"=> $status11, "code"=> $code11], "vk.com"=> [$vk, "valor"=> $valor_vk, "status"=> $status12, "code"=> $code12], "netflix"=> [$netflix, "valor"=> $valor_netflix, "status"=> $status13, "code"=> $code13], "discord"=> [$discord, "valor"=> $valor_discord, "status"=> $status14, "code"=> $code14], "tiktok"=> [$tiktok, "valor"=> $valor_tiktok, "status"=> $status15, "code"=> $code15], "amazon"=> [$amazon, "valor"=> $valor_amazon, "status"=> $status16, "code"=> $code16], "yalla"=> [$yalla, "valor"=> $valor_yalla, "status"=> $status17, "code"=> $code17], "ok.ru"=> [$ok_ru, "valor"=> $valor_ok_ru, "status"=> $status18, "code"=> $code18], "viber"=> [$viber, "valor"=> $valor_viber, "status"=> $status19, "code"=> $code19], "wechat"=> [$wechat, "valor"=> $valor_wechat, "status"=> $status20, "code"=> $code20], "google"=> [$google, "valor"=> $valor_google, "status"=> $status21, "code"=> $code21], "facebook"=> [$facebook, "valor"=> $valor_facebook, "status"=> $status22, "code"=> $code22], "twitter"=> [$twitter, "valor"=> $valor_twitter, "status"=> $status23, "code"=> $code23], "olx"=> [$olx, "valor"=> $valor_olx, "status"=> $status28, "code"=> $code28], "paypal"=> [$paypal, "valor"=> $valor_paypal, "status"=> $status24, "code"=> $code24], "shopee"=>[ $shopee, "valor"=> $valor_shopee, "status"=> $status25, "code"=> $code25], "instagram"=> [$instagram, "valor"=> $valor_instagram, "status"=> $status27, "code"=> $code27], "outros"=> [$outros, "valor"=> $valor_outros, "status"=> $status26, "code"=> $code26], "telegram"=> [$telegram, "valor"=> $valor_telegram, "status"=> $status29, "code"=> $code29], "microsoft"=> [$microsoft, "valor"=> $valor_microsot, "status"=> $status30, "code"=> $code30], "uber"=> [$uber, "valor"=> $valor_uber, "status"=> $status31, "code"=> $code31]], "code"=> "200")));
  exit();
}else{
  die(json_encode(array("status"=> "error", "message"=> "WORLD client token not valid", "code"=> "500")));
  exit();
 }
}else{
  die(json_encode(array("status"=> "error", "message"=> "GET POST method not found", "code"=> "500")));
  exit();
}

?>