<?php

error_reporting(0);
date_default_timezone_set('America/Fortaleza');

$notifiyusers = array("nome"=> "guilherme", "servico"=> "pornosexy eu aguento 1 hora", "response"=> time(), "time"=>  date("s"), "status"=> "true");
$notifiyusers = json_encode($notifiyusers,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT );
$salvaone = file_put_contents(getcwd().'/token.json', $notifiyusers);

echo "true";

?>